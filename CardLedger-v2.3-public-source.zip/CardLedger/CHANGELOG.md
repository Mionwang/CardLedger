# Changelog

## 2.3

- Duration-aware recurring totals, with remaining capped amounts and unlimited annual estimates shown separately.
- Start-date editing and automatically inferred next payments, without adding instalments before setup.
- Original charging-day anchors across short months and leap years.

## 2.2

- Optional inclusive recurring end dates, ended status and compatible backup support.

## 2.1

- Ledger card tiles, saved-card linking, manual match review and explicit history consolidation.

## 2.0

- Redesigned interface with migration support for earlier installed data.
