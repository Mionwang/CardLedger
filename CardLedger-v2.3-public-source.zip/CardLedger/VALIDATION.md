# Public-source validation

The public project was compiled and signed successfully with a temporary generic test key supplied from outside the source tree. All 119 JVM tests passed. Actual APK checks passed for application identity, label, launcher, unchanged permissions, disabled backups, absence of test adapters, signature verification and ZIP alignment. The temporary test key and test APK are not included.

Application Java source, resources, assets and synthetic test fixtures are unchanged from Card Ledger 2.3. Build configuration accepts developer-supplied signing credentials. No phone/emulator UI or biometric/Keystore verification was performed.

The final archive excludes signing material, credentials, real databases, private backups, private handover files, old build logs, generated binaries and repository history. Its contents were scanned for the original signing password, private-key headers, personal names/contact information, local workspace paths and owner-specific signing references. Public Android identifiers and runtime cryptography compatibility constants remain because they are part of the app, not private keys.
