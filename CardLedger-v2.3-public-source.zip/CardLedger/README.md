# Card Ledger

Card Ledger 2.3 is an offline Android app for tracking credit-card expenses, cashback, billing dates and recurring payments, with a locally encrypted saved-card vault.

## Features

- Multiple cards with independent billing days, balances, expenses and cashback.
- Combined outstanding balance and automatic card sorting.
- Saved cards with automatic card-network detection, expiry-date formatting and supported NFC reading.
- Ledger tiles and saved-card linking, with manual review for uncertain name matches.
- Weekly, monthly and yearly recurring payments; editable start dates, automatically inferred next charges, pauses and optional inclusive end dates.
- Original charging-day anchors across short months and leap years.
- Remaining totals for end-dated rules, separately labeled annual estimates for unlimited rules.
- Display-only currency selection with SIM-country detection and manual override.
- Device authentication and encrypted saved-card storage. No Internet permission or Gmail sync.

## Project layout

`app/` contains production source, Android resources and synthetic JVM tests. `tests/` contains the host test runner and APK checks. Font licence notices are retained in the assets directory.

This public source package contains no signing keys, signing credentials, personal databases, personal backups, prebuilt APKs or private handover archives. Android application/launcher identifiers and on-device cryptography compatibility constants remain in the code because existing installations use them; they are not credentials. Runtime vault keys are generated and stored on each device, not in this source.

## Build

Use JDK 17, Android SDK platform 35, build-tools 35.0.0, Python 3, Bash and zip. Set `JAVA_HOME` and `ANDROID_SDK_ROOT` for your installation.

Supply your own signing keystore outside the source tree through these environment variables:

- `CARDLEDGER_KEYSTORE`: absolute path to your keystore.
- `CARDLEDGER_KEY_ALIAS`: its signing alias.
- `CARDLEDGER_STORE_PASSWORD`: store password.
- `CARDLEDGER_KEY_PASSWORD`: optional key password, defaulting to the store password.

Run `bash build.sh --no-test` to compile and sign. Output: `dist/CardLedger-v2.3-update.apk`. No signing key or password is included. Android requires the original signing key to update an installed application; builds signed with another key cannot update an existing installation signed by someone else. Android Studio can also open this Gradle project; without release-signing environment variables, its release output is unsigned.

For the complete native build and host tests, provide `JUNIT_JAR` (JUnit 4.13.2), `HAMCREST_JAR` (Hamcrest 1.3), `SQLITE_JDBC_JAR` (sqlite-jdbc 3.46.1.0), and `SLF4J_JAR` (slf4j-api 2.0.13), then run `bash build.sh`. `bash tests/run.sh` repeats tests against the latest native build. Tests and JDBC adapters are excluded from the APK.

Run `python3 tests/static_checks.py` after building. Optionally set `CARDLEDGER_EXPECTED_CERT_SHA256` to check the APK against your own expected public certificate fingerprint.

## Sharing

Extract this ZIP and upload the project files to a repository. Keep signing keys, passwords, real card data and local build output outside version control; the included `.gitignore` excludes common sensitive files. Publish installable APKs separately as release assets if needed.
