# Maintenance

The application ID and launcher identifiers are retained for compatibility. Database schema 3 adds optional recurring end dates to the existing ledger/linking schema. Backup JSON format 2 retains support for format-1 imports. Do not change device key aliases, wrapping-file names or authenticated-data constants without a tested migration.

The Start date editor uses the same schedule projection for preview and save. It skips instalments before today when a schedule is established or edited, retains processed indices on unchanged schedules, and prevents a second linked payment on today's date after an anchor correction. Posted history is never automatically removed. After setup, normal missed-payment catch-up still applies, capped by today and the inclusive end date.

Remaining commitments count upcoming unposted occurrences on active capped rules. Unlimited annual estimates use a separate amount and label. Paused/ended rules are excluded from active commitments. Sorting uses balance, active recurrence and an annual estimate limited by any end date.

This source contains synthetic fixtures only. Maintain signing keys separately; never commit keystores, credentials, real databases or personal exports. Existing installations require the same signing key for updates.
