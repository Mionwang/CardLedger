package android.hardware.biometrics;

import android.content.Context;
import android.os.CancellationSignal;

import java.util.concurrent.Executor;

/**
 * COMPILE-ONLY STUB of the Android 9+ framework class, used by build.sh because the
 * offline toolchain compiles against the Android 6.0 platform jar. It is never
 * packaged into the APK; at runtime the real framework class is used, and only on
 * Android 10+ (guarded by SDK_INT checks). Gradle builds against a newer SDK and
 * does not use this directory.
 */
public class BiometricPrompt {
    public static final int BIOMETRIC_ERROR_HW_UNAVAILABLE = 1;
    public static final int BIOMETRIC_ERROR_CANCELED = 5;
    public static final int BIOMETRIC_ERROR_LOCKOUT = 7;
    public static final int BIOMETRIC_ERROR_LOCKOUT_PERMANENT = 9;
    public static final int BIOMETRIC_ERROR_USER_CANCELED = 10;
    public static final int BIOMETRIC_ERROR_NO_BIOMETRICS = 11;
    public static final int BIOMETRIC_ERROR_NO_DEVICE_CREDENTIAL = 14;

    public void authenticate(CancellationSignal cancel, Executor executor, AuthenticationCallback callback) {
        throw new RuntimeException("Stub!");
    }

    public static class Builder {
        public Builder(Context context) { throw new RuntimeException("Stub!"); }
        public Builder setTitle(CharSequence title) { throw new RuntimeException("Stub!"); }
        public Builder setSubtitle(CharSequence subtitle) { throw new RuntimeException("Stub!"); }
        public Builder setDescription(CharSequence description) { throw new RuntimeException("Stub!"); }
        public Builder setDeviceCredentialAllowed(boolean allowed) { throw new RuntimeException("Stub!"); }
        public Builder setAllowedAuthenticators(int authenticators) { throw new RuntimeException("Stub!"); }
        public Builder setConfirmationRequired(boolean required) { throw new RuntimeException("Stub!"); }
        public BiometricPrompt build() { throw new RuntimeException("Stub!"); }
    }

    public abstract static class AuthenticationCallback {
        public void onAuthenticationError(int errorCode, CharSequence errString) { }
        public void onAuthenticationHelp(int helpCode, CharSequence helpString) { }
        public void onAuthenticationSucceeded(AuthenticationResult result) { }
        public void onAuthenticationFailed() { }
    }

    public static class AuthenticationResult { }
}
