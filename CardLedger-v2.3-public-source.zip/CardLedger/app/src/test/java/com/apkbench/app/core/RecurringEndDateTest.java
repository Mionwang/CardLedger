package com.apkbench.app.core;

import org.junit.Test;
import static org.junit.Assert.*;
import java.nio.file.Files;
import java.nio.file.Path;

public final class RecurringEndDateTest {
    private static long d(String date){return CivilDate.parseIso(date);}
    private static final class Fixture implements AutoCloseable {
        final JdbcDb db=JdbcDb.memory(); final LedgerRepo repo=new LedgerRepo(db);
        final long card=repo.createCard("Test",10);
        long rule(int freq,String first,String end){return repo.createRule(card,"Payment",10000,freq,d(first),"",end==null?null:d(end));}
        @Override public void close(){db.close();}
    }

    @Test public void monthlyEndIsInclusiveAndDelayedCatchUpStopsAtIt() {
        try(Fixture f=new Fixture()) {
            long id=f.rule(Recurrence.MONTHLY,"2026-01-31","2026-03-31");
            assertEquals(3,f.repo.processDue(d("2026-12-31")));
            assertEquals(d("2026-03-31"),f.repo.listTxns(f.card).get(2).date);
            assertEquals(30000,f.repo.summary(f.card).outstanding);
            assertEquals(0,f.repo.processDue(d("2027-12-31")));
            assertTrue(f.repo.getRule(id).hasEnded(d("2026-03-31")));
            assertNull(f.repo.getRule(id).effectiveNextDate());
        }
    }
    @Test public void weeklyEndBetweenOccurrencesDoesNotInventAFinalCharge() {
        try(Fixture f=new Fixture()) {
            f.rule(Recurrence.WEEKLY,"2026-01-05","2026-01-21");
            assertEquals(3,f.repo.processDue(d("2026-02-01")));
            assertEquals(d("2026-01-19"),f.repo.listTxns(f.card).get(2).date);
        }
    }
    @Test public void leapDayYearlyScheduleRetainsItsAnchorAndCapsCorrectly() {
        try(Fixture f=new Fixture()) {
            long id=f.rule(Recurrence.YEARLY,"2024-02-29","2028-02-29");
            assertEquals(5,f.repo.processDue(d("2030-01-01")));
            assertEquals(d("2028-02-29"),f.repo.listTxns(f.card).get(4).date);
            assertEquals(29,f.repo.getRule(id).anchorDay);
        }
    }
    @Test public void monthEndClampingIncludesFebruary28AndExcludesMarch31() {
        try(Fixture f=new Fixture()) {
            f.rule(Recurrence.MONTHLY,"2026-01-31","2026-02-28");
            assertEquals(2,f.repo.processDue(d("2026-06-01")));
            assertEquals(d("2026-02-28"),f.repo.listTxns(f.card).get(1).date);
        }
    }
    @Test public void endEqualToFirstDateMakesExactlyOnePayment() {
        try(Fixture f=new Fixture()) {
            long id=f.rule(Recurrence.MONTHLY,"2026-01-31","2026-01-31");
            assertEquals(0,f.repo.processDue(d("2026-01-30")));
            assertEquals(1,f.repo.processDue(d("2026-01-31")));
            assertEquals(0,f.repo.processDue(d("2026-02-28")));
            assertNull(f.repo.getRule(id).effectiveNextDate());
        }
    }
    @Test public void invalidEndBeforeFirstIsRejectedWithoutWriting() {
        try(Fixture f=new Fixture()) {
            try{f.rule(Recurrence.MONTHLY,"2026-02-01","2026-01-31");fail();}catch(IllegalArgumentException expected){}
            assertTrue(f.repo.listAllRules().isEmpty());
            long id=f.rule(Recurrence.MONTHLY,"2026-01-31","2026-03-31");
            try{f.repo.updateRule(id,"Changed",900,Recurrence.MONTHLY,d("2026-01-31"),"",d("2026-01-30"));fail();}catch(IllegalArgumentException expected){}
            assertEquals("Payment",f.repo.getRule(id).name);assertEquals(10000,f.repo.getRule(id).amount);
            assertEquals(Long.valueOf(d("2026-03-31")),f.repo.getRule(id).endDate);
        }
    }
    @Test public void changingOnlyTheEndDoesNotReanchorOrErasePostedHistory() {
        try(Fixture f=new Fixture()) {
            long id=f.rule(Recurrence.MONTHLY,"2026-01-31",null);
            f.repo.processDue(d("2026-02-28"));long originalTxn=f.repo.listTxns(f.card).get(0).id;
            f.repo.updateRule(id,"Payment",10000,Recurrence.MONTHLY,d("2026-03-31"),"",d("2026-02-28"));
            assertEquals(31,f.repo.getRule(id).anchorDay);assertEquals(d("2026-01-31"),f.repo.getRule(id).startDate);
            assertEquals(2,f.repo.listTxns(f.card).size());assertNotNull(f.repo.getTxn(originalTxn));
            assertEquals(0,f.repo.processDue(d("2026-12-31")));
        }
    }
    @Test public void extendingOrClearingTheEndContinuesWithoutDuplicatingPriorPayments() {
        try(Fixture f=new Fixture()) {
            long id=f.rule(Recurrence.MONTHLY,"2026-01-31","2026-02-28");
            assertEquals(2,f.repo.processDue(d("2026-06-01")));
            f.repo.updateRule(id,"Payment",10000,Recurrence.MONTHLY,d("2026-03-31"),"",d("2026-04-30"));
            assertEquals(2,f.repo.processDue(d("2026-06-01")));
            f.repo.updateRule(id,"Payment",10000,Recurrence.MONTHLY,d("2026-05-31"),"",null);
            assertEquals(1,f.repo.processDue(d("2026-06-01")));
            assertEquals(5,f.repo.listTxns(f.card).size());assertEquals(31,f.repo.getRule(id).anchorDay);
        }
    }
    @Test public void ordinaryEditOverloadPreservesTheExistingEnd() {
        try(Fixture f=new Fixture()) {
            long id=f.rule(Recurrence.MONTHLY,"2026-01-31","2026-03-31");
            f.repo.updateRule(id,"Renamed",200,Recurrence.MONTHLY,d("2026-01-31"),"Note");
            assertEquals(Long.valueOf(d("2026-03-31")),f.repo.getRule(id).endDate);
        }
    }
    @Test public void timedPauseEndingBeyondCutoffCannotGeneratePaymentsAfterEnd() {
        try(Fixture f=new Fixture()) {
            long id=f.rule(Recurrence.MONTHLY,"2026-01-31","2026-03-31");
            f.repo.pauseRule(id,6,d("2026-02-01"));
            assertNull(f.repo.getRule(id).effectiveNextDate());
            assertEquals(0,f.repo.processDue(d("2026-12-01")));
            assertEquals(1,f.repo.listTxns(f.card).size());
        }
    }
    @Test public void earlyResumeStillHonoursTheEndDate() {
        try(Fixture f=new Fixture()) {
            long id=f.rule(Recurrence.MONTHLY,"2026-01-31","2026-03-31");
            f.repo.pauseRule(id,6,d("2026-02-01"));f.repo.resumeRule(id,d("2026-02-15"));
            assertEquals(2,f.repo.processDue(d("2026-05-01")));
            assertEquals(3,f.repo.listTxns(f.card).size());
        }
    }
    @Test public void endedRulesCannotBeResumedOrPausedWithoutEditingTheirEnd() {
        try(Fixture f=new Fixture()) {
            long id=f.rule(Recurrence.MONTHLY,"2026-01-31","2026-03-31");
            f.repo.pauseRule(id,0,d("2026-02-01"));
            try{f.repo.resumeRule(id,d("2026-04-01"));fail();}catch(IllegalArgumentException expected){}
            try{f.repo.pauseRule(id,1,d("2026-04-01"));fail();}catch(IllegalArgumentException expected){}
            assertEquals(1,f.repo.listTxns(f.card).size());
        }
    }
    @Test public void endedRulesAreExcludedFromActiveCountsAndAnnualCommitment() {
        try(Fixture f=new Fixture()) {
            f.rule(Recurrence.MONTHLY,"2020-01-01","2020-01-01");f.repo.processDue(d("2020-01-01"));
            Models.CardSummary summary=f.repo.summary(f.card);
            assertEquals(1,summary.ruleCount);assertEquals(0,summary.activeRuleCount);
            assertEquals(1,summary.endedRuleCount);assertEquals(0,summary.pausedRuleCount);assertEquals(0,summary.annualCommitment);
        }
    }
    @Test public void backupsRoundTripTheEndAndVersionOneBackupsRemainUnlimited() throws Exception {
        try(Fixture f=new Fixture();JdbcDb target=JdbcDb.memory()) {
            f.rule(Recurrence.MONTHLY,"2026-01-31","2026-03-31");
            String json=LedgerTransfer.export(f.repo,d("2026-01-01"));
            Json.Obj exported=Json.Obj.of(Json.parse(json),"file");
            assertEquals(2L,exported.integer("version",true,0));
            Json.Obj card=Json.Obj.of(exported.list("cards",true).get(0),"card");
            Json.Obj rule=Json.Obj.of(card.list("recurring",true).get(0),"rule");
            assertEquals("2026-03-31",rule.str("endDate",true));
            LedgerRepo restored=new LedgerRepo(target);LedgerTransfer.apply(restored,LedgerTransfer.plan(restored,json));
            assertEquals(Long.valueOf(d("2026-03-31")),restored.listAllRules().get(0).endDate);
            assertEquals(3,restored.processDue(d("2027-01-01")));
            String legacy="{\"format\":\"apkbench-ledger\",\"version\":1,\"cards\":[{\"name\":\"Old\",\"billingDay\":1,\"recurring\":[{\"name\":\"Old payment\",\"amount\":\"1\",\"frequency\":\"monthly\",\"nextDate\":\"2026-01-01\"}]}]}";
            LedgerTransfer.apply(restored,LedgerTransfer.plan(restored,legacy));
            assertNull(restored.listAllRules().get(1).endDate);
        }
    }
    @Test public void invalidBackupEndDoesNotModifyTheDestination() throws Exception {
        try(Fixture f=new Fixture();JdbcDb target=JdbcDb.memory()) {
            f.rule(Recurrence.MONTHLY,"2026-01-31","2026-03-31");
            Json.Obj exported=Json.Obj.of(Json.parse(LedgerTransfer.export(f.repo,d("2026-01-01"))),"file");
            Json.Obj card=Json.Obj.of(exported.list("cards",true).get(0),"card");
            Json.Obj rule=Json.Obj.of(card.list("recurring",true).get(0),"rule");
            rule.map.put("endDate","2026-01-01");
            String bad=Json.write(exported.map);
            LedgerRepo restored=new LedgerRepo(target);
            try{LedgerTransfer.plan(restored,bad);fail();}catch(IllegalArgumentException expected){}
            assertTrue(restored.listCards().isEmpty());assertTrue(restored.listAllRules().isEmpty());
        }
    }
    @Test public void schemaTwoUpgradePreservesRulesLinksBalancesAndCiphertext() throws Exception {
        Path path=Files.createTempFile("cardledger-end-upgrade-", ".db");byte[] cipher={4,5,6};
        try(JdbcDb old=new JdbcDb("jdbc:sqlite:"+path)) {
            for(String sql:Schema.CREATE)old.exec(sql.replace(" end_date INTEGER,",""));
            old.exec("PRAGMA user_version=2");
            old.insert("INSERT INTO cards VALUES(1,'Existing',10,1)");
            old.insert("INSERT INTO rules(id,card_id,name,amount,frequency,start_date,anchor_day,created_at) VALUES(2,1,'Existing payment',100,1,?,31,1)",d("2026-01-31"));
            old.insert("INSERT INTO vault VALUES(3,?,?,1,1)",new byte[12],cipher);
            old.insert("INSERT INTO card_links VALUES(3,1,'manual',0,'')");
            old.insert("INSERT INTO txns(card_id,type,amount,date,created_at) VALUES(1,0,100,?,1)",d("2026-01-01"));
        }
        try(JdbcDb upgraded=JdbcDb.file(path.toString())) {
            LedgerRepo repo=new LedgerRepo(upgraded);
            assertNull(repo.getRule(2).endDate);assertEquals(31,repo.getRule(2).anchorDay);
            assertEquals(1,new CardLinks(upgraded).forSaved(3).ledgerId);assertEquals(100,repo.summary(1).outstanding);
            assertArrayEquals(cipher,upgraded.query("SELECT data FROM vault WHERE id=3").get(0).getBlob("data"));
            assertEquals(3,upgraded.query("PRAGMA user_version").get(0).getInt("user_version"));
        }
        Files.deleteIfExists(path);
    }
}
