package com.apkbench.app.core;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class VaultEmvTest {
    private JdbcDb db;
    private VaultRepo vault;
    private VaultCipher cipher;

    @Before public void setUp() {
        db = JdbcDb.memory();
        byte[] k = new byte[32];
        new SecureRandom().nextBytes(k);
        final SecretKey key = new SecretKeySpec(k, "AES");
        cipher = new VaultCipher(new VaultCipher.KeySource() {
            @Override public SecretKey key() { return key; }
        });
        vault = new VaultRepo(db, cipher);
    }

    @After public void tearDown() { db.close(); }

    private CardInfo card(String number, String cvv, String network) {
        CardInfo c = new CardInfo();
        c.bank = "Test Bank";
        c.product = "Test Product";
        c.holder = "TEST HOLDER";
        c.number = number;
        c.expMonth = 12;
        c.expYear = 2030;
        c.network = network;
        c.cvv = cvv;
        return c;
    }

    // ------------------------------------------------------------ crypto

    @Test public void aesGcmRoundTripAndTamper() {
        byte[] plain = "secret".getBytes(StandardCharsets.UTF_8);
        VaultCipher.Sealed a = cipher.encrypt(plain);
        VaultCipher.Sealed b = cipher.encrypt(plain);
        assertEquals(12, a.iv.length);
        assertFalse("IV must be fresh", java.util.Arrays.equals(a.iv, b.iv));
        assertEquals(plain.length + 16, a.data.length); // 128-bit tag
        assertArrayEquals(plain, cipher.decrypt(a.iv, a.data));
        a.data[0] ^= 1;
        try { cipher.decrypt(a.iv, a.data); fail("tamper not detected"); } catch (IllegalStateException expected) { }
    }

    @Test public void vaultStoresOnlyCiphertext() {
        String n = TestCards.make("4", 16);
        long id = vault.add(card(n, "012", "Visa"));
        Db.Row row = db.query("SELECT * FROM vault WHERE id=?", id).get(0);
        String stored = new String(row.getBlob("data"), StandardCharsets.ISO_8859_1);
        assertFalse(stored.contains(n));
        assertFalse(stored.contains("Test Bank"));
        CardInfo back = vault.get(id);
        assertEquals(n, back.number);
        assertEquals("012", back.cvv); // leading zero preserved
        assertEquals("Visa", back.network);
    }

    @Test public void unreadableRecordsAreReported() {
        long id = vault.add(card(TestCards.make("51", 16), "", "Mastercard"));
        db.exec("UPDATE vault SET data=? WHERE id=?", new byte[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17}, id);
        VaultRepo.Loaded l = vault.load();
        assertTrue(l.cards.isEmpty());
        assertEquals(1, l.unreadable.size());
    }

    @Test public void duplicatesPrevented() {
        String n = TestCards.make("4", 16);
        long id = vault.add(card(n, "", "Visa"));
        try { vault.add(card(n.substring(0, 4) + " " + n.substring(4), "", "Visa")); fail(); } catch (IllegalArgumentException expected) { }
        CardInfo c = vault.get(id);
        c.product = "Renamed";
        vault.update(c);
        assertEquals("Renamed", vault.get(id).product);
        long other = vault.add(card(TestCards.make("4", 16), "", "Visa"));
        CardInfo o = vault.get(other);
        o.number = n;
        try { vault.update(o); fail(); } catch (IllegalArgumentException expected) { }
        vault.delete(id);
        assertEquals(1, vault.load().cards.size());
    }

    // ------------------------------------------------------------ validation

    @Test public void numberValidation() {
        String v = TestCards.make("4", 16);
        assertEquals(v, CardInfo.validateNumber(v.substring(0, 8) + " " + v.substring(8)));
        try { CardInfo.validateNumber(TestCards.broken(v)); fail(); } catch (IllegalArgumentException expected) { }
        try { CardInfo.validateNumber("12345"); fail(); } catch (IllegalArgumentException expected) { }
        try { CardInfo.validateNumber("4abc"); fail(); } catch (IllegalArgumentException expected) { }
        try { CardInfo.validateNumber(""); fail(); } catch (IllegalArgumentException expected) { }
    }

    @Test public void networkDetection() {
        assertEquals("Visa", CardInfo.detectNetwork(TestCards.make("4", 16)));
        assertEquals("Mastercard", CardInfo.detectNetwork(TestCards.make("53", 16)));
        assertEquals("Mastercard", CardInfo.detectNetwork(TestCards.make("2221", 16)));
        assertEquals("American Express", CardInfo.detectNetwork(TestCards.make("37", 15)));
        assertEquals("RuPay", CardInfo.detectNetwork(TestCards.make("6080", 16)));
        assertEquals("RuPay", CardInfo.detectNetwork(TestCards.make("508", 16)));
        assertEquals("Discover", CardInfo.detectNetwork(TestCards.make("6011", 16)));
        assertEquals("JCB", CardInfo.detectNetwork(TestCards.make("3530", 16)));
        assertEquals("UnionPay", CardInfo.detectNetwork(TestCards.make("6250", 16)));
        assertEquals("Diners Club", CardInfo.detectNetwork(TestCards.make("36", 14)));
        assertEquals("Other", CardInfo.detectNetwork(TestCards.make("9", 16)));
    }

    @Test public void cvvRules() {
        assertEquals("", CardInfo.validateCvv("", "Visa"));
        assertEquals("007", CardInfo.validateCvv("007", "Visa"));
        assertEquals("0042", CardInfo.validateCvv("0042", "American Express"));
        assertEquals("0042", CardInfo.validateCvv("0042", "Other"));
        assertEquals("042", CardInfo.validateCvv("042", "Other"));
        String[][] bad = {{"12", "Other"}, {"12345", "Other"}, {"12a", "Visa"}, {"123", "American Express"},
                {"1234", "Visa"}, {"1234", "RuPay"}};
        for (String[] b : bad) {
            try { CardInfo.validateCvv(b[0], b[1]); fail(b[0] + " " + b[1]); } catch (IllegalArgumentException expected) { }
        }
    }

    @Test public void expiryRules() {
        assertArrayEquals(new int[]{3, 2029}, CardInfo.parseExpiry("03/29"));
        assertArrayEquals(new int[]{3, 2029}, CardInfo.parseExpiry("3/2029"));
        assertArrayEquals(new int[]{11, 2030}, CardInfo.parseExpiry("1130"));
        String[] bad = {"13/29", "00/29", "ab/cd", "1/2/3", "123", ""};
        for (String b : bad) {
            try { CardInfo.parseExpiry(b); fail(b); } catch (IllegalArgumentException expected) { }
        }
        CardInfo.validateExpiry(10, 2026, 2026, 10); // valid through end of month
        try { CardInfo.validateExpiry(9, 2026, 2026, 10); fail(); } catch (IllegalArgumentException expected) { }
        try { CardInfo.validateExpiry(1, 2060, 2026, 10); fail(); } catch (IllegalArgumentException expected) { }
    }

    @Test public void masking() {
        String n = TestCards.make("4", 16);
        assertEquals("•••• •••• •••• " + n.substring(12), CardInfo.mask(n));
        assertEquals("•••", CardInfo.maskCvv("012"));
        assertEquals("Not saved", CardInfo.maskCvv(""));
        String a = TestCards.make("37", 15);
        assertEquals(a.substring(0, 4) + " " + a.substring(4, 10) + " " + a.substring(10), CardInfo.group(a, "American Express"));
    }

    // ------------------------------------------------------------ saved card import

    @Test public void savedCardImportMasksDropsCvvAndEncrypts() {
        String existing = TestCards.make("4", 16);
        vault.add(card(existing, "", "Visa"));
        String fresh = TestCards.make("52", 16);
        String amex = TestCards.make("34", 15);
        String json = "{\"format\":\"apkbench-saved-cards\",\"version\":1,\"cards\":["
                + "{\"bank\":\"B1\",\"product\":\"P1\",\"cardholder\":\"A B\",\"cardNumber\":\"" + fresh + "\",\"expiry\":\"08/31\",\"cvv\":\"123\"},"
                + "{\"issuer\":\"B2\",\"number\":\"" + amex + "\",\"expMonth\":1,\"expYear\":2032,\"network\":\"amex\",\"type\":\"debit\"},"
                + "{\"bank\":\"B3\",\"number\":\"" + existing + "\",\"expiry\":\"01/30\"},"
                + "{\"bank\":\"B4\",\"number\":\"" + TestCards.broken(fresh) + "\",\"expiry\":\"01/30\"},"
                + "{\"bank\":\"B5\",\"number\":\"" + TestCards.make("4", 16) + "\",\"expiry\":\"01/20\"},"
                + "{\"bank\":\"B6\",\"number\":\"" + fresh + "\",\"expiry\":\"08/31\"}"
                + "]}";
        SavedCardImport.Plan plan = SavedCardImport.plan(vault, json, 2026, 10);
        String preview = plan.describe();
        assertFalse("preview leaks full number", preview.contains(fresh));
        assertFalse(preview.contains(amex));
        assertTrue(preview.contains(fresh.substring(12)));
        assertEquals(1, plan.cvvDropped);
        assertEquals(2, plan.importable().size());
        assertTrue(plan.rows.get(2).duplicate);
        assertTrue(plan.rows.get(3).problem != null);
        assertTrue(plan.rows.get(4).problem.contains("expired"));
        assertTrue(plan.rows.get(5).duplicate);
        assertEquals(2, SavedCardImport.apply(vault, plan));
        VaultRepo.Loaded l = vault.load();
        assertEquals(3, l.cards.size());
        for (CardInfo c : l.cards) assertEquals("", c.cvv);
        CardInfo a = l.cards.get(2);
        assertEquals("American Express", a.network);
        assertEquals(CardInfo.KIND_DEBIT, a.kind);
        assertEquals(2032, a.expYear);
        for (Db.Row r : db.query("SELECT data FROM vault")) {
            assertFalse(new String(r.getBlob("data"), StandardCharsets.ISO_8859_1).contains(fresh));
        }
    }

    @Test public void savedCardImportRejectsLedgerFile() {
        try {
            SavedCardImport.plan(vault, "{\"format\":\"apkbench-ledger\",\"version\":1,\"cards\":[]}", 2026, 10);
            fail();
        } catch (IllegalArgumentException expected) { }
    }

    // ------------------------------------------------------------ EMV / NFC

    private static byte[] tlv(int tag, byte[]... parts) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        ByteArrayOutputStream v = new ByteArrayOutputStream();
        for (byte[] p : parts) v.write(p, 0, p.length);
        if (tag > 0xFF) o.write(tag >> 8);
        o.write(tag & 0xFF);
        int len = v.size();
        if (len > 127) { o.write(0x81); }
        o.write(len);
        byte[] vb = v.toByteArray();
        o.write(vb, 0, vb.length);
        return o.toByteArray();
    }

    private static byte[] ok(byte[] data) {
        byte[] r = new byte[data.length + 2];
        System.arraycopy(data, 0, r, 0, data.length);
        r[data.length] = (byte) 0x90;
        return r;
    }

    private static final byte[] NOT_FOUND = {0x6A, (byte) 0x82};

    private static byte[] bcdPan(String digits) {
        String h = digits.length() % 2 == 0 ? digits : digits + "F";
        return Emv.unhex(h);
    }

    /** Scripted card: responds by APDU prefix. */
    private static final class FakeCard implements Emv.Transceiver {
        final List<String> log = new ArrayList<>();
        final java.util.Map<String, byte[]> script = new java.util.LinkedHashMap<>();

        @Override public byte[] transceive(byte[] apdu) throws IOException {
            String h = Emv.hex(apdu);
            log.add(h);
            for (java.util.Map.Entry<String, byte[]> e : script.entrySet()) {
                if (h.startsWith(e.getKey())) return e.getValue();
            }
            return NOT_FOUND;
        }
    }

    @Test public void tlvParsing() {
        byte[] data = tlv(0x6F, tlv(0x84, new byte[]{1, 2}), tlv(0xA5, tlv(0x50, "LABEL".getBytes()), tlv(0xBF0C,
                tlv(0x61, tlv(0x4F, Emv.unhex("A0000000031010"))))));
        List<Emv.Tlv> t = Emv.parse(data);
        assertEquals("LABEL", new String(Emv.find(t, 0x50).value));
        assertEquals("A0000000031010", Emv.hex(Emv.find(t, 0x4F).value));
        // truncated input does not throw
        byte[] cut = java.util.Arrays.copyOf(data, data.length - 3);
        Emv.parse(cut);
    }

    @Test public void readsTrack2FromGpoFormat2() throws IOException {
        String pan = TestCards.make("4", 16);
        FakeCard card = new FakeCard();
        byte[] aid = Emv.unhex("A0000000031010");
        card.script.put("00A404000E", ok(tlv(0x6F, tlv(0x84, "2PAY.SYS.DDF01".getBytes()),
                tlv(0xA5, tlv(0xBF0C, tlv(0x61, tlv(0x4F, aid), tlv(0x50, "VISA DEBIT".getBytes())))))));
        card.script.put("00A4040007A0000000031010", ok(tlv(0x6F, tlv(0x84, aid),
                tlv(0xA5, tlv(0x50, "VISA DEBIT".getBytes()), tlv(0x9F38, Emv.unhex("9F66049F02069F37049A039F1A02"))))));
        card.script.put("80A80000", ok(tlv(0x77, tlv(0x82, new byte[]{0x20, 0x00}),
                tlv(0x57, Emv.unhex(pan + "D3001201" + "0000000000000F")),
                tlv(0x5F20, "SMITH/JANE".getBytes()))));
        Emv.Result r = Emv.read(card);
        assertEquals(pan, r.number);
        assertEquals(1, r.expMonth);
        assertEquals(2030, r.expYear);
        assertEquals("JANE SMITH", r.holder);
        assertEquals("Visa", r.network);
        // GPO carried PDOL data of the right length: 4+6+4+3+2 = 19 bytes
        String gpo = null;
        for (String s : card.log) if (s.startsWith("80A8")) gpo = s;
        assertEquals("80A8000015" + "8313", gpo.substring(0, 14));
    }

    @Test public void readsRecordsViaAflAndHandles61xx() throws IOException {
        String pan = TestCards.make("53", 16);
        FakeCard card = new FakeCard();
        byte[] aid = Emv.unhex("A0000000041010");
        card.script.put("00A404000E", ok(tlv(0x6F, tlv(0xA5, tlv(0xBF0C, tlv(0x61, tlv(0x4F, aid)))))));
        card.script.put("00A4040007A0000000041010", new byte[]{0x61, 0x10}); // response waiting
        card.script.put("00C0000010", ok(tlv(0x6F, tlv(0xA5, tlv(0x50, "MASTERCARD".getBytes())))));
        // format 1: AIP 1980, AFL: SFI 1 records 1-2
        card.script.put("80A80000", ok(tlv(0x80, Emv.unhex("1980" + "08010200"))));
        card.script.put("00B2010C", ok(tlv(0x70, tlv(0x9F42, new byte[]{0x03, 0x56}))));
        card.script.put("00B2020C", ok(tlv(0x70, tlv(0x5A, bcdPan(pan)), tlv(0x5F24, Emv.unhex("281131")),
                tlv(0x5F20, " /".getBytes()))));
        Emv.Result r = Emv.read(card);
        assertEquals(pan, r.number);
        assertEquals(11, r.expMonth);
        assertEquals(2028, r.expYear);
        assertEquals("", r.holder); // placeholder name ignored
        assertEquals("Mastercard", r.network);
        assertEquals("MASTERCARD", r.label);
    }

    @Test public void unreadableCardThrows() {
        FakeCard card = new FakeCard();
        try { Emv.read(card); fail(); } catch (IOException expected) { }
        assertNotEquals(0, card.log.size());
    }
}
