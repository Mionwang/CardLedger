package com.apkbench.app.core;

import org.junit.Test;
import static org.junit.Assert.*;

/** Exercises the production migration against actual SQLite databases. */
public final class LegacyUpgradeTest {
    public static JdbcDb original() {
        JdbcDb db = new JdbcDb("jdbc:sqlite::memory:");
        db.exec("PRAGMA user_version=4");
        db.exec("CREATE TABLE cards(_id INTEGER PRIMARY KEY,name TEXT,bill_day INTEGER,created_at INTEGER)");
        db.exec("CREATE TABLE recurring(_id INTEGER PRIMARY KEY,card_id INTEGER,title TEXT,amount_paise INTEGER,frequency TEXT,"
                + "next_date TEXT,anchor_day INTEGER,active INTEGER,paused_until TEXT,pause_resume_date TEXT,created_at INTEGER)");
        db.exec("CREATE TABLE transactions(_id INTEGER PRIMARY KEY,card_id INTEGER,title TEXT,amount_paise INTEGER,type TEXT,"
                + "date TEXT,notes TEXT,recurring_id INTEGER,created_at INTEGER)");
        db.exec("CREATE TABLE saved_cards(_id INTEGER PRIMARY KEY,payload BLOB)");
        return db;
    }

    @Test public void balancesLinksIdsDatesAndUnsetBillDaySurviveAndMigrationRunsOnce() {
        try (JdbcDb old = original(); JdbcDb target = JdbcDb.memory()) {
            old.insert("INSERT INTO cards VALUES(7,'Travel',31,100)");
            old.insert("INSERT INTO cards VALUES(9,'Unscheduled',0,101)");
            old.insert("INSERT INTO recurring VALUES(11,7,'Monthly',12345,'MONTHLY','2026-01-31',31,1,NULL,NULL,110)");
            old.insert("INSERT INTO transactions VALUES(41,7,'Expense',10001,'EXPENSE','2026-01-05','one cent',11,120)");
            old.insert("INSERT INTO transactions VALUES(44,7,'Cashback',5001,'CASHBACK','2026-01-06',NULL,NULL,121)");
            LegacyUpgrade.migrate(old,target);
            LedgerRepo repo = new LedgerRepo(target);
            assertEquals(5000,repo.summary(7).outstanding);
            assertEquals(31,repo.getCard(7).billingDay);
            assertEquals(0,repo.getCard(9).billingDay);
            assertEquals(11,repo.getTxn(41).recurringId.longValue());
            assertEquals("one cent",repo.getTxn(41).note);
            assertEquals(CivilDate.parseIso("2026-01-05"),repo.getTxn(41).date);
            assertEquals(1,repo.processDue(CivilDate.parseIso("2026-01-31")));
            assertEquals(0,repo.processDue(CivilDate.parseIso("2026-01-31")));
            assertEquals(CivilDate.parseIso("2026-02-28"),repo.getRule(11).nextDate());
            LegacyUpgrade.migrate(old,target);
            assertEquals(3,repo.listTxns(7).size());
            assertEquals(2,old.query("SELECT * FROM transactions").size());
            // A migrated card without a billing date remains exportable and restorable.
            String json = LedgerTransfer.export(repo,CivilDate.parseIso("2026-01-31"));
            try (JdbcDb restored = JdbcDb.memory()) {
                LedgerRepo other = new LedgerRepo(restored);
                LedgerTransfer.apply(other,LedgerTransfer.plan(other,json));
                assertEquals(2,other.listCards().size());
                assertEquals(0,other.listCards().get(1).billingDay);
            }
        }
    }

    @Test public void timedAndIndefinitePausesAndEarlyResumeKeepTheirSchedules() {
        try (JdbcDb old = original(); JdbcDb target = JdbcDb.memory()) {
            old.insert("INSERT INTO cards VALUES(1,'Test',1,1)");
            old.insert("INSERT INTO recurring VALUES(2,1,'Timed',100,'MONTHLY','2026-04-30',31,1,'2026-04-20','2026-01-31',1)");
            old.insert("INSERT INTO recurring VALUES(3,1,'Indefinite',200,'YEARLY','2028-02-29',29,0,NULL,NULL,1)");
            LegacyUpgrade.migrate(old,target);
            LedgerRepo repo = new LedgerRepo(target);
            assertTrue(repo.getRule(2).paused);
            assertEquals(CivilDate.parseIso("2026-04-30"),repo.getRule(2).effectiveNextDate().longValue());
            assertNull(repo.getRule(3).effectiveNextDate());
            assertEquals(0,repo.processDue(CivilDate.parseIso("2026-04-19")));
            repo.resumeRule(2,CivilDate.parseIso("2026-02-01"));
            assertFalse(repo.getRule(2).paused);
            assertEquals(CivilDate.parseIso("2026-02-28"),repo.getRule(2).nextDate());
            assertEquals(1,repo.processDue(CivilDate.parseIso("2026-02-28")));
            assertEquals(CivilDate.parseIso("2026-03-31"),repo.getRule(2).nextDate());
        }
    }

    @Test public void completedTimedPauseSkipsItsWholeWindowAndYearlyLeapAnchorSurvives() {
        try (JdbcDb old = original(); JdbcDb target = JdbcDb.memory()) {
            old.insert("INSERT INTO cards VALUES(1,'Test',1,1)");
            old.insert("INSERT INTO recurring VALUES(2,1,'Timed',100,'MONTHLY','2026-04-30',31,1,'2026-04-20','2026-01-31',1)");
            old.insert("INSERT INTO recurring VALUES(3,1,'Leap',200,'YEARLY','2027-02-28',29,1,NULL,NULL,1)");
            LegacyUpgrade.migrate(old,target);
            LedgerRepo repo = new LedgerRepo(target);
            assertEquals(1,repo.processDue(CivilDate.parseIso("2026-04-30")));
            assertEquals(CivilDate.parseIso("2026-04-30"),repo.listTxns(1).get(0).date);
            assertEquals(CivilDate.parseIso("2028-02-29"),Recurrence.occurrence(Recurrence.YEARLY,
                    repo.getRule(3).startDate,repo.getRule(3).anchorDay,1));
        }
    }

    @Test public void failedMigrationRollsBackEveryDestinationWriteAndCanRetry() {
        try (JdbcDb old = original(); JdbcDb target = JdbcDb.memory()) {
            old.insert("INSERT INTO cards VALUES(1,'Original',1,1)");
            old.insert("INSERT INTO transactions VALUES(2,1,'Test',100,'EXPENSE','2026-01-01','',NULL,1)");
            old.insert("INSERT INTO saved_cards VALUES(8,?)",new byte[]{1,2});
            try { LegacyUpgrade.migrate(old,target); fail(); } catch (IllegalStateException expected) { }
            assertFalse(LegacyUpgrade.isComplete(target));
            assertEquals(0,target.query("SELECT * FROM cards").size());
            assertEquals(0,target.query("SELECT * FROM txns").size());
            assertEquals(1,old.query("SELECT * FROM cards").size());
            old.exec("DELETE FROM saved_cards"); // repair only the synthetic fixture
            LegacyUpgrade.migrate(old,target);
            assertTrue(LegacyUpgrade.isComplete(target));
        }
    }

    @Test public void refusesToOverwriteAnAlreadyPopulatedDestination() {
        try (JdbcDb old = original(); JdbcDb target = JdbcDb.memory()) {
            new LedgerRepo(target).createCard("Existing destination",1);
            try { LegacyUpgrade.migrate(old,target); fail(); } catch (IllegalStateException expected) { }
            assertEquals("Existing destination",new LedgerRepo(target).listCards().get(0).name);
            assertFalse(LegacyUpgrade.isComplete(target));
        }
    }
}
