package com.apkbench.app.core;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** {@link Db} backed by SQLite over JDBC, used to run the real schema and SQL in JVM tests. */
public final class JdbcDb implements Db, AutoCloseable {
    private final Connection c;
    private int depth;

    public JdbcDb(String url) {
        try {
            c = DriverManager.getConnection(url);
            try (Statement s = c.createStatement()) {
                s.execute("PRAGMA foreign_keys=ON");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static JdbcDb memory() {
        JdbcDb d = new JdbcDb("jdbc:sqlite::memory:");
        d.createSchema();
        return d;
    }

    /** Opens a file database, creating the schema when the file is new (like SQLiteOpenHelper.onCreate). */
    public static JdbcDb file(String path) {
        JdbcDb d = new JdbcDb("jdbc:sqlite:" + path);
        List<Row> v = d.query("PRAGMA user_version");
        long version = v.get(0).getLong("user_version");
        if (version == 0) {
            d.createSchema();
            d.exec("PRAGMA user_version = " + Schema.VERSION);
        } else if (version < Schema.VERSION) {
            d.transaction(() -> {
                for(String sql : Schema.upgradesFrom((int)version)) d.exec(sql);
                d.exec("PRAGMA user_version = " + Schema.VERSION);
            });
        }
        return d;
    }

    public void createSchema() {
        for (String sql : Schema.CREATE) exec(sql);
    }

    private PreparedStatement prepare(String sql, Object[] args) throws SQLException {
        PreparedStatement p = c.prepareStatement(sql);
        for (int i = 0; i < args.length; i++) {
            Object a = args[i];
            if (a == null) p.setNull(i + 1, java.sql.Types.NULL);
            else if (a instanceof Long) p.setLong(i + 1, (Long) a);
            else if (a instanceof Integer) p.setLong(i + 1, (Integer) a);
            else if (a instanceof Boolean) p.setLong(i + 1, ((Boolean) a) ? 1 : 0);
            else if (a instanceof byte[]) p.setBytes(i + 1, (byte[]) a);
            else p.setString(i + 1, a.toString());
        }
        return p;
    }

    @Override
    public long insert(String sql, Object... args) {
        try (PreparedStatement p = prepare(sql, args)) {
            p.executeUpdate();
            try (Statement s = c.createStatement(); ResultSet rs = s.executeQuery("SELECT last_insert_rowid()")) {
                rs.next();
                return rs.getLong(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    @Override
    public int exec(String sql, Object... args) {
        try (PreparedStatement p = prepare(sql, args)) {
            p.execute();
            return p.getUpdateCount();
        } catch (SQLException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    @Override
    public List<Row> query(String sql, Object... args) {
        try (PreparedStatement p = prepare(sql, args); ResultSet rs = p.executeQuery()) {
            ResultSetMetaData md = rs.getMetaData();
            String[] cols = new String[md.getColumnCount()];
            for (int i = 0; i < cols.length; i++) cols[i] = md.getColumnLabel(i + 1);
            Map<String, Integer> idx = Row.indexOf(cols);
            List<Row> out = new ArrayList<>();
            while (rs.next()) {
                Object[] vals = new Object[cols.length];
                for (int i = 0; i < cols.length; i++) vals[i] = rs.getObject(i + 1);
                out.add(new Row(idx, vals));
            }
            return out;
        } catch (SQLException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    @Override
    public void transaction(Runnable work) {
        try {
            if (depth == 0) c.setAutoCommit(false);
            depth++;
            boolean ok = false;
            try {
                work.run();
                ok = true;
            } finally {
                depth--;
                if (depth == 0) {
                    if (ok) c.commit(); else c.rollback();
                    c.setAutoCommit(true);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void close() {
        try { c.close(); } catch (SQLException ignored) { }
    }
}
