package com.apkbench.app.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import com.apkbench.app.core.Models.Rule;
import com.apkbench.app.core.Models.Txn;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.util.List;
import java.util.Map;

public class ImportExportTest {
    private JdbcDb db;
    private LedgerRepo repo;
    private final long today = CivilDate.of(2026, 10, 19);

    @Before public void setUp() {
        db = JdbcDb.memory();
        repo = new LedgerRepo(db);
    }

    @After public void tearDown() { db.close(); }

    private void seed(LedgerRepo r) {
        long a = r.createCard("Card \"A\" ✓", 31);
        long b = r.createCard("Card B", 5);
        r.addTxn(a, Models.TYPE_EXPENSE, Money.parse("1234.56"), CivilDate.of(2026, 10, 2), "Line\nbreak, \"quoted\"", "note\\slash");
        r.addTxn(a, Models.TYPE_EXPENSE, Money.parse("10.00"), CivilDate.of(2026, 10, 3), "Coffee", "");
        r.addTxn(a, Models.TYPE_EXPENSE, Money.parse("10.00"), CivilDate.of(2026, 10, 3), "Coffee", ""); // legit repeat
        r.addTxn(a, Models.TYPE_CASHBACK, Money.parse("0.01"), CivilDate.of(2026, 10, 4), "Cashback", "");
        long rule = r.createRule(a, "Rent", Money.parse("25000"), Recurrence.MONTHLY, CivilDate.of(2026, 8, 31), "flat");
        r.processDue(today);
        r.createRule(b, "Gym", Money.parse("999.99"), Recurrence.WEEKLY, CivilDate.of(2026, 11, 2), "");
        long paused = r.createRule(b, "Annual fee", Money.parse("500"), Recurrence.YEARLY, CivilDate.of(2024, 2, 29), "");
        r.pauseRule(paused, 6, today);
        assertTrue(rule > 0);
    }

    @Test public void exportImportRoundTrip() throws Exception {
        seed(repo);
        String json = LedgerTransfer.export(repo, today);
        Map<?, ?> parsed = (Map<?, ?>) Json.parse(json);
        assertEquals(LedgerTransfer.FORMAT, parsed.get("format"));
        assertFalse("vault must never be exported", json.contains("vault"));

        try (JdbcDb other = JdbcDb.memory()) {
            LedgerRepo fresh = new LedgerRepo(other);
            LedgerTransfer.Plan plan = LedgerTransfer.plan(fresh, json);
            assertEquals(2, plan.newCards());
            assertEquals(0, plan.duplicateTxns());
            assertEquals(3, plan.newRules());
            LedgerTransfer.apply(fresh, plan);
            assertEquals(LedgerTransfer.export(repo, today), LedgerTransfer.export(fresh, today));
            assertEquals(LedgerRepo.totalDue(repo.summaries()), LedgerRepo.totalDue(fresh.summaries()));
            // imported schedule continues without re-posting what the transactions already hold
            assertEquals(0, fresh.processDue(today));
            Rule paused = null;
            for (Rule r : fresh.listAllRules()) if (r.name.equals("Annual fee")) paused = r;
            assertTrue(paused.paused);
            assertEquals(Long.valueOf(CivilDate.addMonths(today, 6)), paused.pauseUntil);
        }
    }

    @Test public void reimportDetectsDuplicates() {
        seed(repo);
        String json = LedgerTransfer.export(repo, today);
        int before = db.query("SELECT * FROM txns").size();
        LedgerTransfer.Plan plan = LedgerTransfer.plan(repo, json);
        assertEquals(0, plan.newCards());
        assertEquals(2, plan.matchedCards());
        assertEquals(0, plan.newTxns());
        assertEquals(before, plan.duplicateTxns());
        assertEquals(0, plan.newRules());
        assertFalse(plan.hasChanges());
        LedgerTransfer.apply(repo, plan);
        assertEquals(before, db.query("SELECT * FROM txns").size());
    }

    @Test public void multisetDuplicateMatching() {
        long a = repo.createCard("Card", 1);
        repo.addTxn(a, 0, 1000, today, "Coffee", "");
        String json = "{\"format\":\"apkbench-ledger\",\"version\":1,\"cards\":[{\"name\":\"card\",\"billingDay\":9,"
                + "\"transactions\":["
                + "{\"type\":\"expense\",\"amount\":\"10.00\",\"date\":\"2026-10-19\",\"description\":\"Coffee\"},"
                + "{\"type\":\"expense\",\"amount\":10,\"date\":\"2026-10-19\",\"description\":\"coffee\"}]}]}";
        LedgerTransfer.Plan plan = LedgerTransfer.plan(repo, json);
        assertEquals(1, plan.duplicateTxns());
        assertEquals(1, plan.newTxns());
        assertEquals(1, plan.warnings.size()); // billing day differs
        LedgerTransfer.apply(repo, plan);
        assertEquals(2, repo.listTxns(a).size());
        assertEquals(1, repo.getCard(a).billingDay);
    }

    @Test public void invalidFilesWriteNothing() {
        seed(repo);
        String good = LedgerTransfer.export(repo, today);
        int txBefore = db.query("SELECT * FROM txns").size();
        String[] bad = {
                "not json",
                "{}",
                "[]",
                "{\"format\":\"other\",\"version\":1,\"cards\":[]}",
                "{\"format\":\"apkbench-ledger\",\"version\":99,\"cards\":[]}",
                "{\"format\":\"apkbench-ledger\",\"version\":1,\"cards\":[{\"name\":\"N\",\"billingDay\":32}]}",
                "{\"format\":\"apkbench-ledger\",\"version\":1,\"cards\":[{\"name\":\"N\",\"billingDay\":3,"
                        + "\"transactions\":[{\"type\":\"expense\",\"amount\":\"1.234\",\"date\":\"2026-10-01\"}]}]}",
                "{\"format\":\"apkbench-ledger\",\"version\":1,\"cards\":[{\"name\":\"N\",\"billingDay\":3,"
                        + "\"transactions\":[{\"type\":\"expense\",\"amount\":1.5e3,\"date\":\"2026-10-01\"}]}]}",
                "{\"format\":\"apkbench-ledger\",\"version\":1,\"cards\":[{\"name\":\"N\",\"billingDay\":3,"
                        + "\"transactions\":[{\"type\":\"expense\",\"amount\":\"-5\",\"date\":\"2026-10-01\"}]}]}",
                "{\"format\":\"apkbench-ledger\",\"version\":1,\"cards\":[{\"name\":\"N\",\"billingDay\":3,"
                        + "\"transactions\":[{\"type\":\"expense\",\"amount\":\"5\",\"date\":\"2026-02-30\"}]}]}",
                "{\"format\":\"apkbench-ledger\",\"version\":1,\"cards\":[{\"name\":\"N\",\"billingDay\":3,"
                        + "\"recurring\":[{\"name\":\"R\",\"amount\":\"5\",\"frequency\":\"daily\",\"startDate\":\"2026-02-01\"}]}]}",
                "{\"format\":\"apkbench-ledger\",\"version\":1,\"cards\":[{\"name\":\"Dup\",\"billingDay\":3},{\"name\":\"dup\",\"billingDay\":4}]}",
                "{\"format\":\"apkbench-saved-cards\",\"version\":1,\"cards\":[]}",
                good.substring(0, good.length() / 2),
        };
        for (String b : bad) {
            try {
                LedgerTransfer.plan(repo, b);
                fail("accepted: " + b);
            } catch (IllegalArgumentException expected) {
                assertTrue(expected.getMessage(), expected.getMessage().length() > 3);
            }
        }
        assertEquals(txBefore, db.query("SELECT * FROM txns").size());
    }

    @Test public void errorMessagesNameTheLocation() {
        String json = "{\"format\":\"apkbench-ledger\",\"version\":1,\"cards\":[{\"name\":\"N\",\"billingDay\":3,"
                + "\"transactions\":[{\"type\":\"expense\",\"amount\":\"5\",\"date\":\"2026-01-01\"},"
                + "{\"type\":\"refund\",\"amount\":\"5\",\"date\":\"2026-01-01\"}]}]}";
        try {
            LedgerTransfer.plan(repo, json);
            fail();
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage(), e.getMessage().startsWith("cards[0].transactions[1].type"));
        }
    }

    @Test public void applyIsAllOrNothing() {
        String json = "{\"format\":\"apkbench-ledger\",\"version\":1,\"cards\":["
                + "{\"name\":\"One\",\"billingDay\":3,\"transactions\":[{\"type\":\"expense\",\"amount\":\"5\",\"date\":\"2026-01-01\"}]},"
                + "{\"name\":\"Two\",\"billingDay\":3,\"transactions\":[{\"type\":\"expense\",\"amount\":\"7\",\"date\":\"2026-01-02\"}]}]}";
        LedgerTransfer.Plan plan = LedgerTransfer.plan(repo, json);
        db.exec("CREATE TRIGGER boom BEFORE INSERT ON txns WHEN NEW.amount = 700 BEGIN SELECT RAISE(ABORT,'x'); END");
        try {
            LedgerTransfer.apply(repo, plan);
            fail();
        } catch (RuntimeException expected) {
            // rolled back
        }
        assertTrue(repo.listCards().isEmpty());
        assertTrue(db.query("SELECT * FROM txns").isEmpty());
    }

    @Test public void persistenceAcrossReopen() throws Exception {
        File f = File.createTempFile("apkbench", ".db");
        f.delete();
        try {
            String exported;
            try (JdbcDb first = JdbcDb.file(f.getAbsolutePath())) {
                LedgerRepo r = new LedgerRepo(first);
                seed(r);
                exported = LedgerTransfer.export(r, today);
            }
            // "app restart": new connection, schema already present, data intact
            try (JdbcDb second = JdbcDb.file(f.getAbsolutePath())) {
                LedgerRepo r = new LedgerRepo(second);
                assertEquals(exported, LedgerTransfer.export(r, today));
                assertEquals((long) Schema.VERSION, second.query("PRAGMA user_version").get(0).getLong("user_version"));
                List<Txn> l = r.listTxns(r.findCardByName("Card B", -1).id);
                assertEquals(3, l.size()); // annual fee posted for 2024-2026 before pausing
                long c = r.findCardByName("card \"a\" ✓", -1).id;
                r.addTxn(c, 0, 1, today, "after restart", "");
            }
            try (JdbcDb third = JdbcDb.file(f.getAbsolutePath())) {
                LedgerRepo r = new LedgerRepo(third);
                long c = r.findCardByName("Card \"A\" ✓", -1).id;
                List<Txn> l = r.listTxns(c);
                assertEquals("after restart", l.get(l.size() - 1).description);
            }
        } finally {
            f.delete();
        }
    }

    @Test public void jsonParserAndWriter() throws Exception {
        String s = "{\"a\":[1,-2.50,3e2,true,false,null,\"x\\u00e9\\n\\\"q\\\"\"],\"b\":{}}";
        Map<?, ?> m = (Map<?, ?>) Json.parse(s);
        List<?> a = (List<?>) m.get("a");
        assertEquals(new Json.Num("-2.50"), a.get(1));
        assertEquals("xé\n\"q\"", a.get(6));
        assertEquals(m, Json.parse(Json.write(m)));
        String[] bad = {"{", "[1,]", "{\"a\" 1}", "01", "\"\\x\"", "nul", "[1] 2", "\"a\nb\""};
        for (String b : bad) {
            try { Json.parse(b); fail(b); } catch (Json.ParseException expected) { }
        }
        StringBuilder deep = new StringBuilder();
        for (int i = 0; i < 100; i++) deep.append('[');
        try { Json.parse(deep.toString()); fail(); } catch (Json.ParseException expected) { }
        assertEquals("ok", ((Map<?, ?>) Json.parse("\uFEFF{\"k\":\"ok\"}")).get("k"));
    }
}
