package com.apkbench.app.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Test;

public class MoneyDateTest {

    // ------------------------------------------------------------ money

    @Test public void parsesCommonForms() {
        assertEquals(123400, Money.parse("1234"));
        assertEquals(123450, Money.parse("1234.5"));
        assertEquals(123405, Money.parse("1234.05"));
        assertEquals(123450, Money.parse("1,234.50"));
        assertEquals(1234567800, Money.parse("1,23,45,678.00"));
        assertEquals(5, Money.parse("0.05"));
        assertEquals(50, Money.parse(".5"));
        assertEquals(1050, Money.parse("10,5"));      // decimal comma
        assertEquals(1050, Money.parse(" 10.50 "));
        assertEquals(0, Money.parse("0"));
    }

    @Test public void rejectsBadInput() {
        String[] bad = {"", "  ", "-5", "1.234", "abc", "1.2.3", "12a", "1e5", "1,2345", "99999999999999",
                ".", "1,234,5678.00"};
        for (String b : bad) {
            try {
                Money.parse(b);
                fail("accepted " + b);
            } catch (IllegalArgumentException expected) {
                // ok
            }
        }
        try { Money.parsePositive("0.00"); fail(); } catch (IllegalArgumentException expected) { }
    }

    @Test public void noFloatingPointDrift() {
        long sum = 0;
        for (int i = 0; i < 1000; i++) sum = Money.add(sum, Money.parse("0.10"));
        assertEquals(10000, sum);
        assertEquals("100.00", Money.toPlain(sum));
        assertEquals(30, Money.add(Money.parse("0.1"), Money.parse("0.2"))); // 0.30 exactly
        assertEquals("0.30", Money.toPlain(Money.add(Money.parse("0.1"), Money.parse("0.2"))));
    }

    @Test public void overflowIsDetected() {
        try { Money.add(Long.MAX_VALUE, 1); fail(); } catch (ArithmeticException expected) { }
        try { Money.sub(Long.MIN_VALUE, 1); fail(); } catch (ArithmeticException expected) { }
        try { Money.times(Long.MAX_VALUE / 2, 3); fail(); } catch (ArithmeticException expected) { }
        assertEquals(Money.MAX_INPUT * 52, Money.times(Money.MAX_INPUT, 52));
    }

    @Test public void formats() {
        assertEquals("₹1,23,45,678.90", Money.format(1234567890, "₹", true));
        assertEquals("$12,345,678.90", Money.format(1234567890, "$", false));
        assertEquals("₹0.05", Money.format(5, "₹", true));
        assertEquals("-$1,000.00", Money.format(-100000, "$", false));
        assertEquals("€999.00", Money.format(99900, "€", false));
        assertEquals("-12.30", Money.toPlain(-1230));
        assertEquals(Money.parse(Money.toPlain(987654321)), 987654321);
    }

    // ------------------------------------------------------------ dates

    @Test public void epochDayRoundTrip() {
        assertEquals(0, CivilDate.of(1970, 1, 1));
        assertEquals(20745, CivilDate.of(2026, 10, 19));
        for (long e = CivilDate.of(1900, 1, 1); e < CivilDate.of(2200, 1, 1); e += 17) {
            int[] p = CivilDate.ymd(e);
            assertEquals(e, CivilDate.of(p[0], p[1], p[2]));
        }
        assertEquals("2026-10-19", CivilDate.iso(CivilDate.parseIso("2026-10-19")));
    }

    @Test public void leapYears() {
        assertTrue(CivilDate.isLeap(2000));
        assertTrue(CivilDate.isLeap(2024));
        assertTrue(CivilDate.isLeap(2028));
        assertFalse(CivilDate.isLeap(1900));
        assertFalse(CivilDate.isLeap(2100));
        assertFalse(CivilDate.isLeap(2026));
        assertEquals(29, CivilDate.daysInMonth(2024, 2));
        assertEquals(28, CivilDate.daysInMonth(2026, 2));
        assertEquals(30, CivilDate.daysInMonth(2026, 4));
        try { CivilDate.of(2026, 2, 29); fail(); } catch (IllegalArgumentException expected) { }
        try { CivilDate.parseIso("2026-13-01"); fail(); } catch (IllegalArgumentException expected) { }
    }

    @Test public void weekdays() {
        assertEquals(0, CivilDate.dayOfWeek(CivilDate.of(2026, 10, 19))); // Monday
        assertEquals(3, CivilDate.dayOfWeek(0));                         // 1970-01-01 Thursday
        assertEquals("Sunday", CivilDate.weekdayName(CivilDate.of(2026, 10, 25)));
    }

    @Test public void addMonthsClampsAndKeepsAnchor() {
        long jan31 = CivilDate.of(2026, 1, 31);
        assertEquals(CivilDate.of(2026, 2, 28), CivilDate.addMonths(jan31, 1));
        assertEquals(CivilDate.of(2026, 3, 31), CivilDate.addMonths(jan31, 2, 31));
        assertEquals(CivilDate.of(2025, 12, 31), CivilDate.addMonths(jan31, -1));
        assertEquals(CivilDate.of(2028, 2, 29), CivilDate.addMonths(CivilDate.of(2027, 12, 31), 2, 31));
    }

    @Test public void ordinals() {
        assertEquals("1st", CivilDate.ordinal(1));
        assertEquals("2nd", CivilDate.ordinal(2));
        assertEquals("3rd", CivilDate.ordinal(3));
        assertEquals("11th", CivilDate.ordinal(11));
        assertEquals("22nd", CivilDate.ordinal(22));
        assertEquals("31st", CivilDate.ordinal(31));
    }

    // ------------------------------------------------------------ billing cycles

    @Test public void billingDayClampsToShortMonths() {
        assertEquals(CivilDate.of(2026, 2, 28), BillingCycle.statementIn(31, 2026, 2));
        assertEquals(CivilDate.of(2028, 2, 29), BillingCycle.statementIn(31, 2028, 2));
        assertEquals(CivilDate.of(2028, 2, 29), BillingCycle.statementIn(30, 2028, 2));
        assertEquals(CivilDate.of(2026, 4, 30), BillingCycle.statementIn(31, 2026, 4));
        assertEquals(CivilDate.of(2026, 5, 31), BillingCycle.statementIn(31, 2026, 5));
        assertEquals(CivilDate.of(2026, 6, 15), BillingCycle.statementIn(15, 2026, 6));
        try { BillingCycle.statementIn(0, 2026, 1); fail(); } catch (IllegalArgumentException expected) { }
        try { BillingCycle.statementIn(32, 2026, 1); fail(); } catch (IllegalArgumentException expected) { }
    }

    @Test public void nextAndPreviousStatement() {
        long oct19 = CivilDate.of(2026, 10, 19);
        assertEquals(CivilDate.of(2026, 10, 25), BillingCycle.nextStatement(25, oct19));
        assertEquals(CivilDate.of(2026, 10, 19), BillingCycle.nextStatement(19, oct19));
        assertEquals(CivilDate.of(2026, 11, 5), BillingCycle.nextStatement(5, oct19));
        assertEquals(CivilDate.of(2026, 9, 19), BillingCycle.previousStatement(19, oct19));
        // Dec -> Jan rollover
        assertEquals(CivilDate.of(2027, 1, 10), BillingCycle.nextStatement(10, CivilDate.of(2026, 12, 20)));
        // Jan 31 cycle at end of January 2027 -> next statement 28 Feb 2027
        assertEquals(CivilDate.of(2027, 2, 28), BillingCycle.nextStatement(31, CivilDate.of(2027, 2, 1)));
        long[] cyc = BillingCycle.currentCycle(31, CivilDate.of(2027, 3, 10));
        assertEquals(CivilDate.of(2027, 3, 1), cyc[0]);
        assertEquals(CivilDate.of(2027, 3, 31), cyc[1]);
        assertEquals(6, BillingCycle.daysUntilStatement(25, oct19));
    }
}
