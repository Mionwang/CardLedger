package com.apkbench.app.core;

import org.junit.Test;
import static org.junit.Assert.*;

public final class StartDateCommitmentTest {
    private static long d(String s){return CivilDate.parseIso(s);}
    private static final long TODAY=d("2026-10-19");
    private static final class Fixture implements AutoCloseable {
        final JdbcDb db=JdbcDb.memory(); final LedgerRepo repo=new LedgerRepo(db);
        final long card=repo.createCard("Test",10);
        long save(long id,int frequency,String start,String end,long today){
            return repo.saveRuleFromStart(id,card,"Instalment",10000,frequency,d(start),"",end==null?null:d(end),today);
        }
        Models.CardSummary summary(long today){return repo.summaries(today).get(0);}
        public void close(){db.close();}
    }
    @Test public void historicalStartInfersTodayWithoutAddingEarlierInstalments(){
        try(Fixture f=new Fixture()){
            long id=f.save(-1,Recurrence.MONTHLY,"2026-04-19","2026-12-19",TODAY);
            assertEquals(TODAY,f.repo.getRule(id).nextDate());assertTrue(f.repo.listTxns(f.card).isEmpty());
            assertEquals(1,f.repo.processDue(TODAY));assertEquals(10000,f.summary(TODAY).outstanding);
            assertEquals(d("2026-11-19"),f.repo.getRule(id).nextDate());
            assertEquals(0,f.repo.processDue(TODAY));
            assertEquals(20000,f.summary(TODAY).remainingCommitment);
        }
    }
    @Test public void passedChargingDayInfersNextMonth(){
        try(Fixture f=new Fixture()){
            long id=f.save(-1,Recurrence.MONTHLY,"2026-04-05","2026-12-05",TODAY);
            assertEquals(d("2026-11-05"),f.repo.getRule(id).nextDate());assertEquals(0,f.repo.processDue(TODAY));
            assertEquals(20000,f.summary(TODAY).remainingCommitment);
        }
    }
    @Test public void futureStartIsNotPulledEarlier(){
        try(Fixture f=new Fixture()){
            long id=f.save(-1,Recurrence.MONTHLY,"2027-02-15","2027-04-15",TODAY);
            assertEquals(d("2027-02-15"),f.repo.getRule(id).nextDate());assertEquals(0,f.repo.processDue(TODAY));
            assertEquals(30000,f.summary(TODAY).remainingCommitment);
        }
    }
    @Test public void endInThePastSavesEndedWithoutHistoricalCharges(){
        try(Fixture f=new Fixture()){
            long id=f.save(-1,Recurrence.MONTHLY,"2026-01-15","2026-06-15",TODAY);
            assertTrue(f.repo.getRule(id).hasEnded(TODAY));assertEquals(0,f.repo.processDue(TODAY));
            assertEquals(0,f.summary(TODAY).remainingCommitment);assertEquals(0,f.summary(TODAY).activeRuleCount);
        }
    }
    @Test public void februaryClamps31ThenReturnsTo31(){
        try(Fixture f=new Fixture()){
            long today=d("2027-02-01");long id=f.save(-1,Recurrence.MONTHLY,"2026-01-31","2027-04-30",today);
            assertEquals(d("2027-02-28"),f.repo.getRule(id).nextDate());
            assertEquals(1,f.repo.processDue(d("2027-02-28")));assertEquals(d("2027-03-31"),f.repo.getRule(id).nextDate());
            assertEquals(1,f.repo.processDue(d("2027-03-31")));assertEquals(d("2027-04-30"),f.repo.getRule(id).nextDate());
        }
    }
    @Test public void leapFebruaryClamps30To29ThenReturnsTo30(){
        try(Fixture f=new Fixture()){
            long id=f.save(-1,Recurrence.MONTHLY,"2027-01-30","2028-04-30",d("2028-02-01"));
            assertEquals(d("2028-02-29"),f.repo.getRule(id).nextDate());
            f.repo.processDue(d("2028-02-29"));assertEquals(d("2028-03-30"),f.repo.getRule(id).nextDate());
        }
    }
    @Test public void day28Stays28InLeapYear(){
        try(Fixture f=new Fixture()){
            long id=f.save(-1,Recurrence.MONTHLY,"2027-01-28",null,d("2028-02-01"));
            assertEquals(d("2028-02-28"),f.repo.getRule(id).nextDate());
        }
    }
    @Test public void unchangedStartPreservesCursorPostedHistoryAndPause(){
        try(Fixture f=new Fixture()){
            long id=f.save(-1,Recurrence.MONTHLY,"2026-04-19","2026-12-19",TODAY);f.repo.processDue(TODAY);
            long txn=f.repo.listTxns(f.card).get(0).id;long index=f.repo.getRule(id).nextIndex;
            f.repo.pauseRule(id,2,TODAY);
            f.save(id,Recurrence.MONTHLY,"2026-04-19","2027-01-19",TODAY);
            assertEquals(index,f.repo.getRule(id).nextIndex);assertTrue(f.repo.getRule(id).paused);
            assertEquals(Long.valueOf(d("2026-12-19")),f.repo.getRule(id).pauseUntil);
            assertNotNull(f.repo.getTxn(txn));assertEquals(0,f.repo.processDue(TODAY));
        }
    }
    @Test public void correctingStartPreservesHistoryAndDoesNotRepostToday(){
        try(Fixture f=new Fixture()){
            long id=f.save(-1,Recurrence.MONTHLY,"2026-04-19","2026-12-19",TODAY);f.repo.processDue(TODAY);
            long txn=f.repo.listTxns(f.card).get(0).id;
            Models.Rule preview=f.repo.previewRuleFromStart(id,Recurrence.MONTHLY,d("2025-04-19"),d("2026-12-19"),TODAY);
            f.save(id,Recurrence.MONTHLY,"2025-04-19","2026-12-19",TODAY);
            assertEquals(preview.nextDate(),f.repo.getRule(id).nextDate());assertEquals(d("2026-11-19"),preview.nextDate());
            assertEquals(0,f.repo.processDue(TODAY));assertNotNull(f.repo.getTxn(txn));assertEquals(1,f.repo.listTxns(f.card).size());
        }
    }
    @Test public void extendingEndInfersUpcomingDateWithoutRevivingPastGap(){
        try(Fixture f=new Fixture()){
            long id=f.save(-1,Recurrence.MONTHLY,"2026-04-19","2026-08-19",d("2026-08-19"));f.repo.processDue(d("2026-08-19"));
            f.save(id,Recurrence.MONTHLY,"2026-04-19","2026-12-19",TODAY);
            assertEquals(TODAY,f.repo.getRule(id).nextDate());assertEquals(1,f.repo.processDue(TODAY));
            assertEquals(2,f.repo.listTxns(f.card).size());assertEquals(d("2026-08-19"),f.repo.listTxns(f.card).get(0).date);
        }
    }
    @Test public void automaticCatchUpStillWorksAfterSetupAndStopsAtEnd(){
        try(Fixture f=new Fixture()){
            f.save(-1,Recurrence.MONTHLY,"2026-04-19","2026-12-19",TODAY);f.repo.processDue(TODAY);
            assertEquals(2,f.repo.processDue(d("2027-02-01")));assertEquals(30000,f.summary(d("2027-02-01")).outstanding);
            assertEquals(0,f.repo.processDue(d("2027-03-01")));
        }
    }
    @Test public void durationTotalsSeparateLimitedRemainingAndUnlimitedAnnual(){
        try(Fixture f=new Fixture()){
            f.save(-1,Recurrence.MONTHLY,"2026-01-20","2027-02-20",TODAY);
            f.save(-1,Recurrence.MONTHLY,"2026-01-20",null,TODAY);
            Models.CardSummary s=f.summary(TODAY);
            assertEquals(50000,s.remainingCommitment);assertEquals(120000,s.unlimitedAnnualCommitment);
            assertEquals(1,s.limitedRuleCount);assertEquals(1,s.unlimitedRuleCount);assertEquals(170000,s.annualCommitment);
        }
    }
    @Test public void longPlansShowAllRemainingButSortingUsesNextYear(){
        try(Fixture f=new Fixture()){
            f.save(-1,Recurrence.MONTHLY,"2026-01-20","2028-10-20",TODAY);
            assertEquals(250000,f.summary(TODAY).remainingCommitment);assertEquals(120000,f.summary(TODAY).annualCommitment);
        }
    }
    @Test public void weeklyAndYearlyStartInferenceAndInclusiveTotals(){
        try(Fixture f=new Fixture()){
            long weekly=f.save(-1,Recurrence.WEEKLY,"2026-10-05","2026-11-02",TODAY);
            long yearly=f.save(-1,Recurrence.YEARLY,"2024-02-29","2028-02-29",TODAY);
            assertEquals(TODAY,f.repo.getRule(weekly).nextDate());assertEquals(d("2027-02-28"),f.repo.getRule(yearly).nextDate());
            assertEquals(50000,f.summary(TODAY).remainingCommitment);
        }
    }
    @Test public void pausedRulesAreExcludedFromCommitments(){
        try(Fixture f=new Fixture()){
            long id=f.save(-1,Recurrence.MONTHLY,"2026-01-20","2027-02-20",TODAY);f.repo.pauseRule(id,2,TODAY);
            assertEquals(0,f.summary(TODAY).remainingCommitment);assertEquals(0,f.summary(TODAY).annualCommitment);
            assertEquals(1,f.summary(TODAY).pausedRuleCount);
        }
    }
    @Test public void invalidStartEndEditIsAtomic(){
        try(Fixture f=new Fixture()){
            long id=f.save(-1,Recurrence.MONTHLY,"2026-04-19","2026-12-19",TODAY);f.repo.processDue(TODAY);
            long index=f.repo.getRule(id).nextIndex;
            try{f.save(id,Recurrence.MONTHLY,"2027-01-19","2026-12-19",TODAY);fail();}catch(IllegalArgumentException expected){}
            assertEquals(d("2026-04-19"),f.repo.getRule(id).startDate);assertEquals(index,f.repo.getRule(id).nextIndex);
            assertEquals(1,f.repo.listTxns(f.card).size());assertNotNull(f.repo.listTxns(f.card).get(0).occurrence);
        }
    }
}
