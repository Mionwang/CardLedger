package com.apkbench.app;

import com.apkbench.app.core.*;
import javax.crypto.spec.SecretKeySpec;
import org.junit.Test;
import static org.junit.Assert.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public final class LegacyCryptoCompatibilityTest {
    @Test public void originalEncryptedCardsStayByteIdenticalAndReadableAfterMigration() throws Exception {
        final byte[] key = new byte[32];
        Arrays.fill(key,(byte) 39);
        String json = "{\"bank\":\"Test bank\",\"product\":\"Legacy\",\"holder\":\"Synthetic Person\","
                + "\"number\":\"4111111111111111\",\"expiry\":\"12/35\",\"network\":\"Visa\",\"cvv\":\"007\"}";
        byte[] blob = LegacyCrypto.seal(key,json.getBytes(StandardCharsets.UTF_8));
        try (JdbcDb old = LegacyUpgradeTest.original(); JdbcDb target = JdbcDb.memory()) {
            old.insert("INSERT INTO saved_cards VALUES(77,?)",blob);
            LegacyUpgrade.migrate(old,target);
            VaultCipher cipher = new VaultCipher(() -> new SecretKeySpec(key,"AES"));
            VaultRepo vault = new VaultRepo(target,cipher);
            CardInfo card = vault.get(77);
            assertNotNull(card);
            assertEquals("4111111111111111",card.number);
            assertEquals("007",card.cvv);
            assertEquals("12/35",card.expiry());
            Db.Row row = target.query("SELECT * FROM vault WHERE id=77").get(0);
            assertArrayEquals(Arrays.copyOfRange(blob,1,13),row.getBlob("iv"));
            assertArrayEquals(Arrays.copyOfRange(blob,13,blob.length),row.getBlob("data"));
            assertArrayEquals(blob,old.query("SELECT payload FROM saved_cards").get(0).getBlob("payload"));
            // New writes still use the same original key and authenticated-data string.
            VaultCipher.Sealed sealed = cipher.encrypt("compatibility".getBytes(StandardCharsets.UTF_8));
            byte[] packed = new byte[13+sealed.data.length]; packed[0]=1;
            System.arraycopy(sealed.iv,0,packed,1,12); System.arraycopy(sealed.data,0,packed,13,sealed.data.length);
            assertEquals("compatibility",new String(LegacyCrypto.open(key,packed),StandardCharsets.UTF_8));
        }
    }

    @Test public void legacyRecordsWithoutExpiryOrCvvStillOpen() throws Exception {
        byte[] key = new byte[32];
        String json = "{\"bank\":\"Test\",\"product\":\"\",\"holder\":\"\",\"number\":\"4111111111111111\",\"expiry\":\"\"}";
        try (JdbcDb old = LegacyUpgradeTest.original(); JdbcDb target = JdbcDb.memory()) {
            old.insert("INSERT INTO saved_cards VALUES(1,?)",LegacyCrypto.seal(key,json.getBytes(StandardCharsets.UTF_8)));
            LegacyUpgrade.migrate(old,target);
            CardInfo card = new VaultRepo(target,new VaultCipher(() -> new SecretKeySpec(key,"AES"))).get(1);
            assertNotNull(card);
            assertEquals("",card.expiry());
            assertEquals("",card.cvv);
        }
    }
}
