package com.apkbench.app.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class CurrencyTest {
    @Test public void simCountryMapping() {
        assertEquals("INR", Currencies.forCountry("in"));
        assertEquals("USD", Currencies.forCountry("US"));
        assertEquals("GBP", Currencies.forCountry("gb"));
        assertEquals("EUR", Currencies.forCountry("de"));
        assertEquals("AED", Currencies.forCountry("ae"));
        assertEquals("JPY", Currencies.forCountry("jp"));
    }

    @Test public void fallsBackToInr() {
        assertEquals("INR", Currencies.forCountry(null));
        assertEquals("INR", Currencies.forCountry(""));
        assertEquals("INR", Currencies.forCountry("zz"));
        assertEquals("INR", Currencies.forCountry("xyz"));
        assertEquals("INR", Currencies.resolve(Currencies.AUTO, null));
    }

    @Test public void manualOverrideWins() {
        assertEquals("EUR", Currencies.resolve("EUR", "in"));
        assertEquals("USD", Currencies.resolve(Currencies.AUTO, "us"));
    }

    @Test public void requiredCurrenciesPresent() {
        for (String c : new String[]{"INR", "USD", "EUR", "GBP", "AED", "CAD", "AUD", "JPY"}) {
            assertNotNull(c, Currencies.find(c));
        }
        assertTrue(Currencies.LIST.length > 8);
        assertEquals("₹", Currencies.symbol("INR"));
    }

    @Test public void switchingCurrencyChangesOnlyTheSymbol() {
        long v = Money.parse("123456.78");
        assertEquals("₹1,23,456.78", Money.format(v, Currencies.symbol("INR"), Currencies.indianGrouping("INR")));
        assertEquals("$123,456.78", Money.format(v, Currencies.symbol("USD"), Currencies.indianGrouping("USD")));
        assertEquals("¥123,456.78", Money.format(v, Currencies.symbol("JPY"), false));
        assertEquals(12345678, v); // stored value untouched
    }
}
