package com.apkbench.app.core;

import java.util.Random;

/**
 * Generates synthetic, checksum-valid card numbers for tests so no real or
 * published example card numbers appear anywhere in the project.
 */
final class TestCards {
    private TestCards() {}

    private static final Random RND = new Random(20261019L);

    static String make(String prefix, int length) {
        StringBuilder b = new StringBuilder(prefix);
        while (b.length() < length - 1) b.append(RND.nextInt(10));
        for (int check = 0; check <= 9; check++) {
            String candidate = b.toString() + check;
            if (CardInfo.luhn(candidate)) return candidate;
        }
        throw new IllegalStateException();
    }

    /** Same digits with the last one altered, so the checksum fails. */
    static String broken(String valid) {
        char last = valid.charAt(valid.length() - 1);
        char other = last == '9' ? '0' : (char) (last + 1);
        return valid.substring(0, valid.length() - 1) + other;
    }
}
