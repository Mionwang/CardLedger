package com.apkbench.app.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import com.apkbench.app.core.Models.CardSummary;
import com.apkbench.app.core.Models.Rule;
import com.apkbench.app.core.Models.Txn;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

public class RecurrenceLedgerTest {
    private JdbcDb db;
    private LedgerRepo repo;

    private static long d(int y, int m, int day) { return CivilDate.of(y, m, day); }

    @Before public void setUp() {
        db = JdbcDb.memory();
        repo = new LedgerRepo(db);
    }

    @After public void tearDown() { db.close(); }

    // ------------------------------------------------------------ pure schedule math

    @Test public void monthlyMonthEndDoesNotDrift() {
        long start = d(2026, 1, 31);
        int f = Recurrence.MONTHLY;
        assertEquals(d(2026, 1, 31), Recurrence.occurrence(f, start, 31, 0));
        assertEquals(d(2026, 2, 28), Recurrence.occurrence(f, start, 31, 1));
        assertEquals(d(2026, 3, 31), Recurrence.occurrence(f, start, 31, 2));
        assertEquals(d(2026, 4, 30), Recurrence.occurrence(f, start, 31, 3));
        assertEquals(d(2026, 5, 31), Recurrence.occurrence(f, start, 31, 4));
        assertEquals(d(2028, 2, 29), Recurrence.occurrence(f, start, 31, 25));
        assertEquals(d(2027, 1, 31), Recurrence.occurrence(f, start, 31, 12));
    }

    @Test public void yearlyLeapDay() {
        long start = d(2024, 2, 29);
        int f = Recurrence.YEARLY;
        assertEquals(d(2025, 2, 28), Recurrence.occurrence(f, start, 29, 1));
        assertEquals(d(2027, 2, 28), Recurrence.occurrence(f, start, 29, 3));
        assertEquals(d(2028, 2, 29), Recurrence.occurrence(f, start, 29, 4));
        assertEquals(d(2100, 2, 28), Recurrence.occurrence(f, start, 29, 76)); // 2100 not leap
        assertEquals("Yearly on 29 Feb", Recurrence.describe(f, start, 29));
    }

    @Test public void weekly() {
        long start = d(2026, 10, 19);
        assertEquals(d(2026, 10, 26), Recurrence.occurrence(Recurrence.WEEKLY, start, 19, 1));
        assertEquals(d(2027, 1, 4), Recurrence.occurrence(Recurrence.WEEKLY, start, 19, 11));
        assertEquals(1, Recurrence.firstIndexOnOrAfter(Recurrence.WEEKLY, start, 19, 0, d(2026, 10, 20)));
        assertEquals(1, Recurrence.firstIndexOnOrAfter(Recurrence.WEEKLY, start, 19, 0, d(2026, 10, 26)));
        assertEquals(2, Recurrence.firstIndexOnOrAfter(Recurrence.WEEKLY, start, 19, 0, d(2026, 10, 27)));
        assertEquals("Weekly on Monday", Recurrence.describe(Recurrence.WEEKLY, start, 19));
    }

    @Test public void annualizedCommitment() {
        assertEquals(5200, Recurrence.annualized(Recurrence.WEEKLY, 100));
        assertEquals(1200, Recurrence.annualized(Recurrence.MONTHLY, 100));
        assertEquals(100, Recurrence.annualized(Recurrence.YEARLY, 100));
    }

    // ------------------------------------------------------------ ledger

    @Test public void balancesWithCashback() {
        long c = repo.createCard("Card A", 15);
        repo.addTxn(c, Models.TYPE_EXPENSE, Money.parse("1000.10"), d(2026, 10, 1), "Groceries", "");
        repo.addTxn(c, Models.TYPE_EXPENSE, Money.parse("0.20"), d(2026, 10, 2), "Gum", "");
        repo.addTxn(c, Models.TYPE_CASHBACK, Money.parse("50.05"), d(2026, 10, 3), "Cashback", "");
        CardSummary s = repo.summary(c);
        assertEquals(100030, s.expenses);
        assertEquals(5005, s.cashback);
        assertEquals(95025, s.outstanding);
        assertEquals("950.25", Money.toPlain(s.outstanding));
        long c2 = repo.createCard("Card B", 1);
        repo.addTxn(c2, Models.TYPE_EXPENSE, 100, d(2026, 10, 3), "", "");
        assertEquals(95125, LedgerRepo.totalDue(repo.summaries()));
    }

    @Test public void transactionsAreChronological() {
        long c = repo.createCard("Card", 5);
        repo.addTxn(c, 0, 100, d(2026, 10, 9), "third", "");
        repo.addTxn(c, 0, 100, d(2026, 10, 1), "first", "");
        repo.addTxn(c, 1, 100, d(2026, 10, 5), "second", "");
        List<Txn> l = repo.listTxns(c);
        assertEquals("first", l.get(0).description);
        assertEquals("second", l.get(1).description);
        assertEquals("third", l.get(2).description);
    }

    @Test public void editAndDeleteTransaction() {
        long c = repo.createCard("Card", 5);
        long t = repo.addTxn(c, 0, 100, d(2026, 10, 9), "x", "n");
        repo.updateTxn(t, Models.TYPE_CASHBACK, 250, d(2026, 10, 10), "y", "m");
        Txn x = repo.getTxn(t);
        assertEquals(1, x.type);
        assertEquals(250, x.amount);
        assertEquals("y", x.description);
        assertEquals("m", x.note);
        assertEquals(-250, repo.summary(c).outstanding);
        repo.deleteTxn(t);
        assertNull(repo.getTxn(t));
        assertEquals(0, repo.summary(c).outstanding);
    }

    @Test public void cardValidationAndRename() {
        long c = repo.createCard("  My   Card ", 31);
        assertEquals("My Card", repo.getCard(c).name);
        try { repo.createCard("my card", 3); fail("duplicate allowed"); } catch (IllegalArgumentException e) { }
        try { repo.createCard("X", 0); fail(); } catch (IllegalArgumentException e) { }
        try { repo.createCard("X", 32); fail(); } catch (IllegalArgumentException e) { }
        try { repo.createCard("  ", 3); fail(); } catch (IllegalArgumentException e) { }
        repo.updateCard(c, "Renamed", 30);
        assertEquals("Renamed", repo.getCard(c).name);
        assertEquals(30, repo.getCard(c).billingDay);
        try { repo.addTxn(c, 0, 0, 1, "", ""); fail("zero amount"); } catch (IllegalArgumentException e) { }
    }

    @Test public void deleteCardCascades() {
        long c = repo.createCard("Card", 5);
        repo.addTxn(c, 0, 100, d(2026, 10, 9), "", "");
        repo.createRule(c, "Sub", 100, Recurrence.MONTHLY, d(2026, 11, 1), "");
        repo.deleteCard(c);
        assertTrue(db.query("SELECT * FROM txns").isEmpty());
        assertTrue(db.query("SELECT * FROM rules").isEmpty());
    }

    @Test public void sortingByBalanceThenRecurringThenCommitment() {
        long a = repo.createCard("Alpha", 1);
        long b = repo.createCard("Bravo", 1);
        long c = repo.createCard("Charlie", 1);
        long dd = repo.createCard("Delta", 1);
        long e = repo.createCard("Echo", 1);
        long today = d(2026, 10, 19);
        repo.addTxn(e, 0, 999999, today, "", "");               // highest balance
        for (long id : new long[]{a, b, c, dd}) repo.addTxn(id, 0, 5000, today, "", "");
        // equal balances: b has big commitment, c small, d paused rule only, a none
        repo.createRule(b, "Big", 10000, Recurrence.MONTHLY, d(2027, 1, 1), "");
        repo.createRule(c, "Small", 100, Recurrence.WEEKLY, d(2027, 1, 1), "");
        long pausedRule = repo.createRule(dd, "Huge", 9999999, Recurrence.YEARLY, d(2027, 1, 1), "");
        repo.pauseRule(pausedRule, 0, today);
        List<CardSummary> s = repo.summaries();
        assertEquals("Echo", s.get(0).card.name);
        assertEquals("Bravo", s.get(1).card.name);   // 120,000 annual
        assertEquals("Charlie", s.get(2).card.name); // 5,200 annual
        assertEquals("Alpha", s.get(3).card.name);   // no active rule, name order
        assertEquals("Delta", s.get(4).card.name);
        assertFalse(s.get(4).hasActiveRecurring());
    }

    @Test public void markPaidClearsTransactionsKeepsRules() {
        long c = repo.createCard("Card", 5);
        repo.createRule(c, "Rent", 50000, Recurrence.MONTHLY, d(2026, 9, 1), "");
        repo.addTxn(c, 0, 100, d(2026, 10, 9), "", "");
        repo.processDue(d(2026, 10, 19));
        assertEquals(3, repo.listTxns(c).size()); // Sep 1, Oct 1, manual
        assertEquals(3, repo.markPaid(c));
        assertEquals(0, repo.summary(c).outstanding);
        assertEquals(1, repo.listRules(c).size());
        // Already-posted occurrences are not re-added after paying
        assertEquals(0, repo.processDue(d(2026, 10, 19)));
        assertEquals(1, repo.processDue(d(2026, 11, 1)));
        assertEquals(50000, repo.summary(c).outstanding);
    }

    @Test public void catchUpPostsMissedOccurrencesOnce() {
        long c = repo.createCard("Card", 5);
        long r = repo.createRule(c, "Gym", 1500, Recurrence.WEEKLY, d(2026, 9, 7), "");
        assertEquals(7, repo.processDue(d(2026, 10, 19))); // Sep 7,14,21,28, Oct 5,12,19
        assertEquals(0, repo.processDue(d(2026, 10, 19)));
        assertEquals(0, repo.processDue(d(2026, 10, 25)));
        assertEquals(1, repo.processDue(d(2026, 10, 26)));
        assertEquals(8 * 1500, repo.summary(c).outstanding);
        Rule rule = repo.getRule(r);
        assertEquals(d(2026, 11, 2), rule.nextDate());
        // descriptions come from the rule
        assertEquals("Gym", repo.listTxns(c).get(0).description);
        assertNotNull(repo.listTxns(c).get(0).recurringId);
    }

    @Test public void futureStartNotChargedEarly() {
        long c = repo.createCard("Card", 5);
        repo.createRule(c, "Insurance", 120000, Recurrence.YEARLY, d(2027, 3, 1), "");
        assertEquals(0, repo.processDue(d(2026, 10, 19)));
        assertEquals(1, repo.processDue(d(2027, 3, 1)));
    }

    @Test public void monthEndRecurringInLeapYear() {
        long c = repo.createCard("Card", 5);
        repo.createRule(c, "EOM", 100, Recurrence.MONTHLY, d(2027, 12, 31), "");
        repo.processDue(d(2028, 3, 31));
        List<Txn> l = repo.listTxns(c);
        assertEquals(4, l.size());
        assertEquals(d(2027, 12, 31), l.get(0).date);
        assertEquals(d(2028, 1, 31), l.get(1).date);
        assertEquals(d(2028, 2, 29), l.get(2).date);
        assertEquals(d(2028, 3, 31), l.get(3).date);
    }

    @Test public void indefinitePauseSkipsWithoutRetroCharge() {
        long c = repo.createCard("Card", 5);
        long r = repo.createRule(c, "Stream", 64900, Recurrence.MONTHLY, d(2026, 8, 10), "");
        repo.pauseRule(r, 0, d(2026, 10, 20)); // posts Aug, Sep, Oct first
        assertEquals(3, repo.listTxns(c).size());
        assertNull(repo.getRule(r).effectiveNextDate());
        assertEquals(0, repo.processDue(d(2027, 2, 1)));
        repo.resumeRule(r, d(2027, 2, 15)); // Nov..Feb 10 skipped
        assertEquals(3, repo.listTxns(c).size());
        assertEquals(d(2027, 3, 10), repo.getRule(r).nextDate());
        assertEquals(1, repo.processDue(d(2027, 3, 10)));
        assertEquals(4, repo.listTxns(c).size());
    }

    @Test public void resumeOnPaymentDayChargesThatDay() {
        long c = repo.createCard("Card", 5);
        long r = repo.createRule(c, "X", 100, Recurrence.MONTHLY, d(2026, 11, 10), "");
        repo.pauseRule(r, 0, d(2026, 10, 19));
        repo.resumeRule(r, d(2027, 1, 10));
        assertEquals(1, repo.listTxns(c).size());
        assertEquals(d(2027, 1, 10), repo.listTxns(c).get(0).date);
    }

    @Test public void timedPauseAutoResumes() {
        long c = repo.createCard("Card", 5);
        long r = repo.createRule(c, "Music", 11900, Recurrence.MONTHLY, d(2026, 11, 5), "");
        repo.pauseRule(r, 3, d(2026, 10, 19)); // until 2027-01-19
        Rule rule = repo.getRule(r);
        assertTrue(rule.paused);
        assertEquals(Long.valueOf(d(2027, 1, 19)), rule.pauseUntil);
        assertEquals(Long.valueOf(d(2027, 2, 5)), rule.effectiveNextDate());
        assertEquals(0, repo.processDue(d(2027, 1, 18)));
        assertTrue(repo.getRule(r).paused);
        // app not opened until April: Nov/Dec/Jan skipped, Feb/Mar/Apr charged
        assertEquals(3, repo.processDue(d(2027, 4, 6)));
        rule = repo.getRule(r);
        assertFalse(rule.paused);
        assertNull(rule.pauseUntil);
        List<Txn> l = repo.listTxns(c);
        assertEquals(d(2027, 2, 5), l.get(0).date);
        assertEquals(d(2027, 4, 5), l.get(2).date);
    }

    @Test public void timedPauseFromMonthEnd() {
        long c = repo.createCard("Card", 5);
        long r = repo.createRule(c, "Y", 100, Recurrence.WEEKLY, d(2026, 1, 5), "");
        repo.pauseRule(r, 1, d(2026, 1, 31)); // until 28 Feb 2026 (clamped)
        assertEquals(Long.valueOf(d(2026, 2, 28)), repo.getRule(r).pauseUntil);
    }

    @Test public void editRuleRescheduleOrAmount() {
        long c = repo.createCard("Card", 5);
        long r = repo.createRule(c, "Old", 100, Recurrence.MONTHLY, d(2026, 9, 1), "");
        repo.processDue(d(2026, 10, 19));
        Rule before = repo.getRule(r);
        assertEquals(d(2026, 11, 1), before.nextDate());
        // amount-only edit keeps schedule
        repo.updateRule(r, "New", 200, Recurrence.MONTHLY, before.nextDate(), "note");
        Rule after = repo.getRule(r);
        assertEquals(d(2026, 11, 1), after.nextDate());
        assertEquals(200, after.amount);
        assertEquals("New", after.name);
        // reschedule to weekly from Nov 3
        repo.updateRule(r, "New", 200, Recurrence.WEEKLY, d(2026, 11, 3), "");
        after = repo.getRule(r);
        assertEquals(Recurrence.WEEKLY, after.frequency);
        assertEquals(d(2026, 11, 3), after.nextDate());
        assertEquals(0, repo.processDue(d(2026, 11, 2)));
        assertEquals(2, repo.processDue(d(2026, 11, 10)));
        // deleting the rule keeps posted transactions
        int n = repo.listTxns(c).size();
        repo.deleteRule(r);
        assertEquals(n, repo.listTxns(c).size());
        assertNull(repo.listTxns(c).get(0).recurringId);
    }

    @Test public void processDueIsAtomic() {
        long c = repo.createCard("Card", 5);
        repo.createRule(c, "A", 100, Recurrence.MONTHLY, d(2026, 1, 1), "");
        db.exec("CREATE TRIGGER boom BEFORE INSERT ON txns WHEN NEW.date = " + d(2026, 5, 1)
                + " BEGIN SELECT RAISE(ABORT, 'boom'); END");
        try {
            repo.processDue(d(2026, 10, 19));
            fail();
        } catch (RuntimeException expected) {
            // rolled back
        }
        assertEquals(0, repo.listTxns(c).size());
        assertEquals(0, repo.listRules(c).get(0).nextIndex);
    }
}
