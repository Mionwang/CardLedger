package com.apkbench.app.core;

import org.junit.Test;
import static org.junit.Assert.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public final class CardLinksTest {
    private static final long TODAY=CivilDate.parseIso("2026-10-19");
    private static final class Fixture implements AutoCloseable {
        final JdbcDb db=JdbcDb.memory(); final LedgerRepo ledger=new LedgerRepo(db); final CardLinks links=new CardLinks(db);
        final List<CardInfo> saved=new ArrayList<>();
        CardInfo save(String bank,String product) {
            CardInfo c=new CardInfo();c.bank=bank;c.product=product;
            // Linking does not decrypt fields; ciphertext placeholders stand in for existing vault rows.
            c.id=db.insert("INSERT INTO vault(iv,data,created_at,updated_at) VALUES(?,?,0,0)",new byte[12],new byte[16]);
            saved.add(c);return c;
        }
        long expense(long card,long amount){return ledger.addTxn(card,Models.TYPE_EXPENSE,amount,TODAY,"Expense","");}
        long total(){return LedgerRepo.totalDue(ledger.summaries());}
        @Override public void close(){db.close();}
    }

    @Test public void exactCompositeMatchLinksWithoutCopyingOrChangingHistory() {
        try(Fixture f=new Fixture()) {
            long id=f.ledger.createCard("HDFC - Millennia",12);long txn=f.expense(id,10001);
            CardInfo c=f.save("hdfc","Millennia");f.links.sync(f.saved);
            assertEquals(id,f.links.forSaved(c.id).ledgerId);assertEquals("auto",f.links.forSaved(c.id).status);
            assertEquals(1,f.ledger.listCards().size());assertEquals(10001,f.total());assertEquals(id,f.ledger.getTxn(txn).cardId);
            assertEquals(12,f.ledger.getCard(id).billingDay);
        }
    }
    @Test public void newSavedCardsAppearAtZeroWithNoInventedBillingDayAndSyncIsIdempotent() {
        try(Fixture f=new Fixture()) {
            CardInfo c=f.save("ICICI","Amazon Pay");f.links.sync(f.saved);long id=f.links.forSaved(c.id).ledgerId;
            assertEquals(0,f.ledger.getCard(id).billingDay);assertEquals(0,f.ledger.summary(id).outstanding);
            assertEquals("new",f.links.forSaved(c.id).status);f.links.sync(f.saved);f.links.sync(f.saved);
            assertEquals(1,f.ledger.listCards().size());assertEquals(id,f.links.forSaved(c.id).ledgerId);
        }
    }
    @Test public void duplicateSavedNamesNeverAutoChooseOneAndHaveUniqueGeneratedLedgers() {
        try(Fixture f=new Fixture()) {
            long old=f.ledger.createCard("HDFC Millennia",1);f.expense(old,100);
            CardInfo a=f.save("HDFC","Millennia"),b=f.save("HDFC","Millennia");f.links.sync(f.saved);
            assertNotEquals(old,f.links.forSaved(a.id).ledgerId);assertNotEquals(old,f.links.forSaved(b.id).ledgerId);
            assertNotEquals(f.links.forSaved(a.id).ledgerId,f.links.forSaved(b.id).ledgerId);
            assertTrue(f.links.forSaved(a.id).needsReview());assertTrue(f.links.forSaved(b.id).needsReview());
            assertEquals(100,f.total());assertEquals(3,f.ledger.listCards().size());
        }
    }
    @Test public void multipleNormalizedLedgerMatchesAreQueuedForReview() {
        try(Fixture f=new Fixture()) {
            f.ledger.createCard("HDFC Millennia",1);f.ledger.createCard("HDFC-Millennia",2);
            CardInfo c=f.save("HDFC","Millennia");f.links.sync(f.saved);
            assertTrue(f.links.forSaved(c.id).needsReview());assertEquals(3,f.ledger.listCards().size());
        }
    }
    @Test public void bankOnlyAndNetworkOnlyNamesDoNotAutoLink() {
        try(Fixture f=new Fixture()) {
            long bank=f.ledger.createCard("HDFC",1),network=f.ledger.createCard("Visa",1);
            CardInfo a=f.save("HDFC",""),b=f.save("","Visa");f.links.sync(f.saved);
            assertNotEquals(bank,f.links.forSaved(a.id).ledgerId);assertNotEquals(network,f.links.forSaved(b.id).ledgerId);
        }
    }
    @Test public void partialMatchesDoNotSilentlyCombineBalances() {
        try(Fixture f=new Fixture()) {
            long id=f.ledger.createCard("Travel Millennia",1);f.expense(id,1234);
            CardInfo c=f.save("HDFC","Millennia");f.links.sync(f.saved);
            assertNotEquals(id,f.links.forSaved(c.id).ledgerId);assertTrue(f.links.forSaved(c.id).needsReview());assertEquals(1234,f.total());
        }
    }
    @Test public void confirmedLinkConsolidatesOnlyAnUntouchedAutoCreatedEmptyLedger() {
        try(Fixture f=new Fixture()) {
            long target=f.ledger.createCard("Travel",16);long t=f.expense(target,5000);
            CardInfo c=f.save("HDFC","Millennia");f.links.sync(f.saved);long generated=f.links.forSaved(c.id).ledgerId;
            f.links.connect(c.id,target,false);
            assertNull(f.ledger.getCard(generated));assertEquals(1,f.ledger.listCards().size());assertEquals(target,f.links.forSaved(c.id).ledgerId);
            assertEquals(5000,f.total());assertEquals(target,f.ledger.getTxn(t).cardId);assertEquals(16,f.ledger.getCard(target).billingDay);
        }
    }
    @Test public void linkOnlyKeepsBothPopulatedHistoriesSeparate() {
        try(Fixture f=new Fixture()) {
            long target=f.ledger.createCard("Travel",16);long t=f.expense(target,5000);
            CardInfo c=f.save("HDFC","Millennia");f.links.sync(f.saved);long source=f.links.forSaved(c.id).ledgerId;
            long s=f.expense(source,7000);f.links.connect(c.id,target,false);
            assertNotNull(f.ledger.getCard(source));assertEquals(source,f.ledger.getTxn(s).cardId);assertEquals(target,f.ledger.getTxn(t).cardId);
            assertEquals(12000,f.total());assertNull(f.links.forLedger(source));assertEquals(target,f.links.forSaved(c.id).ledgerId);
        }
    }
    @Test public void explicitlyConfirmedMergePreservesIdsRecurringLinksAndCombinedTotal() {
        try(Fixture f=new Fixture()) {
            long target=f.ledger.createCard("Travel",16);f.expense(target,5000);
            CardInfo c=f.save("HDFC","Millennia");f.links.sync(f.saved);long source=f.links.forSaved(c.id).ledgerId;
            long rule=f.ledger.createRule(source,"Monthly",100,Recurrence.MONTHLY,CivilDate.parseIso("2031-01-31"),"");
            f.ledger.processDue(CivilDate.parseIso("2031-01-31"));long txn=f.ledger.listTxns(source).get(0).id;
            long before=f.total();f.links.connect(c.id,target,true);
            assertNull(f.ledger.getCard(source));assertEquals(before,f.total());assertEquals(target,f.ledger.getRule(rule).cardId);
            assertEquals(target,f.ledger.getTxn(txn).cardId);assertEquals(rule,f.ledger.getTxn(txn).recurringId.longValue());
            assertEquals(16,f.ledger.getCard(target).billingDay);assertEquals(0,f.ledger.processDue(CivilDate.parseIso("2031-01-31")));
        }
    }
    @Test public void renamingEitherSideDoesNotBreakOrReassignLinks() {
        try(Fixture f=new Fixture()) {
            long target=f.ledger.createCard("HDFC Millennia",1);CardInfo c=f.save("HDFC","Millennia");f.links.sync(f.saved);
            f.ledger.updateCard(target,"My travel card",19);c.bank="Renamed bank";c.product="Renamed product";
            f.links.sync(f.saved);assertEquals(target,f.links.forSaved(c.id).ledgerId);assertEquals(1,f.ledger.listCards().size());
            assertEquals("My travel card",f.ledger.getCard(target).name);
        }
    }
    @Test public void deletingSavedCredentialsLeavesLedgerHistoryAndRemovesOnlyTheLink() {
        try(Fixture f=new Fixture()) {
            CardInfo c=f.save("HDFC","Millennia");f.links.sync(f.saved);long id=f.links.forSaved(c.id).ledgerId;f.expense(id,999);
            f.db.exec("DELETE FROM vault WHERE id=?",c.id);f.saved.clear();f.links.sync(f.saved);
            assertNull(f.links.forLedger(id));assertNotNull(f.ledger.getCard(id));assertEquals(999,f.total());
        }
    }
    @Test public void deleteOfLinkedLedgerResetsItButRetainsSavedCardLinkAndBillingDay() {
        try(Fixture f=new Fixture()) {
            long id=f.ledger.createCard("HDFC Millennia",17);CardInfo c=f.save("HDFC","Millennia");f.links.sync(f.saved);
            f.expense(id,500);f.ledger.createRule(id,"Next",100,Recurrence.MONTHLY,CivilDate.parseIso("2031-01-01"),"");
            f.ledger.deleteCard(id);
            assertNotNull(f.ledger.getCard(id));assertEquals(0,f.ledger.summary(id).outstanding);assertEquals(0,f.ledger.listRules(id).size());
            assertEquals(17,f.ledger.getCard(id).billingDay);assertEquals(id,f.links.forSaved(c.id).ledgerId);
            assertEquals(1,f.db.query("SELECT * FROM vault").size());
        }
    }
    @Test public void unlinkKeepsHistoryAndProvidesSavedCardWithItsOwnNewLedger() {
        try(Fixture f=new Fixture()) {
            CardInfo c=f.save("HDFC","Millennia");f.links.sync(f.saved);long old=f.links.forSaved(c.id).ledgerId;f.expense(old,321);
            f.links.unlink(c.id,c.title());long fresh=f.links.forSaved(c.id).ledgerId;
            assertNotEquals(old,fresh);assertNotNull(f.ledger.getCard(old));assertEquals(321,f.total());assertEquals(0,f.ledger.summary(fresh).outstanding);
            f.links.sync(f.saved);assertEquals(fresh,f.links.forSaved(c.id).ledgerId);
        }
    }
    @Test public void changingSavedCardOnAnOccupiedLedgerPreservesBothSavedCardsAndHistory() {
        try(Fixture f=new Fixture()) {
            CardInfo a=f.save("Bank A","One"),b=f.save("Bank B","Two");f.links.sync(f.saved);
            long target=f.links.forSaved(a.id).ledgerId,empty=f.links.forSaved(b.id).ledgerId;f.expense(target,456);
            f.links.connect(b.id,target,false);
            assertEquals(target,f.links.forSaved(b.id).ledgerId);assertNotEquals(target,f.links.forSaved(a.id).ledgerId);
            assertNull(f.ledger.getCard(empty));assertEquals(456,f.total());assertEquals(2,f.ledger.listCards().size());
        }
    }
    @Test public void keepSeparateDismissesReviewWithoutChangingBalances() {
        try(Fixture f=new Fixture()) {
            f.ledger.createCard("HDFC",1);CardInfo c=f.save("HDFC","Millennia");f.links.sync(f.saved);
            assertTrue(f.links.forSaved(c.id).needsReview());long id=f.links.forSaved(c.id).ledgerId;
            f.links.keepSeparate(c.id);f.links.sync(f.saved);assertFalse(f.links.forSaved(c.id).needsReview());assertEquals(id,f.links.forSaved(c.id).ledgerId);
        }
    }
    @Test public void failedLinkLeavesExistingRelationsAndDataUntouched() {
        try(Fixture f=new Fixture()) {
            CardInfo c=f.save("HDFC","Millennia");f.links.sync(f.saved);long id=f.links.forSaved(c.id).ledgerId;f.expense(id,700);
            try{f.links.connect(c.id,99999,true);fail();}catch(IllegalArgumentException expected){}
            assertEquals(id,f.links.forSaved(c.id).ledgerId);assertEquals(700,f.total());assertNotNull(f.ledger.getCard(id));
        }
    }
    @Test public void v20DatabaseUpgradeAddsOnlyLinksAndPreservesEncryptedRowsAndHistory() throws Exception {
        Path file=Files.createTempFile("cardledger-v20-", ".db");
        byte[] encrypted={1,2,3,4,5};
        try(JdbcDb old=new JdbcDb("jdbc:sqlite:"+file.toString())) {
            for(String sql:Schema.CREATE)if(!sql.equals(Schema.LINK_SCHEMA))old.exec(sql.replace(" end_date INTEGER,", ""));
            old.exec("PRAGMA user_version=1");
            old.insert("INSERT INTO cards VALUES(9,'Original',23,1)");
            old.insert("INSERT INTO txns(card_id,type,amount,date,description,note,created_at) VALUES(9,0,12345,1,'Existing','Retain',1)");
            old.insert("INSERT INTO vault VALUES(5,?,?,1,1)",new byte[12],encrypted);

        }
        try(JdbcDb upgraded=JdbcDb.file(file.toString())) {
            assertEquals(12345,new LedgerRepo(upgraded).summary(9).outstanding);
            assertArrayEquals(encrypted,upgraded.query("SELECT data FROM vault WHERE id=5").get(0).getBlob("data"));
            assertEquals(23,new LedgerRepo(upgraded).getCard(9).billingDay);
            assertEquals(0,new CardLinks(upgraded).all().size());
            assertEquals(3,upgraded.query("PRAGMA user_version").get(0).getInt("user_version"));
        }
        Files.deleteIfExists(file);
    }
    @Test public void longNamesAndPunctuationNeverPreventSavedCardsFromAppearing() {
        try(Fixture f=new Fixture()) {
            CardInfo c=f.save(String.join("",Collections.nCopies(55,"A")),String.join("",Collections.nCopies(55,"B")));
            f.links.sync(f.saved);Models.Card card=f.ledger.getCard(f.links.forSaved(c.id).ledgerId);
            assertTrue(card.name.length()<=LedgerRepo.MAX_NAME);assertEquals(0,card.billingDay);
            assertEquals("hdfcmillennia",CardLinks.normalized(" HDFC—  Millennia! "));
        }
    }

    @Test public void aFailureHalfwayThroughMergeRollsBackMovesAndReassignment() {
        try(Fixture f=new Fixture()) {
            CardInfo a=f.save("Bank A","One"),b=f.save("Bank B","Two");f.links.sync(f.saved);
            long source=f.links.forSaved(a.id).ledgerId,target=f.links.forSaved(b.id).ledgerId;
            long txn=f.expense(source,111);f.expense(target,222);
            Db interrupted=new Db(){
                public long insert(String sql,Object... args){return f.db.insert(sql,args);}
                public int exec(String sql,Object... args){
                    if(sql.startsWith("UPDATE rules SET card_id="))throw new IllegalStateException("Injected write failure");
                    return f.db.exec(sql,args);
                }
                public List<Row> query(String sql,Object... args){return f.db.query(sql,args);}
                public void transaction(Runnable work){f.db.transaction(work);}
            };
            try{new CardLinks(interrupted).connect(a.id,target,true);fail();}catch(IllegalStateException expected){}
            assertEquals(source,f.links.forSaved(a.id).ledgerId);assertEquals(target,f.links.forSaved(b.id).ledgerId);
            assertEquals(source,f.ledger.getTxn(txn).cardId);assertEquals(333,f.total());assertEquals(2,f.ledger.listCards().size());
        }
    }

    @Test public void linksSurviveDatabaseReopenAndNameChanges() throws Exception {
        Path file=Files.createTempFile("cardledger-links-", ".db");long savedId,ledgerId;
        try(JdbcDb db=JdbcDb.file(file.toString())) {
            CardInfo c=new CardInfo();c.bank="HDFC";c.product="Millennia";
            c.id=db.insert("INSERT INTO vault(iv,data,created_at,updated_at) VALUES(?,?,0,0)",new byte[12],new byte[16]);
            CardLinks links=new CardLinks(db);links.sync(Collections.singletonList(c));savedId=c.id;ledgerId=links.forSaved(c.id).ledgerId;
            new LedgerRepo(db).updateCard(ledgerId,"Custom title",22);
        }
        try(JdbcDb db=JdbcDb.file(file.toString())) {
            CardLinks links=new CardLinks(db);assertEquals(ledgerId,links.forSaved(savedId).ledgerId);
            assertEquals("Custom title",new LedgerRepo(db).getCard(ledgerId).name);
            assertEquals(22,new LedgerRepo(db).getCard(ledgerId).billingDay);
        }
        Files.deleteIfExists(file);
    }
}
