package com.mion.cardledger;
/** Retains the original launcher component for installed shortcuts and app updates. */
public final class MainActivity extends com.apkbench.app.MainActivity {}
