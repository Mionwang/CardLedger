package com.apkbench.app;

import android.app.Activity;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.Executor;

/**
 * System biometric prompt with device PIN/pattern/password fallback.
 * Only referenced on Android 10+ (API 29), where BiometricPrompt supports
 * device credentials. Nothing about the credential is seen or stored by the app.
 */
@android.annotation.TargetApi(29)
final class BiometricUnlocker {
    private BiometricUnlocker() {}

    interface Result {
        void onSuccess();
        void onCancel();
        void onError(int code, CharSequence message);
    }

    private static final int BIOMETRIC_STRONG = 0x000F;
    private static final int DEVICE_CREDENTIAL = 0x8000;

    static CancellationSignal authenticate(Activity a, final Result result) {
        BiometricPrompt.Builder b = new BiometricPrompt.Builder(a)
                .setTitle("Unlock " + a.getString(R.string.app_name))
                .setSubtitle("Use your fingerprint or screen lock");
        if (Build.VERSION.SDK_INT >= 30) {
            b.setAllowedAuthenticators(BIOMETRIC_STRONG | DEVICE_CREDENTIAL);
        } else {
            b.setDeviceCredentialAllowed(true);
        }
        b.setConfirmationRequired(false);
        BiometricPrompt prompt = b.build();
        final Handler h = new Handler(Looper.getMainLooper());
        Executor ex = new Executor() {
            @Override public void execute(Runnable r) { h.post(r); }
        };
        CancellationSignal cancel = new CancellationSignal();
        prompt.authenticate(cancel, ex, new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) {
                result.onSuccess();
            }

            @Override public void onAuthenticationError(int code, CharSequence msg) {
                if (code == BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED || code == BiometricPrompt.BIOMETRIC_ERROR_CANCELED
                        || code == 13 /* negative button */) {
                    result.onCancel();
                } else {
                    result.onError(code, msg);
                }
            }
        });
        return cancel;
    }
}
