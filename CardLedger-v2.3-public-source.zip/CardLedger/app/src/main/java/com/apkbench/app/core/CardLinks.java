package com.apkbench.app.core;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** One-to-one saved-card/ledger associations. Never stores card numbers or vault fields. */
public final class CardLinks {
    private final Db db;
    public CardLinks(Db db) { this.db = db; }

    public static final class Link {
        public long savedId, ledgerId;
        public String status, autoName;
        public boolean generated;
        public boolean needsReview() { return "review".equals(status); }
    }

    public static String normalized(String name) {
        return Normalizer.normalize(name == null ? "" : name, Normalizer.Form.NFKC)
                .toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]", "");
    }

    private static Link read(Db.Row r) {
        Link l = new Link(); l.savedId = r.getLong("saved_id"); l.ledgerId = r.getLong("ledger_id");
        l.status = r.getString("status"); l.generated = r.getInt("generated") != 0; l.autoName = r.getString("auto_name");
        return l;
    }
    public Link forSaved(long id) {
        List<Db.Row> rows = db.query("SELECT * FROM card_links WHERE saved_id=?", id);
        return rows.isEmpty() ? null : read(rows.get(0));
    }
    public Link forLedger(long id) {
        List<Db.Row> rows = db.query("SELECT * FROM card_links WHERE ledger_id=?", id);
        return rows.isEmpty() ? null : read(rows.get(0));
    }
    public List<Link> all() {
        List<Link> out = new ArrayList<>();
        for (Db.Row r : db.query("SELECT * FROM card_links ORDER BY saved_id")) out.add(read(r));
        return out;
    }

    /** Only a unique composite bank/product identity can match automatically. */
    public void sync(final List<CardInfo> savedCards) {
        db.transaction(() -> {
            LedgerRepo repo = new LedgerRepo(db);
            Map<String,Integer> counts = new HashMap<>();
            for (CardInfo saved : savedCards) {
                String key = normalized(saved.title());
                counts.put(key, counts.containsKey(key) ? counts.get(key)+1 : 1);
            }
            for (CardInfo saved : savedCards) {
                if (forSaved(saved.id) != null) continue;
                String key = normalized(saved.title());
                List<Models.Card> exact = new ArrayList<>();
                boolean possible = false;
                for (Models.Card ledger : repo.listCards()) {
                    if (forLedger(ledger.id) != null) continue;
                    String name = normalized(ledger.name);
                    if (!key.isEmpty() && key.equals(name)) exact.add(ledger);
                    if ((!key.isEmpty() && (name.contains(key) || key.contains(name)))
                            || (!normalized(saved.product).isEmpty() && name.contains(normalized(saved.product)))) possible = true;
                }
                if (!saved.product.trim().isEmpty() && !normalized(saved.bank).isEmpty()
                        && counts.get(key) == 1 && exact.size() == 1) {
                    db.insert("INSERT INTO card_links(saved_id,ledger_id,status,generated,auto_name) VALUES(?,?,'auto',0,'')",
                            saved.id, exact.get(0).id);
                } else {
                    createLedger(saved.id, saved.title(), possible || counts.get(key) > 1 ? "review" : "new");
                }
            }
        });
    }

    private long createLedger(long savedId, String title, String status) {
        String base = title == null || title.trim().isEmpty() ? "Saved card" : title.trim().replaceAll("\\s+", " ");
        base = base.substring(0, Math.min(base.length(), LedgerRepo.MAX_NAME));
        String name = base;
        LedgerRepo repo = new LedgerRepo(db);
        for (int n = 2; repo.findCardByName(name,-1) != null; n++) {
            String suffix = " ("+n+")";
            name = base.substring(0,Math.min(base.length(),LedgerRepo.MAX_NAME-suffix.length()))+suffix;
        }
        long id = db.insert("INSERT INTO cards(name,billing_day,created_at) VALUES(?,0,?)",name,System.currentTimeMillis());
        db.insert("INSERT INTO card_links(saved_id,ledger_id,status,generated,auto_name) VALUES(?,?,?,1,?)", savedId,id,status,name);
        return id;
    }

    public boolean hasEntries(long ledgerId) {
        return db.query("SELECT COUNT(*) AS n FROM txns WHERE card_id=?",ledgerId).get(0).getLong("n") > 0
                || db.query("SELECT COUNT(*) AS n FROM rules WHERE card_id=?",ledgerId).get(0).getLong("n") > 0;
    }
    private boolean disposable(Link l) {
        Models.Card c = new LedgerRepo(db).getCard(l.ledgerId);
        return l.generated && c != null && c.billingDay == 0 && c.name.equals(l.autoName) && !hasEntries(c.id);
    }

    /** Explicit user action. Histories move only when mergeHistory is separately confirmed. */
    public void connect(final long savedId, final long ledgerId, final boolean mergeHistory) {
        db.transaction(() -> {
            LedgerRepo repo = new LedgerRepo(db);
            if (db.query("SELECT id FROM vault WHERE id=?",savedId).isEmpty() || repo.getCard(ledgerId) == null)
                throw new IllegalArgumentException("Card no longer exists");
            Link source = forSaved(savedId), occupied = forLedger(ledgerId);
            if (source != null && source.ledgerId == ledgerId) { keepSeparate(savedId); return; }
            if (occupied != null) {
                // Reassigning the target explicitly detaches its former saved card, not its history.
                db.exec("DELETE FROM card_links WHERE saved_id=?",occupied.savedId);
                createLedger(occupied.savedId,repo.getCard(ledgerId).name,"manual");
            }
            if (source != null) {
                boolean removeEmpty = disposable(source);
                db.exec("DELETE FROM card_links WHERE saved_id=?",savedId);
                if (mergeHistory) {
                    db.exec("UPDATE txns SET card_id=? WHERE card_id=?",ledgerId,source.ledgerId);
                    db.exec("UPDATE rules SET card_id=? WHERE card_id=?",ledgerId,source.ledgerId);
                    if (repo.getCard(ledgerId).billingDay == 0) {
                        db.exec("UPDATE cards SET billing_day=? WHERE id=?",repo.getCard(source.ledgerId).billingDay,ledgerId);
                    }
                    db.exec("DELETE FROM cards WHERE id=?",source.ledgerId);
                } else if (removeEmpty) db.exec("DELETE FROM cards WHERE id=?",source.ledgerId);
            }
            db.insert("INSERT INTO card_links(saved_id,ledger_id,status,generated,auto_name) VALUES(?,?,'manual',0,'')",savedId,ledgerId);
        });
    }

    public void keepSeparate(long savedId) { db.exec("UPDATE card_links SET status='manual' WHERE saved_id=?",savedId); }

    /** Detach history while keeping the saved card represented by its own fresh zero ledger. */
    public void unlink(final long savedId, final String savedTitle) {
        db.transaction(() -> {
            Link link = forSaved(savedId);
            if (link == null) return;
            db.exec("DELETE FROM card_links WHERE saved_id=?",savedId);
            createLedger(savedId,savedTitle,"manual");
        });
    }
}
