package com.apkbench.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.StateListDrawable;
import android.text.InputType;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * View toolkit: true-black, type-led, Material You.
 *
 * Colours are Material 3 dark roles read from resources at runtime. On Android 12+
 * they come from the wallpaper palette (res/values-v31); older phones use a fixed
 * fallback scheme. Lists are plain rows of large type with no containers; tonal
 * fills are reserved for controls. Text uses the phone's system font; DM Mono is
 * used only for card numbers.
 */
final class Ui {
    private Ui() {}

    // ------------------------------------------------------------ colour roles (set in init)
    static int BG = 0xFF000000;
    static int TEXT, MUTED, FAINT;                 // onSurface, onSurfaceVariant, outline
    static int ACCENT, ON_ACCENT;                  // primary, onPrimary
    static int PRIMARY_CONTAINER, ON_PRIMARY_CONTAINER;
    static int TONAL, ON_TONAL;                    // secondaryContainer / onSecondaryContainer
    static int CREDIT;                             // tertiary: cashback and credit balances
    static int SURFACE, SURFACE_2;                 // surface container / high
    static int DANGER, WARN;
    static int IRIS;                               // recurring indicator (= primary)
    static int STROKE;

    static final Typeface SANS = Typeface.create("sans-serif", Typeface.NORMAL);
    static final Typeface MEDIUM = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    static final Typeface SEMIBOLD = MEDIUM;
    static final Typeface LIGHT = Typeface.create("sans-serif-light", Typeface.NORMAL);
    static final Typeface THIN = Typeface.create("sans-serif-thin", Typeface.NORMAL);
    static Typeface MONO = Typeface.MONOSPACE;

    /** Reads the colour roles (dynamic on Android 12+). Call from each activity's onCreate. */
    @SuppressWarnings("deprecation")
    static void init(Context c) {
        TEXT = color(c, R.color.m3_on_surface);
        MUTED = color(c, R.color.m3_on_surface_variant);
        FAINT = color(c, R.color.m3_outline);
        ACCENT = color(c, R.color.m3_primary);
        ON_ACCENT = color(c, R.color.m3_on_primary);
        PRIMARY_CONTAINER = color(c, R.color.m3_primary_container);
        ON_PRIMARY_CONTAINER = color(c, R.color.m3_on_primary_container);
        TONAL = color(c, R.color.m3_secondary_container);
        ON_TONAL = color(c, R.color.m3_on_secondary_container);
        CREDIT = color(c, R.color.m3_tertiary);
        SURFACE = color(c, R.color.m3_surface_container);
        SURFACE_2 = color(c, R.color.m3_surface_container_high);
        DANGER = color(c, R.color.m3_error);
        WARN = color(c, R.color.m3_warn);
        IRIS = ACCENT;
        STROKE = (FAINT & 0x00FFFFFF) | 0x40000000;
        if (MONO == Typeface.MONOSPACE) {
            try {
                MONO = Typeface.createFromAsset(c.getAssets(), "fonts/DMMono-Regular.ttf");
            } catch (RuntimeException ignored) {
                // keep system monospace
            }
        }
    }

    private static int color(Context c, int id) { return c.getColor(id); }

    static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }

    static int alpha(int color, int a) { return (color & 0x00FFFFFF) | (a << 24); }

    // ------------------------------------------------------------ shapes

    static GradientDrawable rounded(Context c, int color, float radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeColor != 0) g.setStroke(Math.max(1, dp(c, 1)), strokeColor);
        return g;
    }

    static Drawable ripple(Context c, Drawable content, float radiusDp) {
        GradientDrawable mask = rounded(c, Color.WHITE, radiusDp, 0);
        return new RippleDrawable(ColorStateList.valueOf(alpha(TEXT, 0x1F)), content, mask);
    }

    /** Plain full-bleed row: no container, just a ripple when touched. */
    static void rowClickable(View v) {
        v.setBackground(ripple(v.getContext(), null, 20));
        v.setClickable(true);
        v.setFocusable(true);
    }

    /** Tonal surface block (used sparingly: saved-card faces, the hero on detail screens). */
    static LinearLayout panel(Context c) {
        LinearLayout l = col(c);
        l.setBackground(rounded(c, SURFACE, 28, 0));
        int p = dp(c, 20);
        l.setPadding(p, p, p, p);
        return l;
    }

    // ------------------------------------------------------------ layout

    static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }

    static LinearLayout.LayoutParams matchWrap() { return lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }

    static LinearLayout.LayoutParams weight(float w) {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w);
    }

    static LinearLayout.LayoutParams margins(Context c, LinearLayout.LayoutParams p, float l, float t, float r, float b) {
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    static View space(Context c, float dp) {
        View v = new View(c);
        v.setLayoutParams(lp(1, dp(c, dp)));
        return v;
    }

    /**
     * Horizontal spacer that absorbs leftover width in a row. Its height is fixed at
     * 1px: a bare View with wrap_content height would claim all available height.
     */
    static View flex(Context c) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1f));
        return v;
    }

    static View hspace(Context c, float dp) {
        View v = new View(c);
        v.setLayoutParams(lp(dp(c, dp), 1));
        return v;
    }

    /** Hairline, used only where two groups need separating. */
    static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(alpha(FAINT, 0x33));
        v.setLayoutParams(lp(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(c, 0.6f))));
        return v;
    }

    static ScrollView scroll(Context c, View content) {
        ScrollView s = new ScrollView(c);
        s.setFillViewport(true);
        s.setVerticalScrollBarEnabled(false);
        s.setOverScrollMode(View.OVER_SCROLL_NEVER);
        s.addView(content, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return s;
    }

    // ------------------------------------------------------------ text

    static TextView text(Context c, CharSequence s, float sp, int color, Typeface tf) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setTypeface(tf);
        t.setLineSpacing(0, 1.12f);
        return t;
    }

    static TextView title(Context c, CharSequence s) { return text(c, s, 28, TEXT, SANS); }

    static TextView body(Context c, CharSequence s) { return text(c, s, 16, TEXT, SANS); }

    static TextView muted(Context c, CharSequence s) { return text(c, s, 14, MUTED, SANS); }

    /** Section label in the accent tone, sentence case (Material You style). */
    static TextView label(Context c, String s) { return text(c, s, 14, ACCENT, MEDIUM); }

    static TextView amount(Context c, CharSequence s, float sp, int color) {
        TextView t = text(c, s, sp, color, sp >= 28 ? LIGHT : SANS);
        t.setFontFeatureSettings("tnum");
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        return t;
    }

    /**
     * Oversized figure: whole units huge and thin with tight tracking; sign, symbol
     * and decimals reduced and dimmed so the number reads first.
     */
    static TextView figure(Context c, String formatted, float sp, int color) {
        SpannableString s = new SpannableString(formatted);
        int firstDigit = -1;
        for (int i = 0; i < formatted.length(); i++) {
            if (Character.isDigit(formatted.charAt(i))) { firstDigit = i; break; }
        }
        int dot = formatted.lastIndexOf('.');
        int dim = alpha(color, 0x99);
        if (firstDigit > 0) {
            s.setSpan(new RelativeSizeSpan(0.42f), 0, firstDigit, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            s.setSpan(new ForegroundColorSpan(dim), 0, firstDigit, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        if (dot > 0 && dot > firstDigit) {
            s.setSpan(new RelativeSizeSpan(0.42f), dot, formatted.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            s.setSpan(new ForegroundColorSpan(dim), dot, formatted.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        TextView t = text(c, s, sp, color, THIN);
        t.setFontFeatureSettings("tnum");
        t.setLetterSpacing(-0.035f);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setIncludeFontPadding(false);
        return t;
    }

    static TextView single(TextView t) {
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        return t;
    }

    // ------------------------------------------------------------ buttons

    static final int PRIMARY = 0, SECONDARY = 1, GHOST = 2, DANGER_STYLE = 3;

    /** Material 3 buttons: filled (primary), tonal (secondary), text (ghost / danger). */
    static TextView button(Context c, String label, int style, View.OnClickListener l) {
        TextView b = text(c, label, 15, TEXT, MEDIUM);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(c, 52));
        int ph = dp(c, 24);
        b.setPadding(ph, dp(c, 12), ph, dp(c, 12));
        float r = 26;
        switch (style) {
            case PRIMARY:
                b.setTextColor(ON_ACCENT);
                b.setBackground(ripple(c, rounded(c, ACCENT, r, 0), r));
                break;
            case SECONDARY:
                b.setTextColor(ON_TONAL);
                b.setBackground(ripple(c, rounded(c, TONAL, r, 0), r));
                break;
            case DANGER_STYLE:
                b.setTextColor(DANGER);
                b.setBackground(ripple(c, rounded(c, Color.TRANSPARENT, r, alpha(DANGER, 0x66)), r));
                break;
            default:
                b.setTextColor(ACCENT);
                b.setBackground(ripple(c, null, r));
                break;
        }
        b.setClickable(true);
        b.setFocusable(true);
        b.setOnClickListener(l);
        return b;
    }

    /** Compact tonal pill. {@code accent} = filled primary. */
    static TextView pill(Context c, String label, boolean accent, View.OnClickListener l) {
        TextView b = text(c, label, 14, accent ? ON_ACCENT : ON_TONAL, MEDIUM);
        b.setGravity(Gravity.CENTER);
        int ph = dp(c, 18);
        b.setPadding(ph, dp(c, 8), ph, dp(c, 8));
        b.setMinHeight(dp(c, 40));
        b.setBackground(ripple(c, rounded(c, accent ? ACCENT : TONAL, 20, 0), 20));
        b.setClickable(true);
        b.setFocusable(true);
        b.setOnClickListener(l);
        return b;
    }

    /** Bare icon button (no container), 48dp touch target. Accepts "←", "⋮", "lock", "+". */
    static View iconButton(Context c, String glyph, String description, View.OnClickListener l) {
        int kind = "←".equals(glyph) ? Shapes.ICON_BACK : "⋮".equals(glyph) ? Shapes.ICON_MORE
                : "lock".equals(glyph) ? Shapes.ICON_LOCK : "+".equals(glyph) ? Shapes.ICON_PLUS : Shapes.ICON_MORE;
        return icon(c, kind, description, l);
    }

    static ImageView icon(Context c, int kind, String description, View.OnClickListener l) {
        ImageView v = new ImageView(c);
        v.setImageDrawable(new Shapes.Icon(kind, dp(c, 24), MUTED));
        v.setScaleType(ImageView.ScaleType.CENTER);
        int s = dp(c, 48);
        v.setLayoutParams(lp(s, s));
        v.setBackground(ripple(c, null, 24));
        v.setClickable(true);
        v.setFocusable(true);
        v.setContentDescription(description);
        v.setOnClickListener(l);
        return v;
    }

    /** Material 3 FAB: 56dp rounded square in primary container. */
    static ImageView fab(Context c, String description, View.OnClickListener l) {
        ImageView v = new ImageView(c);
        v.setImageDrawable(new Shapes.Icon(Shapes.ICON_PLUS, dp(c, 26), ON_PRIMARY_CONTAINER));
        v.setScaleType(ImageView.ScaleType.CENTER);
        v.setBackground(ripple(c, rounded(c, PRIMARY_CONTAINER, 18, 0), 18));
        v.setElevation(dp(c, 3));
        v.setClickable(true);
        v.setFocusable(true);
        v.setContentDescription(description);
        v.setOnClickListener(l);
        return v;
    }

    /** Small tonal status pill. */
    static TextView chip(Context c, String s, int color) {
        TextView t = text(c, s, 12, color, MEDIUM);
        int ph = dp(c, 10);
        t.setPadding(ph, dp(c, 3), ph, dp(c, 4));
        t.setBackground(rounded(c, alpha(color, 0x29), 10, 0));
        return t;
    }

    // ------------------------------------------------------------ inputs

    static final int INPUT_TEXT = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES;
    static final int INPUT_MONEY = InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL;
    static final int INPUT_DIGITS = InputType.TYPE_CLASS_NUMBER;
    static final int INPUT_PIN = InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD;
    static final int INPUT_CAPS = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD;
    static final int INPUT_MULTI = INPUT_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE;

    /** Filled field: tonal surface, primary outline when focused. */
    private static Drawable fieldBackground(Context c) {
        StateListDrawable s = new StateListDrawable();
        GradientDrawable focused = rounded(c, SURFACE, 16, 0);
        focused.setStroke(dp(c, 2), ACCENT);
        s.addState(new int[]{android.R.attr.state_focused}, focused);
        s.addState(new int[]{}, rounded(c, SURFACE, 16, 0));
        return s;
    }

    /** Text field with no autofill, no suggestions and no keyboard learning. */
    static EditText input(Context c, String hint, int type) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setInputType(type);
        e.setTextColor(TEXT);
        e.setHintTextColor(FAINT);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        e.setTypeface(SANS);
        e.setBackground(fieldBackground(c));
        int p = dp(c, 16);
        e.setPadding(p, dp(c, 14), p, dp(c, 14));
        e.setMinHeight(dp(c, 56));
        if ((type & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0) {
            e.setMinLines(3);
            e.setGravity(Gravity.TOP | Gravity.START);
        } else {
            e.setSingleLine(true);
        }
        e.setSaveEnabled(false);
        Compat.sensitive(e);
        e.setLayoutParams(matchWrap());
        return e;
    }

    /** Labelled field block: label above, input below. */
    static LinearLayout field(Context c, String labelText, View input) {
        LinearLayout l = col(c);
        l.addView(text(c, labelText, 13, MUTED, MEDIUM), margins(c, matchWrap(), 4, 0, 0, 8));
        l.addView(input);
        l.setLayoutParams(margins(c, matchWrap(), 0, 0, 0, 18));
        return l;
    }

    /** A non-editable tappable field (date pickers, selectors). */
    static TextView selector(Context c, String value, View.OnClickListener l) {
        TextView t = text(c, value, 17, TEXT, SANS);
        t.setGravity(Gravity.CENTER_VERTICAL);
        int p = dp(c, 16);
        t.setPadding(p, dp(c, 14), dp(c, 12), dp(c, 14));
        t.setMinHeight(dp(c, 56));
        t.setBackground(ripple(c, rounded(c, SURFACE, 16, 0), 16));
        t.setCompoundDrawablesWithIntrinsicBounds(null, null, new Shapes.Icon(Shapes.ICON_CHEVRON, dp(c, 20), MUTED), null);
        t.setClickable(true);
        t.setFocusable(true);
        t.setOnClickListener(l);
        t.setLayoutParams(matchWrap());
        return t;
    }

    /** Material 3 segmented choice: tonal track, selected segment in secondary container. */
    static LinearLayout segmented(final Context c, String[] options, int selected, final SegmentListener listener) {
        final LinearLayout l = row(c);
        l.setBackground(rounded(c, Color.TRANSPARENT, 24, alpha(FAINT, 0x80)));
        int p = dp(c, 3);
        l.setPadding(p, p, p, p);
        final TextView[] views = new TextView[options.length];
        for (int i = 0; i < options.length; i++) {
            final int idx = i;
            TextView t = text(c, options[i], 14, MUTED, MEDIUM);
            t.setGravity(Gravity.CENTER);
            t.setMinHeight(dp(c, 42));
            views[i] = t;
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    styleSegments(c, views, idx);
                    listener.onSelected(idx);
                }
            });
            l.addView(t, weight(1));
        }
        styleSegments(c, views, selected);
        l.setLayoutParams(matchWrap());
        return l;
    }

    interface SegmentListener { void onSelected(int index); }

    static void styleSegments(Context c, TextView[] views, int selected) {
        for (int i = 0; i < views.length; i++) {
            boolean on = i == selected;
            views[i].setTextColor(on ? ON_TONAL : MUTED);
            views[i].setBackground(on ? rounded(c, TONAL, 21, 0) : null);
            views[i].setClickable(true);
        }
    }

    static void error(EditText e, String message) {
        e.setError(message);
        e.requestFocus();
    }
}
