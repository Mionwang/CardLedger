package com.apkbench.app.core;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Imports saved-card details from a separate JSON file. CVV values are always
 * dropped (never imported). Preview text shows masked numbers only. Valid rows are
 * encrypted and written in one transaction; invalid and duplicate rows are skipped.
 *
 * Accepted shape: {"format":"apkbench-saved-cards","version":1,"cards":[{...}]}
 * or a bare array of card objects. Field aliases are accepted (see {@link #read}).
 */
public final class SavedCardImport {
    private SavedCardImport() {}

    public static final String FORMAT = "apkbench-saved-cards";

    public static final class Row {
        public CardInfo card;      // null when invalid
        public String masked = "";
        public String label = "";
        public String problem;     // null = importable
        public boolean duplicate;
    }

    public static final class Plan {
        public final List<Row> rows = new ArrayList<Row>();
        public int cvvDropped;

        public List<CardInfo> importable() {
            List<CardInfo> l = new ArrayList<CardInfo>();
            for (Row r : rows) if (r.problem == null && !r.duplicate) l.add(r.card);
            return l;
        }

        public String describe() {
            int ok = importable().size(), dup = 0, bad = 0;
            for (Row r : rows) { if (r.duplicate) dup++; else if (r.problem != null) bad++; }
            StringBuilder b = new StringBuilder();
            b.append(ok).append(" to import, ").append(dup).append(" duplicates, ").append(bad).append(" invalid\n");
            for (Row r : rows) {
                b.append("\n").append(r.problem == null && !r.duplicate ? "✓ " : "✗ ")
                        .append(r.label.isEmpty() ? "Card" : r.label).append("  ").append(r.masked);
                if (r.duplicate) b.append("\n   already saved");
                else if (r.problem != null) b.append("\n   ").append(r.problem);
            }
            if (cvvDropped > 0) {
                b.append("\n\nCVV values were found for ").append(cvvDropped)
                        .append(" card(s) and ignored. CVVs are never imported; add them manually if needed.");
            }
            return b.toString();
        }
    }

    private static final String[] CVV_KEYS = {"cvv", "cvc", "cvv2", "cvc2", "securityCode", "security_code", "csc"};

    public static Plan plan(VaultRepo vault, String json) {
        Calendar c = Calendar.getInstance();
        return plan(vault, json, c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1);
    }

    public static Plan plan(VaultRepo vault, String json, int nowYear, int nowMonth) {
        if (json.length() > LedgerTransfer.MAX_BYTES) throw new IllegalArgumentException("File is too large");
        Object parsed;
        try {
            parsed = Json.parse(json);
        } catch (Json.ParseException e) {
            throw new IllegalArgumentException("Not valid JSON: " + e.getMessage());
        }
        List<Object> items;
        if (parsed instanceof List) {
            @SuppressWarnings("unchecked") List<Object> l = (List<Object>) parsed;
            items = l;
        } else {
            Json.Obj root = Json.Obj.of(parsed, "file");
            String format = root.str("format", false);
            if (LedgerTransfer.FORMAT.equals(format)) {
                throw new IllegalArgumentException("This is a ledger export. Use \"Import ledger\" instead.");
            }
            if (!format.isEmpty() && !FORMAT.equals(format)) {
                throw new IllegalArgumentException("Unknown format \"" + format + "\"");
            }
            items = root.list("cards", true);
        }

        Plan plan = new Plan();
        Set<String> existing = new HashSet<String>();
        for (CardInfo ci : vault.load().cards) existing.add(ci.number);
        Set<String> seen = new HashSet<String>();
        for (int i = 0; i < items.size(); i++) {
            Row row = new Row();
            plan.rows.add(row);
            Json.Obj o;
            try {
                o = Json.Obj.of(items.get(i), "cards[" + i + "]");
            } catch (IllegalArgumentException e) {
                row.problem = "Not a card object";
                continue;
            }
            for (String k : CVV_KEYS) {
                if (o.has(k)) { plan.cvvDropped++; break; }
            }
            try {
                CardInfo card = read(o);
                row.label = card.title();
                String digits = CardInfo.digitsOnly(card.number);
                row.masked = digits == null ? "••••" : CardInfo.mask(digits);
                card.validate(nowYear, nowMonth);
                row.card = card;
                if (existing.contains(card.number) || !seen.add(card.number)) row.duplicate = true;
            } catch (IllegalArgumentException e) {
                row.problem = e.getMessage();
            }
        }
        return plan;
    }

    /** Encrypts and saves all importable rows atomically. */
    public static int apply(VaultRepo vault, Plan plan) {
        return vault.addAll(plan.importable());
    }

    static CardInfo read(Json.Obj o) {
        CardInfo c = new CardInfo();
        c.bank = pick(o, "bank", "issuer", "issuingBank", "issuing_bank");
        c.product = pick(o, "product", "productName", "product_name", "cardName");
        c.holder = pick(o, "holder", "cardholder", "cardholderName", "cardholder_name", "nameOnCard");
        c.number = pick(o, "number", "cardNumber", "card_number", "pan");
        c.network = normalizeNetwork(pick(o, "network", "scheme", "brand"));
        String kind = pick(o, "kind", "type", "cardType");
        c.kind = kind.toLowerCase().startsWith("deb") ? CardInfo.KIND_DEBIT : CardInfo.KIND_CREDIT;
        String exp = pick(o, "expiry", "exp", "expiration", "expiryDate");
        if (!exp.isEmpty()) {
            int[] e = CardInfo.parseExpiry(exp);
            c.expMonth = e[0];
            c.expYear = e[1];
        } else {
            long m = o.integer(o.has("expMonth") ? "expMonth" : "expiryMonth", true, 0);
            long y = o.integer(o.has("expYear") ? "expYear" : "expiryYear", true, 0);
            if (y < 100) y += 2000;
            c.expMonth = (int) m;
            c.expYear = (int) y;
        }
        c.cvv = ""; // never imported
        if (c.number.isEmpty()) throw new IllegalArgumentException("Card number is required");
        return c;
    }

    private static String pick(Json.Obj o, String... keys) {
        String k = o.firstKey(keys);
        return k == null ? "" : o.str(k, false).trim();
    }

    public static String normalizeNetwork(String n) {
        if (n == null) return "";
        String s = n.trim().toLowerCase().replace(" ", "");
        if (s.isEmpty()) return "";
        if (s.equals("visa")) return "Visa";
        if (s.startsWith("master") || s.equals("mc")) return "Mastercard";
        if (s.equals("rupay")) return "RuPay";
        if (s.startsWith("amex") || s.startsWith("americanexpress")) return "American Express";
        if (s.startsWith("discover")) return "Discover";
        if (s.startsWith("diners")) return "Diners Club";
        if (s.equals("jcb")) return "JCB";
        if (s.startsWith("union")) return "UnionPay";
        if (s.startsWith("maestro")) return "Maestro";
        return "Other";
    }
}
