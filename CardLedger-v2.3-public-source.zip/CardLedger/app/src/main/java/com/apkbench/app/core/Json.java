package com.apkbench.app.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Small strict JSON reader/writer. Numbers are kept as their literal text
 * ({@link Num}) so money never passes through a double.
 * Objects are LinkedHashMap, arrays ArrayList, plus String, Boolean, Num, null.
 */
public final class Json {
    private Json() {}

    public static final int MAX_DEPTH = 64;

    /** A JSON number kept as its exact source text. */
    public static final class Num {
        public final String text;
        public Num(String text) { this.text = text; }
        @Override public String toString() { return text; }
        @Override public boolean equals(Object o) { return o instanceof Num && ((Num) o).text.equals(text); }
        @Override public int hashCode() { return text.hashCode(); }
    }

    public static final class ParseException extends Exception {
        public ParseException(String m) { super(m); }
    }

    // ---------------------------------------------------------------- parsing

    public static Object parse(String s) throws ParseException {
        Parser p = new Parser(s);
        p.ws();
        Object v = p.value(0);
        p.ws();
        if (p.i != p.s.length()) throw p.err("Unexpected trailing content");
        return v;
    }

    private static final class Parser {
        final String s;
        int i;
        Parser(String s) {
            // tolerate a UTF-8 byte-order mark
            this.s = s.length() > 0 && s.charAt(0) == '﻿' ? s.substring(1) : s;
        }

        ParseException err(String m) { return new ParseException(m + " at position " + i); }

        void ws() {
            while (i < s.length()) {
                char c = s.charAt(i);
                if (c == ' ' || c == '\t' || c == '\n' || c == '\r') i++; else break;
            }
        }

        Object value(int depth) throws ParseException {
            if (depth > MAX_DEPTH) throw err("Nesting too deep");
            if (i >= s.length()) throw err("Unexpected end of input");
            char c = s.charAt(i);
            switch (c) {
                case '{': return object(depth);
                case '[': return array(depth);
                case '"': return string();
                case 't': lit("true"); return Boolean.TRUE;
                case 'f': lit("false"); return Boolean.FALSE;
                case 'n': lit("null"); return null;
                default:
                    if (c == '-' || (c >= '0' && c <= '9')) return number();
                    throw err("Unexpected character '" + c + "'");
            }
        }

        void lit(String w) throws ParseException {
            if (!s.startsWith(w, i)) throw err("Invalid literal");
            i += w.length();
        }

        Map<String, Object> object(int depth) throws ParseException {
            Map<String, Object> m = new LinkedHashMap<String, Object>();
            i++;
            ws();
            if (i < s.length() && s.charAt(i) == '}') { i++; return m; }
            while (true) {
                ws();
                if (i >= s.length() || s.charAt(i) != '"') throw err("Expected property name");
                String k = string();
                ws();
                if (i >= s.length() || s.charAt(i) != ':') throw err("Expected ':'");
                i++;
                ws();
                m.put(k, value(depth + 1));
                ws();
                if (i >= s.length()) throw err("Unterminated object");
                char c = s.charAt(i++);
                if (c == '}') return m;
                if (c != ',') throw err("Expected ',' or '}'");
            }
        }

        List<Object> array(int depth) throws ParseException {
            List<Object> a = new ArrayList<Object>();
            i++;
            ws();
            if (i < s.length() && s.charAt(i) == ']') { i++; return a; }
            while (true) {
                ws();
                a.add(value(depth + 1));
                ws();
                if (i >= s.length()) throw err("Unterminated array");
                char c = s.charAt(i++);
                if (c == ']') return a;
                if (c != ',') throw err("Expected ',' or ']'");
            }
        }

        String string() throws ParseException {
            i++;
            StringBuilder b = new StringBuilder();
            while (true) {
                if (i >= s.length()) throw err("Unterminated string");
                char c = s.charAt(i++);
                if (c == '"') return b.toString();
                if (c < 0x20) throw err("Control character in string");
                if (c != '\\') { b.append(c); continue; }
                if (i >= s.length()) throw err("Bad escape");
                char e = s.charAt(i++);
                switch (e) {
                    case '"': b.append('"'); break;
                    case '\\': b.append('\\'); break;
                    case '/': b.append('/'); break;
                    case 'b': b.append('\b'); break;
                    case 'f': b.append('\f'); break;
                    case 'n': b.append('\n'); break;
                    case 'r': b.append('\r'); break;
                    case 't': b.append('\t'); break;
                    case 'u':
                        if (i + 4 > s.length()) throw err("Bad unicode escape");
                        try {
                            b.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                        } catch (NumberFormatException ex) {
                            throw err("Bad unicode escape");
                        }
                        i += 4;
                        break;
                    default: throw err("Bad escape");
                }
            }
        }

        Num number() throws ParseException {
            int st = i;
            if (s.charAt(i) == '-') i++;
            if (i >= s.length()) throw err("Bad number");
            if (s.charAt(i) == '0') {
                i++;
            } else if (s.charAt(i) >= '1' && s.charAt(i) <= '9') {
                while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
            } else {
                throw err("Bad number");
            }
            if (i < s.length() && s.charAt(i) == '.') {
                i++;
                int d = i;
                while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
                if (d == i) throw err("Bad number");
            }
            if (i < s.length() && (s.charAt(i) == 'e' || s.charAt(i) == 'E')) {
                i++;
                if (i < s.length() && (s.charAt(i) == '+' || s.charAt(i) == '-')) i++;
                int d = i;
                while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
                if (d == i) throw err("Bad number");
            }
            return new Num(s.substring(st, i));
        }
    }

    // ---------------------------------------------------------------- writing

    public static String write(Object v) {
        StringBuilder b = new StringBuilder();
        write(b, v, 0);
        b.append('\n');
        return b.toString();
    }

    @SuppressWarnings("unchecked")
    private static void write(StringBuilder b, Object v, int ind) {
        if (v == null) { b.append("null"); return; }
        if (v instanceof String) { quote(b, (String) v); return; }
        if (v instanceof Boolean) { b.append(v.toString()); return; }
        if (v instanceof Num) { b.append(((Num) v).text); return; }
        if (v instanceof Long || v instanceof Integer) { b.append(v.toString()); return; }
        if (v instanceof Map) {
            Map<String, Object> m = (Map<String, Object>) v;
            if (m.isEmpty()) { b.append("{}"); return; }
            b.append("{\n");
            int n = 0;
            for (Map.Entry<String, Object> e : m.entrySet()) {
                indent(b, ind + 1);
                quote(b, e.getKey());
                b.append(": ");
                write(b, e.getValue(), ind + 1);
                if (++n < m.size()) b.append(',');
                b.append('\n');
            }
            indent(b, ind);
            b.append('}');
            return;
        }
        if (v instanceof List) {
            List<Object> a = (List<Object>) v;
            if (a.isEmpty()) { b.append("[]"); return; }
            b.append("[\n");
            for (int k = 0; k < a.size(); k++) {
                indent(b, ind + 1);
                write(b, a.get(k), ind + 1);
                if (k < a.size() - 1) b.append(',');
                b.append('\n');
            }
            indent(b, ind);
            b.append(']');
            return;
        }
        throw new IllegalArgumentException("Unsupported JSON value: " + v.getClass());
    }

    private static void indent(StringBuilder b, int n) {
        for (int k = 0; k < n; k++) b.append("  ");
    }

    public static void quote(StringBuilder b, String s) {
        b.append('"');
        for (int k = 0; k < s.length(); k++) {
            char c = s.charAt(k);
            switch (c) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                case '\b': b.append("\\b"); break;
                case '\f': b.append("\\f"); break;
                default:
                    if (c < 0x20 || c == ' ' || c == ' ') {
                        String h = Integer.toHexString(c);
                        b.append("\\u");
                        for (int p = h.length(); p < 4; p++) b.append('0');
                        b.append(h);
                    } else {
                        b.append(c);
                    }
            }
        }
        b.append('"');
    }

    // ---------------------------------------------------------------- typed access

    /** Wraps a parsed object for validated field access with path-aware errors. */
    public static final class Obj {
        public final Map<String, Object> map;
        public final String path;

        public Obj(Map<String, Object> map, String path) {
            this.map = map;
            this.path = path;
        }

        @SuppressWarnings("unchecked")
        public static Obj of(Object v, String path) {
            if (!(v instanceof Map)) throw new IllegalArgumentException(path + ": expected an object");
            return new Obj((Map<String, Object>) v, path);
        }

        public boolean has(String k) { return map.containsKey(k) && map.get(k) != null; }

        /** First present key among aliases, or null. */
        public String firstKey(String... keys) {
            for (String k : keys) if (has(k)) return k;
            return null;
        }

        public String str(String k, boolean required) {
            Object v = map.get(k);
            if (v == null) {
                if (required) throw new IllegalArgumentException(path + "." + k + ": required");
                return "";
            }
            if (v instanceof String) return (String) v;
            if (v instanceof Num) return ((Num) v).text;
            throw new IllegalArgumentException(path + "." + k + ": expected text");
        }

        public long integer(String k, boolean required, long def) {
            Object v = map.get(k);
            if (v == null) {
                if (required) throw new IllegalArgumentException(path + "." + k + ": required");
                return def;
            }
            String t = v instanceof Num ? ((Num) v).text : (v instanceof String ? ((String) v).trim() : null);
            if (t == null) throw new IllegalArgumentException(path + "." + k + ": expected a whole number");
            try {
                return Long.parseLong(t);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException(path + "." + k + ": expected a whole number");
            }
        }

        public boolean bool(String k, boolean def) {
            Object v = map.get(k);
            if (v == null) return def;
            if (v instanceof Boolean) return (Boolean) v;
            throw new IllegalArgumentException(path + "." + k + ": expected true or false");
        }

        /** Money given as "12.34" or 12.34; never via double. */
        public long money(String k) {
            Object v = map.get(k);
            if (v == null) throw new IllegalArgumentException(path + "." + k + ": required");
            String t;
            if (v instanceof Num) t = ((Num) v).text;
            else if (v instanceof String) t = (String) v;
            else throw new IllegalArgumentException(path + "." + k + ": expected an amount");
            if (t.indexOf('e') >= 0 || t.indexOf('E') >= 0) {
                throw new IllegalArgumentException(path + "." + k + ": exponent notation not allowed");
            }
            try {
                return Money.parsePositive(t);
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException(path + "." + k + ": " + e.getMessage());
            }
        }

        @SuppressWarnings("unchecked")
        public List<Object> list(String k, boolean required) {
            Object v = map.get(k);
            if (v == null) {
                if (required) throw new IllegalArgumentException(path + "." + k + ": required");
                return new ArrayList<Object>();
            }
            if (!(v instanceof List)) throw new IllegalArgumentException(path + "." + k + ": expected a list");
            return (List<Object>) v;
        }
    }
}
