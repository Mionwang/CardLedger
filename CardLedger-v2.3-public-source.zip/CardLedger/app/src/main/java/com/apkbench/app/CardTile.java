package com.apkbench.app;

import android.content.Context;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.apkbench.app.core.CardInfo;

/** Saved-card face: a tonal surface with the number set large in DM Mono. */
final class CardTile {
    private CardTile() {}

    /** @param numberText already masked or revealed number text */
    static FrameLayout build(Context c, CardInfo info, String numberText) {
        return build(c,info,numberText,null);
    }

    static FrameLayout build(Context c, CardInfo info, String numberText, android.view.View.OnClickListener menu) {
        FrameLayout f = new FrameLayout(c);
        f.setBackground(Ui.rounded(c, Ui.SURFACE_2, 28, 0));
        int p = Ui.dp(c, 22);
        f.setPadding(p, p, p, p);
        f.setMinimumHeight(Ui.dp(c, 196));

        LinearLayout col = Ui.col(c);
        LinearLayout top = Ui.row(c);
        top.setGravity(Gravity.TOP);
        LinearLayout titles = Ui.col(c);
        titles.addView(Ui.single(Ui.text(c, info.bank.isEmpty() ? "Card" : info.bank, 20, Ui.TEXT, Ui.SANS)));
        String sub = info.kind.isEmpty() ? info.product : info.product.isEmpty() ? info.kind : info.product + ", " + info.kind.toLowerCase();
        titles.addView(Ui.single(Ui.text(c, sub, 14, Ui.MUTED, Ui.SANS)));
        top.addView(titles, Ui.weight(1));
        top.addView(Ui.text(c, info.network, 14, Ui.ACCENT, Ui.MEDIUM));
        if (menu != null) top.addView(Ui.icon(c,Shapes.ICON_MORE,"Saved card options",menu));
        col.addView(top);
        col.addView(Ui.space(c, 34));
        TextView num = Ui.text(c, numberText, 21, Ui.TEXT, Ui.MONO);
        num.setLetterSpacing(0.04f);
        num.setSingleLine(true);
        col.addView(num);
        col.addView(Ui.space(c, 16));
        LinearLayout bottom = Ui.row(c);
        bottom.addView(Ui.single(Ui.text(c, info.holder.isEmpty() ? "No name" : info.holder, 14, Ui.MUTED, Ui.SANS)), Ui.weight(1));
        bottom.addView(Ui.text(c, info.expiry(), 14, Ui.MUTED, Ui.MONO));
        col.addView(bottom);
        f.addView(col);
        return f;
    }
}
