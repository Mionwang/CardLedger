package com.apkbench.app;
import com.apkbench.app.core.VaultCipher;
import javax.crypto.SecretKey;
/** Uses Card Ledger's original authenticated wrapped key; never rotates it. */
final class KeystoreKeys implements VaultCipher.KeySource {
    @Override public SecretKey key() { return App.get().vaultKey(); }
}
