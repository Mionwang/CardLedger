package com.apkbench.app;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.apkbench.app.core.BillingCycle;
import com.apkbench.app.core.CivilDate;
import com.apkbench.app.core.Models;

import java.util.List;

/** One ledger card: balance breakdown, actions and its chronological transactions. */
public final class CardDetailActivity extends BaseActivity {
    private long cardId;

    @Override protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        cardId = getIntent().getLongExtra("card", -1);
    }

    @Override protected View build() {
        final Models.CardSummary s = app.ledger().summary(cardId);
        if (s == null) {
            finish();
            return new View(this);
        }
        final View more = Ui.iconButton(this, "⋮", "Card options", null);
        more.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                boolean linked=app.links().forLedger(cardId)!=null;
                Dialogs.actions(CardDetailActivity.this,s.card.name,new String[]{"Rename / billing day","Mark paid",
                        linked?"Linked saved card":"Link saved card",linked?"Reset ledger":"Delete ledger"},i->{
                    if(i==0)Dialogs.cardEditor(CardDetailActivity.this,s.card,()->rebuild());
                    else if(i==1)MainActivity.confirmPaid(CardDetailActivity.this,s.card);
                    else if(i==2)CardLinkDialogs.manageLedger(CardDetailActivity.this,cardId);
                    else CardLinkDialogs.deleteOrReset(CardDetailActivity.this,s.card);
                });
            }
        });
        long today = CivilDate.today();
        long[] cycle = s.card.billingDay == 0 ? null : BillingCycle.currentCycle(s.card.billingDay, today);
        LinearLayout[] pg = page(s.card.name, s.card.billingDay == 0 ? "Bill date not set" : "Bills on the " + CivilDate.ordinal(s.card.billingDay)
                + " of each month", true, more);
        LinearLayout body = pg[1];

        // balance: oversized figure, no container
        body.addView(Ui.label(this, "Outstanding"));
        body.addView(Ui.figure(this, app.money(s.outstanding), 56, s.outstanding < 0 ? Ui.CREDIT : Ui.TEXT),
                Ui.margins(this, Ui.matchWrap(), -2, 2, 0, 18));
        LinearLayout stats = Ui.row(this);
        stats.addView(stat("Spent", app.money(s.expenses), Ui.TEXT), Ui.weight(1));
        stats.addView(stat("Cashback", "−" + app.money(s.cashback), Ui.CREDIT), Ui.weight(1));
        body.addView(stats);
        body.addView(Ui.muted(this, cycle == null ? "Set a billing day from the card menu." : "This cycle runs " + CivilDate.displayShort(cycle[0]) + " to " + CivilDate.display(cycle[1]) + "."),
                Ui.margins(this, Ui.matchWrap(), 0, 14, 0, 24));

        LinearLayout actions = Ui.row(this);
        actions.addView(Ui.button(this, "Add expense", Ui.PRIMARY, new View.OnClickListener() {
            @Override public void onClick(View v) { openTxn(-1, Models.TYPE_EXPENSE); }
        }), Ui.weight(1));
        actions.addView(Ui.hspace(this, 10));
        actions.addView(Ui.button(this, "Add cashback", Ui.SECONDARY, new View.OnClickListener() {
            @Override public void onClick(View v) { openTxn(-1, Models.TYPE_CASHBACK); }
        }), Ui.weight(1));
        body.addView(actions, Ui.margins(this, Ui.matchWrap(), 0, 0, 0, 10));
        body.addView(Ui.button(this, "Mark paid", Ui.DANGER_STYLE, new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (s.txnCount == 0) { toast("Nothing to clear"); return; }
                MainActivity.confirmPaid(CardDetailActivity.this, s.card);
            }
        }), Ui.margins(this, Ui.matchWrap(), 0, 0, 0, 28));

        // recurring: a plain row that leads to its own screen
        LinearLayout rec = Ui.row(this);
        Ui.rowClickable(rec);
        rec.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 12));
        LinearLayout rt = Ui.col(this);
        rt.addView(Ui.text(this, "Recurring payments", 20, Ui.TEXT, Ui.SANS));
        String sub = s.ruleCount == 0 ? "None set up" : s.activeRuleCount + " active"
                + (s.pausedRuleCount > 0 ? ", " + s.pausedRuleCount + " paused" : "")
                + (s.endedRuleCount > 0 ? ", " + s.endedRuleCount + " ended" : "")
                + (s.limitedRuleCount > 0 ? "\n" + app.money(s.remainingCommitment) + " remaining until end dates" : "")
                + (s.unlimitedRuleCount > 0 ? "\n" + app.money(s.unlimitedAnnualCommitment) + " a year · no end date" : "");
        rt.addView(Ui.muted(this, sub));
        rec.addView(rt, Ui.weight(1));
        android.widget.ImageView chev = new android.widget.ImageView(this);
        chev.setImageDrawable(new Shapes.Icon(Shapes.ICON_CHEVRON, Ui.dp(this, 22), Ui.MUTED));
        rec.addView(chev);
        rec.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(intent(RecurringListActivity.class).putExtra("card", cardId));
            }
        });
        body.addView(rec, Ui.margins(this, Ui.matchWrap(), 0, 0, 0, 20));

        List<Models.Txn> txns = app.ledger().listTxns(cardId);
        body.addView(Ui.label(this, txns.isEmpty() ? "Transactions" : "Transactions, oldest first"),
                Ui.margins(this, Ui.matchWrap(), 0, 0, 0, 4));
        if (txns.isEmpty()) {
            body.addView(Ui.muted(this, "Nothing in this cycle yet."), Ui.margins(this, Ui.matchWrap(), 0, 8, 0, 0));
        } else {
            for (int i = 0; i < txns.size(); i++) body.addView(txnRow(txns.get(i)));
            body.addView(Ui.text(this, "Tap an entry to edit it. Press and hold for more options.", 13, Ui.FAINT, Ui.SANS),
                    Ui.margins(this, Ui.matchWrap(), 0, 16, 0, 0));
        }
        return pg[0];
    }

    private View stat(String label, String value, int color) {
        LinearLayout l = Ui.col(this);
        l.addView(Ui.muted(this, label));
        l.addView(Ui.amount(this, value, 18, color));
        return l;
    }

    private View txnRow(final Models.Txn t) {
        LinearLayout r = Ui.row(this);
        int p = Ui.dp(this, 14);
        r.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 12));
        r.setBackground(Ui.ripple(this, null, 16));
        r.setClickable(true);
        LinearLayout left = Ui.col(this);
        String title = t.description.isEmpty() ? (t.isCashback() ? "Cashback" : "Expense") : t.description;
        left.addView(Ui.single(Ui.text(this, title, 17, Ui.TEXT, Ui.SANS)));
        String meta = CivilDate.display(t.date) + (t.recurringId != null ? ", recurring" : "")
                + (t.isCashback() ? ", cashback" : "");
        left.addView(Ui.single(Ui.text(this, meta, 13, Ui.MUTED, Ui.SANS)));
        if (!t.note.isEmpty() && !(t.recurringId != null && "Recurring".equals(t.note))) {
            left.addView(Ui.single(Ui.text(this, t.note, 13, Ui.FAINT, Ui.SANS)));
        }
        r.addView(left, Ui.weight(1));
        r.addView(Ui.hspace(this, 10));
        r.addView(Ui.amount(this, (t.isCashback() ? "−" : "") + app.money(t.amount), 17, t.isCashback() ? Ui.CREDIT : Ui.TEXT));
        r.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openTxn(t.id, t.type); }
        });
        r.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                Dialogs.actions(CardDetailActivity.this, app.money(t.amount) + " on " + CivilDate.display(t.date),
                        new String[]{"Edit", "Delete"}, new Dialogs.Picked() {
                            @Override public void picked(int i) {
                                if (i == 0) openTxn(t.id, t.type);
                                else Dialogs.confirm(CardDetailActivity.this, "Delete transaction?",
                                        "This can't be undone.", "Delete", true, new Dialogs.Done() {
                                            @Override public void run() {
                                                app.ledger().deleteTxn(t.id);
                                                rebuild();
                                            }
                                        });
                            }
                        });
                return true;
            }
        });
        return r;
    }

    private void openTxn(long id, int type) {
        startActivity(intent(TxnEditActivity.class).putExtra("card", cardId).putExtra("txn", id).putExtra("type", type));
    }
}
