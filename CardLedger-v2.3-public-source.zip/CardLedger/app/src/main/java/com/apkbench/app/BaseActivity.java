package com.apkbench.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Common base for every screen behind the lock. Content stays hidden while the app
 * is locked; the lock screen is shown on top and the screen refreshes once unlocked.
 */
abstract class BaseActivity extends Activity {
    protected App app;
    private FrameLayout root;
    private boolean contentBuilt;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        app = App.get();
        Ui.init(this);
        Window w = getWindow();
        edgeToEdge(w, auroraVariant());
        Compat.hideFromRecents(this);
        root = new FrameLayout(this);
        root.setFitsSystemWindows(true);
        Compat.disableAutofill(root, true);
        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        if (app.isLocked()) {
            root.setVisibility(View.INVISIBLE);
            LockActivity.show(this);
            return;
        }
        root.setVisibility(View.VISIBLE);
        try {
            app.processRecurring();
        } catch (RuntimeException e) {
            toast("Couldn't post recurring payments: " + e.getMessage());
        }
        if (!contentBuilt || rebuildOnResume()) {
            contentBuilt = true;
            rebuild();
        }
    }

    /** Lists refresh on every resume; edit forms return false to keep typed input. */
    protected boolean rebuildOnResume() { return true; }

    @Override protected void onPause() {
        super.onPause();
        if (isFinishing()) return;
        onHide();
    }

    /** True-black window and system bars. */
    static void edgeToEdge(Window w, int unused) {
        w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0xFF000000));
        w.setStatusBarColor(0xFF000000);
        w.setNavigationBarColor(0xFF000000);
    }

    protected int auroraVariant() { return 0; }

    /** Called when the screen goes into the background (e.g. to stop reveal timers). */
    protected void onHide() { }

    /** Rebuild the screen from current data. */
    protected final void rebuild() {
        root.removeAllViews();
        View v = build();
        root.addView(v, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /** Builds the whole screen. Called on every resume and after data changes. */
    protected abstract View build();

    /** Starts a system activity (file picker, settings) without triggering the background lock. */
    protected void startExternal(Intent i, int requestCode) {
        app.expectExternal();
        try {
            if (requestCode >= 0) startActivityForResult(i, requestCode); else startActivity(i);
        } catch (RuntimeException e) {
            toast("No app available for this action");
        }
    }

    protected void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    /**
     * Material large top app bar: a row of bare icons (back on the left, actions on the
     * right) with the title set large and left-aligned underneath.
     */
    protected LinearLayout topBar(String title, String subtitle, boolean back, View... trailing) {
        LinearLayout bar = Ui.col(this);
        LinearLayout icons = Ui.row(this);
        int p = Ui.dp(this, 8);
        icons.setPadding(p, Ui.dp(this, 6), p, 0);
        icons.setMinimumHeight(Ui.dp(this, 56));
        if (back) {
            icons.addView(Ui.iconButton(this, "←", "Back", new View.OnClickListener() {
                @Override public void onClick(View v) { finish(); }
            }));
        }
        icons.addView(Ui.flex(this));
        for (View v : trailing) {
            if (v == null) continue;
            ViewGroup.LayoutParams own = v.getLayoutParams();
            LinearLayout.LayoutParams lp = own != null ? Ui.lp(own.width, own.height)
                    : Ui.lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.leftMargin = Ui.dp(this, 4);
            icons.addView(v, lp);
        }
        bar.addView(icons);
        if (title != null) {
            TextView t = Ui.text(this, title, 32, Ui.TEXT, Ui.SANS);
            t.setLetterSpacing(-0.01f);
            t.setMaxLines(2);
            t.setEllipsize(android.text.TextUtils.TruncateAt.END);
            bar.addView(t, Ui.margins(this, Ui.matchWrap(), 24, 12, 24, 0));
            if (subtitle != null && !subtitle.isEmpty()) {
                bar.addView(Ui.muted(this, subtitle), Ui.margins(this, Ui.matchWrap(), 24, 4, 24, 0));
            }
        }
        bar.setPadding(0, 0, 0, Ui.dp(this, 12));
        return bar;
    }

    /** Vertical page with top bar and scrollable padded body. Returns {page, body}. */
    protected LinearLayout[] page(String title, String subtitle, boolean back, View... trailing) {
        LinearLayout page = Ui.col(this);
        page.addView(topBar(title, subtitle, back, trailing));
        LinearLayout body = Ui.col(this);
        int p = Ui.dp(this, 24);
        body.setPadding(p, Ui.dp(this, 8), p, Ui.dp(this, 48));
        page.addView(Ui.scroll(this, body), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        return new LinearLayout[]{page, body};
    }

    protected Intent intent(Class<?> cls) { return new Intent(this, cls); }
}
