package com.apkbench.app.core;

import com.apkbench.app.core.Models.Card;
import com.apkbench.app.core.Models.Rule;
import com.apkbench.app.core.Models.Txn;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Ledger JSON export / import.
 *
 * Import is two-phase: {@link #plan} parses and validates the whole file and
 * computes what would change (nothing is written), then {@link #apply} writes the
 * plan inside a single database transaction, so a failure leaves the ledger
 * untouched. Cards are matched to existing cards by name (case-insensitive).
 * Transactions and recurring rules already present are skipped as duplicates.
 * The Saved Cards vault is never part of this file.
 */
public final class LedgerTransfer {
    private LedgerTransfer() {}

    public static final String FORMAT = "apkbench-ledger";
    public static final int VERSION = 2;
    public static final int MAX_BYTES = 20 * 1024 * 1024;

    // ================================================================ export

    public static String export(LedgerRepo repo, long todayEpochDay) {
        Map<String, Object> root = new LinkedHashMap<String, Object>();
        root.put("format", FORMAT);
        root.put("version", (long) VERSION);
        root.put("exportedOn", CivilDate.iso(todayEpochDay));
        List<Object> cards = new ArrayList<Object>();
        for (Card c : repo.listCards()) {
            Map<String, Object> cm = new LinkedHashMap<String, Object>();
            cm.put("name", c.name);
            cm.put("billingDay", (long) c.billingDay);
            List<Object> txns = new ArrayList<Object>();
            for (Txn t : repo.listTxns(c.id)) {
                Map<String, Object> tm = new LinkedHashMap<String, Object>();
                tm.put("type", t.isCashback() ? "cashback" : "expense");
                tm.put("amount", Money.toPlain(t.amount));
                tm.put("date", CivilDate.iso(t.date));
                tm.put("description", t.description);
                tm.put("note", t.note);
                txns.add(tm);
            }
            cm.put("transactions", txns);
            List<Object> rules = new ArrayList<Object>();
            for (Rule r : repo.listRules(c.id)) {
                Map<String, Object> rm = new LinkedHashMap<String, Object>();
                rm.put("name", r.name);
                rm.put("amount", Money.toPlain(r.amount));
                rm.put("frequency", Recurrence.frequencyKey(r.frequency));
                rm.put("startDate", CivilDate.iso(r.startDate));
                rm.put("anchorDay", (long) r.anchorDay);
                rm.put("nextIndex", r.nextIndex);
                rm.put("nextDate", CivilDate.iso(r.nextDate()));
                rm.put("paused", r.paused);
                rm.put("pausedAt", r.pausedAt == null ? null : CivilDate.iso(r.pausedAt));
                rm.put("pauseUntil", r.pauseUntil == null ? null : CivilDate.iso(r.pauseUntil));
                rm.put("endDate", r.endDate == null ? null : CivilDate.iso(r.endDate));
                rm.put("note", r.note);
                rules.add(rm);
            }
            cm.put("recurring", rules);
            cards.add(cm);
        }
        root.put("cards", cards);
        return Json.write(root);
    }

    // ================================================================ import plan

    public static final class PlanCard {
        public String name;
        public int billingDay;
        public Long existingId;          // null = will be created
        public int existingBillingDay;
        public final List<Txn> newTxns = new ArrayList<Txn>();
        public int duplicateTxns;
        public final List<Rule> newRules = new ArrayList<Rule>();
        public int duplicateRules;
    }

    public static final class Plan {
        public final List<PlanCard> cards = new ArrayList<PlanCard>();
        public final List<String> warnings = new ArrayList<String>();

        public int newCards() { int n = 0; for (PlanCard c : cards) if (c.existingId == null) n++; return n; }
        public int matchedCards() { return cards.size() - newCards(); }
        public int newTxns() { int n = 0; for (PlanCard c : cards) n += c.newTxns.size(); return n; }
        public int duplicateTxns() { int n = 0; for (PlanCard c : cards) n += c.duplicateTxns; return n; }
        public int newRules() { int n = 0; for (PlanCard c : cards) n += c.newRules.size(); return n; }
        public int duplicateRules() { int n = 0; for (PlanCard c : cards) n += c.duplicateRules; return n; }
        public boolean hasChanges() { return newCards() + newTxns() + newRules() > 0; }

        public String describe(String symbol, boolean indian) {
            StringBuilder b = new StringBuilder();
            b.append("Cards: ").append(cards.size()).append(" (").append(newCards()).append(" new, ")
                    .append(matchedCards()).append(" matched by name)\n");
            b.append("Transactions: ").append(newTxns()).append(" to add, ").append(duplicateTxns())
                    .append(" duplicates skipped\n");
            b.append("Recurring payments: ").append(newRules()).append(" to add, ").append(duplicateRules())
                    .append(" duplicates skipped\n");
            for (PlanCard c : cards) {
                long sum = 0;
                for (Txn t : c.newTxns) sum = Money.add(sum, t.signed());
                b.append("\n• ").append(c.name).append(c.existingId == null ? " (new)" : " (existing)")
                        .append("\n   +").append(c.newTxns.size()).append(" transactions (")
                        .append(Money.format(sum, symbol, indian)).append("), +")
                        .append(c.newRules.size()).append(" recurring");
            }
            if (!warnings.isEmpty()) {
                b.append("\n\nNotes:");
                for (String w : warnings) b.append("\n– ").append(w);
            }
            return b.toString();
        }
    }

    /**
     * Parses and validates {@code json} against the current ledger.
     * Throws IllegalArgumentException with a path-specific message on the first problem.
     */
    public static Plan plan(LedgerRepo repo, String json) {
        if (json.length() > MAX_BYTES) throw new IllegalArgumentException("File is too large");
        Object parsed;
        try {
            parsed = Json.parse(json);
        } catch (Json.ParseException e) {
            throw new IllegalArgumentException("Not valid JSON: " + e.getMessage());
        }
        Json.Obj root = Json.Obj.of(parsed, "file");
        String format = root.str("format", false);
        if (!FORMAT.equals(format)) {
            if ("apkbench-saved-cards".equals(format)) {
                throw new IllegalArgumentException("This is a Saved Cards file. Use \"Import saved cards\" instead.");
            }
            throw new IllegalArgumentException("Not a supported Card Ledger export (format must be \"" + FORMAT + "\")");
        }
        long version = root.integer("version", true, 0);
        if (version < 1 || version > VERSION) throw new IllegalArgumentException("Unsupported file version " + version);

        Plan plan = new Plan();
        Map<String, PlanCard> byName = new HashMap<String, PlanCard>();
        List<Object> cards = root.list("cards", true);
        for (int i = 0; i < cards.size(); i++) {
            String p = "cards[" + i + "]";
            Json.Obj co = Json.Obj.of(cards.get(i), p);
            String name;
            try {
                name = LedgerRepo.cleanName(co.str("name", true));
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException(p + ".name: " + e.getMessage());
            }
            long bd = co.integer("billingDay", true, 0);
            if ((bd != 0 && !BillingCycle.isValidDay((int) bd)) || bd != (int) bd) {
                throw new IllegalArgumentException(p + ".billingDay: must be 0 (unset) or 1-31");
            }
            String key = name.toLowerCase();
            if (byName.containsKey(key)) throw new IllegalArgumentException(p + ".name: \"" + name + "\" appears twice in the file");
            PlanCard pc = new PlanCard();
            pc.name = name;
            pc.billingDay = (int) bd;
            byName.put(key, pc);
            Card existing = repo.findCardByName(name, -1);
            if (existing != null) {
                pc.existingId = existing.id;
                pc.existingBillingDay = existing.billingDay;
                if (existing.billingDay != pc.billingDay) {
                    plan.warnings.add("\"" + name + "\" keeps its billing day (" + existing.billingDay
                            + "); file says " + pc.billingDay + ".");
                }
            }

            // transactions: multiset duplicate detection against existing rows
            Map<String, Integer> existingKeys = new HashMap<String, Integer>();
            if (existing != null) {
                for (Txn t : repo.listTxns(existing.id)) increment(existingKeys, txnKey(t));
            }
            List<Object> txns = co.list("transactions", false);
            for (int j = 0; j < txns.size(); j++) {
                String tp = p + ".transactions[" + j + "]";
                Json.Obj to = Json.Obj.of(txns.get(j), tp);
                Txn t = new Txn();
                String type = to.str("type", true);
                if ("expense".equalsIgnoreCase(type)) t.type = Models.TYPE_EXPENSE;
                else if ("cashback".equalsIgnoreCase(type)) t.type = Models.TYPE_CASHBACK;
                else throw new IllegalArgumentException(tp + ".type: must be \"expense\" or \"cashback\"");
                t.amount = to.money("amount");
                t.date = date(to, "date", tp, true);
                t.description = text(to, "description", LedgerRepo.MAX_TEXT, tp);
                t.note = text(to, "note", LedgerRepo.MAX_NOTE, tp);
                String k = txnKey(t);
                Integer have = existingKeys.get(k);
                if (have != null && have > 0) {
                    existingKeys.put(k, have - 1);
                    pc.duplicateTxns++;
                } else {
                    pc.newTxns.add(t);
                }
            }

            Map<String, Integer> existingRules = new HashMap<String, Integer>();
            if (existing != null) {
                for (Rule r : repo.listRules(existing.id)) increment(existingRules, ruleKey(r));
            }
            List<Object> rules = co.list("recurring", false);
            for (int j = 0; j < rules.size(); j++) {
                String rp = p + ".recurring[" + j + "]";
                Json.Obj ro = Json.Obj.of(rules.get(j), rp);
                Rule r = new Rule();
                try {
                    r.name = LedgerRepo.cleanName(ro.str("name", true));
                } catch (IllegalArgumentException e) {
                    throw new IllegalArgumentException(rp + ".name: " + e.getMessage());
                }
                r.amount = ro.money("amount");
                try {
                    r.frequency = Recurrence.parseFrequency(ro.str("frequency", true));
                } catch (IllegalArgumentException e) {
                    throw new IllegalArgumentException(rp + ".frequency: " + e.getMessage());
                }
                if (ro.has("startDate")) {
                    r.startDate = date(ro, "startDate", rp, true);
                    long ad = ro.integer("anchorDay", false, CivilDate.day(r.startDate));
                    if (ad < 1 || ad > 31) throw new IllegalArgumentException(rp + ".anchorDay: must be 1-31");
                    r.anchorDay = (int) ad;
                    if (r.anchorDay < CivilDate.day(r.startDate)) {
                        throw new IllegalArgumentException(rp + ".anchorDay: cannot be before the start date's day");
                    }
                    long ni = ro.integer("nextIndex", false, 0);
                    if (ni < 0 || ni > 1_000_000) throw new IllegalArgumentException(rp + ".nextIndex: out of range");
                    r.nextIndex = ni;
                } else {
                    // hand-written files may give just the next payment date
                    r.startDate = date(ro, "nextDate", rp, true);
                    r.anchorDay = CivilDate.day(r.startDate);
                    r.nextIndex = 0;
                }
                r.paused = ro.bool("paused", false);
                r.pausedAt = r.paused ? dateOrNull(ro, "pausedAt", rp) : null;
                r.pauseUntil = r.paused ? dateOrNull(ro, "pauseUntil", rp) : null;
                r.endDate = dateOrNull(ro,"endDate",rp);
                LedgerRepo.validateEndDate(r.startDate,r.endDate);
                r.note = text(ro, "note", LedgerRepo.MAX_NOTE, rp);
                String k = ruleKey(r);
                Integer have = existingRules.get(k);
                if (have != null && have > 0) {
                    existingRules.put(k, have - 1);
                    pc.duplicateRules++;
                } else {
                    pc.newRules.add(r);
                }
            }
            plan.cards.add(pc);
        }
        return plan;
    }

    /** Writes the plan atomically. Returns the number of transactions added. */
    public static int apply(final LedgerRepo repo, final Plan plan) {
        final Db db = repo.db();
        final int[] added = {0};
        db.transaction(new Runnable() {
            @Override public void run() {
                long now = System.currentTimeMillis();
                for (PlanCard pc : plan.cards) {
                    long cardId;
                    if (pc.existingId != null) {
                        if (repo.getCard(pc.existingId) == null) throw new IllegalStateException("Card changed during import");
                        cardId = pc.existingId;
                    } else {
                        if (repo.findCardByName(pc.name, -1) != null) throw new IllegalStateException("Card changed during import");
                        cardId = db.insert("INSERT INTO cards(name, billing_day, created_at) VALUES (?,?,?)",
                                pc.name, pc.billingDay, now);
                    }
                    for (Txn t : pc.newTxns) {
                        db.insert("INSERT INTO txns(card_id, type, amount, date, description, note, created_at)"
                                + " VALUES (?,?,?,?,?,?,?)", cardId, t.type, t.amount, t.date, t.description, t.note, now);
                        added[0]++;
                    }
                    for (Rule r : pc.newRules) {
                        db.insert("INSERT INTO rules(card_id, name, amount, frequency, start_date, anchor_day,"
                                        + " next_index, paused, paused_at, pause_until, note, created_at, end_date)"
                                        + " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                                cardId, r.name, r.amount, r.frequency, r.startDate, r.anchorDay, r.nextIndex,
                                r.paused ? 1 : 0, r.pausedAt, r.pauseUntil, r.note, now, r.endDate);
                    }
                }
            }
        });
        return added[0];
    }

    // ================================================================ helpers

    static String txnKey(Txn t) {
        return t.type + "|" + t.amount + "|" + t.date + "|" + t.description.trim().toLowerCase()
                + "|" + t.note.trim().toLowerCase();
    }

    static String ruleKey(Rule r) {
        return r.name.trim().toLowerCase() + "|" + r.amount + "|" + r.frequency + "|" + r.startDate + "|" + r.anchorDay + "|" + r.endDate;
    }

    private static void increment(Map<String, Integer> m, String k) {
        Integer v = m.get(k);
        m.put(k, v == null ? 1 : v + 1);
    }

    private static long date(Json.Obj o, String k, String path, boolean required) {
        try {
            return CivilDate.parseIso(o.str(k, required));
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException(path + "." + k + ": " + e.getMessage());
        }
    }

    private static Long dateOrNull(Json.Obj o, String k, String path) {
        if (!o.has(k)) return null;
        return date(o, k, path, true);
    }

    private static String text(Json.Obj o, String k, int max, String path) {
        try {
            return LedgerRepo.cleanText(o.str(k, false), max, k);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException(path + "." + k + ": " + e.getMessage());
        }
    }
}
