package com.apkbench.app.core;

/** SQLite schema shared by the app and the JVM tests. */
public final class Schema {
    private Schema() {}

    public static final int VERSION = 3;
    public static final String END_DATE_SCHEMA = "ALTER TABLE rules ADD COLUMN end_date INTEGER";
    public static final String LINK_SCHEMA = "CREATE TABLE card_links ("
            + "saved_id INTEGER PRIMARY KEY REFERENCES vault(id) ON DELETE CASCADE,"
            + "ledger_id INTEGER NOT NULL UNIQUE REFERENCES cards(id) ON DELETE CASCADE,"
            + "status TEXT NOT NULL CHECK(status IN ('auto','new','review','manual')),"
            + "generated INTEGER NOT NULL DEFAULT 0, auto_name TEXT NOT NULL DEFAULT '')";

    public static String[] upgradesFrom(int oldVersion) {
        if (oldVersion < 1 || oldVersion > VERSION) throw new IllegalArgumentException("Unsupported schema version");
        if (oldVersion < 2) return new String[]{LINK_SCHEMA, END_DATE_SCHEMA};
        return oldVersion < 3 ? new String[]{END_DATE_SCHEMA} : new String[0];
    }

    public static final String[] CREATE = {
            "CREATE TABLE migration_state (name TEXT PRIMARY KEY, value TEXT NOT NULL)",
            "CREATE TABLE cards ("
                    + " id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + " name TEXT NOT NULL,"
                    + " billing_day INTEGER NOT NULL CHECK (billing_day BETWEEN 0 AND 31),"
                    + " created_at INTEGER NOT NULL)",
            "CREATE TABLE txns ("
                    + " id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + " card_id INTEGER NOT NULL REFERENCES cards(id) ON DELETE CASCADE,"
                    + " type INTEGER NOT NULL CHECK (type IN (0,1)),"
                    + " amount INTEGER NOT NULL CHECK (amount > 0),"
                    + " date INTEGER NOT NULL,"
                    + " description TEXT NOT NULL DEFAULT '',"
                    + " note TEXT NOT NULL DEFAULT '',"
                    + " recurring_id INTEGER,"
                    + " occurrence INTEGER,"
                    + " created_at INTEGER NOT NULL)",
            "CREATE INDEX idx_txns_card ON txns(card_id, date)",
            "CREATE UNIQUE INDEX idx_txns_occurrence ON txns(recurring_id, occurrence)",
            "CREATE TABLE rules ("
                    + " id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + " card_id INTEGER NOT NULL REFERENCES cards(id) ON DELETE CASCADE,"
                    + " name TEXT NOT NULL,"
                    + " amount INTEGER NOT NULL CHECK (amount > 0),"
                    + " frequency INTEGER NOT NULL CHECK (frequency IN (0,1,2)),"
                    + " start_date INTEGER NOT NULL,"
                    + " anchor_day INTEGER NOT NULL CHECK (anchor_day BETWEEN 1 AND 31),"
                    + " next_index INTEGER NOT NULL DEFAULT 0,"
                    + " paused INTEGER NOT NULL DEFAULT 0,"
                    + " paused_at INTEGER,"
                    + " pause_until INTEGER,"
                    + " end_date INTEGER,"
                    + " note TEXT NOT NULL DEFAULT '',"
                    + " created_at INTEGER NOT NULL)",
            "CREATE INDEX idx_rules_card ON rules(card_id)",
            "CREATE TABLE vault ("
                    + " id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + " iv BLOB NOT NULL,"
                    + " data BLOB NOT NULL,"
                    + " created_at INTEGER NOT NULL,"
                    + " updated_at INTEGER NOT NULL)",
            LINK_SCHEMA
    };
}
