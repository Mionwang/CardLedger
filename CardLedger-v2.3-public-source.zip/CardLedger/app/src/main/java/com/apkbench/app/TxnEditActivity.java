package com.apkbench.app;

import android.text.InputFilter;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.apkbench.app.core.CivilDate;
import com.apkbench.app.core.LedgerRepo;
import com.apkbench.app.core.Models;
import com.apkbench.app.core.Money;

/** Add or edit an expense or a cashback entry. */
public final class TxnEditActivity extends BaseActivity {
    private long cardId, txnId;
    private int type;
    private long date;
    private EditText amount, description, note;
    private TextView dateField;
    private boolean loaded;

    @Override protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        cardId = getIntent().getLongExtra("card", -1);
        txnId = getIntent().getLongExtra("txn", -1);
        type = getIntent().getIntExtra("type", Models.TYPE_EXPENSE);
        date = CivilDate.today();
    }

    @Override protected boolean rebuildOnResume() { return false; }

    @Override protected View build() {
        Models.Card card = app.ledger().getCard(cardId);
        if (card == null) { finish(); return new View(this); }
        Models.Txn existing = txnId > 0 ? app.ledger().getTxn(txnId) : null;
        if (txnId > 0 && existing == null) { finish(); return new View(this); }
        if (existing != null && !loaded) {
            type = existing.type;
            date = existing.date;
        }
        LinearLayout[] pg = page(existing == null ? (type == Models.TYPE_CASHBACK ? "Add cashback" : "Add expense")
                : "Edit transaction", card.name, true);
        LinearLayout body = pg[1];

        body.addView(Ui.segmented(this, new String[]{"Expense", "Cashback"}, type, new Ui.SegmentListener() {
            @Override public void onSelected(int index) { type = index; }
        }), Ui.margins(this, Ui.matchWrap(), 0, 4, 0, 16));

        amount = Ui.input(this, "0.00", Ui.INPUT_MONEY);
        amount.setTextSize(24);
        amount.setFilters(new InputFilter[]{new InputFilter.LengthFilter(16)});
        body.addView(Ui.field(this, "Amount (" + app.symbol().trim() + ")", amount));

        dateField = Ui.selector(this, CivilDate.display(date), new View.OnClickListener() {
            @Override public void onClick(View v) {
                Dialogs.pickDate(TxnEditActivity.this, date, new Dialogs.DatePicked() {
                    @Override public void picked(long d) {
                        date = d;
                        dateField.setText(CivilDate.display(d));
                    }
                });
            }
        });
        body.addView(Ui.field(this, "Date", dateField));

        description = Ui.input(this, "e.g. Groceries", Ui.INPUT_TEXT);
        description.setFilters(new InputFilter[]{new InputFilter.LengthFilter(LedgerRepo.MAX_TEXT)});
        body.addView(Ui.field(this, "Description", description));

        note = Ui.input(this, "Optional", Ui.INPUT_MULTI);
        note.setFilters(new InputFilter[]{new InputFilter.LengthFilter(LedgerRepo.MAX_NOTE)});
        body.addView(Ui.field(this, "Notes", note));

        if (existing != null && !loaded) {
            amount.setText(Money.toInput(existing.amount));
            description.setText(existing.description);
            note.setText(existing.note);
        }
        loaded = true;
        if (existing != null && existing.recurringId != null) {
            body.addView(Ui.muted(this, "Added automatically by a recurring payment. Editing it here doesn't change the rule."),
                    Ui.margins(this, Ui.matchWrap(), 2, 0, 0, 14));
        }

        body.addView(Ui.button(this, existing == null ? "Add" : "Save", Ui.PRIMARY, new View.OnClickListener() {
            @Override public void onClick(View v) { save(); }
        }), Ui.margins(this, Ui.matchWrap(), 0, 6, 0, 10));
        if (existing != null) {
            body.addView(Ui.button(this, "Delete", Ui.DANGER_STYLE, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Dialogs.confirm(TxnEditActivity.this, "Delete transaction?", "This can't be undone.", "Delete", true,
                            new Dialogs.Done() {
                                @Override public void run() {
                                    app.ledger().deleteTxn(txnId);
                                    finish();
                                }
                            });
                }
            }));
        }
        if (existing == null) amount.requestFocus();
        return pg[0];
    }

    private void save() {
        long minor;
        try {
            minor = Money.parsePositive(amount.getText().toString());
        } catch (IllegalArgumentException e) {
            Ui.error(amount, e.getMessage());
            return;
        }
        try {
            if (txnId > 0) {
                app.ledger().updateTxn(txnId, type, minor, date, description.getText().toString(), note.getText().toString());
            } else {
                app.ledger().addTxn(cardId, type, minor, date, description.getText().toString(), note.getText().toString());
            }
            finish();
        } catch (IllegalArgumentException e) {
            String m = e.getMessage();
            if (m != null && m.startsWith("Description")) Ui.error(description, m);
            else if (m != null && m.startsWith("Notes")) Ui.error(note, m);
            else Ui.error(amount, m);
        }
    }
}
