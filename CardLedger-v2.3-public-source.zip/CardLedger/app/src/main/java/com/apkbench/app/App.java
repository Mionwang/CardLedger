package com.apkbench.app;

import android.app.Activity;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.telephony.TelephonyManager;

import com.apkbench.app.core.CivilDate;
import com.apkbench.app.core.Currencies;
import com.apkbench.app.core.LedgerRepo;
import com.apkbench.app.core.Money;
import com.apkbench.app.core.VaultCipher;
import com.apkbench.app.core.VaultRepo;

/**
 * Process-wide state: database, repositories, lock state and currency.
 * The app starts locked and re-locks whenever it leaves the foreground
 * or the screen turns off.
 */
public final class App extends Application {
    private static App instance;

    private LedgerRepo ledger;
    private VaultRepo vault;
    private SharedPreferences prefs;
    private AndroidDb db;
    private com.apkbench.app.core.CardLinks cardLinks;
    private byte[] sessionKey;

    private boolean locked = true;
    private int started;
    private long externalSince;          // > 0 while a trusted system screen (file picker etc.) is open
    private static final long EXTERNAL_GRACE_MS = 5 * 60 * 1000L;

    public static App get() { return instance; }

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        Ui.init(this);
        db = new AndroidDb(this);
        cardLinks = new com.apkbench.app.core.CardLinks(db);
        ledger = new LedgerRepo(db);
        vault = new VaultRepo(db, new VaultCipher(new KeystoreKeys()));
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        if (!prefs.contains("currency")) {
            String original = getSharedPreferences("display_settings", MODE_PRIVATE).getString("currency_code", null);
            if (original != null) prefs.edit().putString("currency", original).apply();
        }

        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override public void onActivityStarted(Activity a) {
                if (started == 0 && externalSince > 0) {
                    if (SystemClock.elapsedRealtime() - externalSince > EXTERNAL_GRACE_MS) lock();
                    externalSince = 0;
                }
                started++;
            }

            @Override public void onActivityStopped(Activity a) {
                started = Math.max(0, started - 1);
                if (started == 0 && !a.isChangingConfigurations() && externalSince == 0) lock();
            }

            @Override public void onActivityCreated(Activity a, Bundle b) { }
            @Override public void onActivityResumed(Activity a) { }
            @Override public void onActivityPaused(Activity a) { }
            @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
            @Override public void onActivityDestroyed(Activity a) { }
        });

        BroadcastReceiver screenOff = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                externalSince = 0;
                lock();
            }
        };
        IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        boolean registered = false;
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            try { // RECEIVER_NOT_EXPORTED (system broadcasts are still delivered)
                Context.class.getMethod("registerReceiver", BroadcastReceiver.class, IntentFilter.class, int.class)
                        .invoke(this, screenOff, filter, 0x4);
                registered = true;
            } catch (Exception ignored) {
                // fall back below
            }
        }
        if (!registered) registerReceiver(screenOff, filter);
    }

    // ------------------------------------------------------------ lock

    public boolean isLocked() { return locked; }

    public void lock() {
        locked = true;
        if (sessionKey != null) java.util.Arrays.fill(sessionKey, (byte) 0);
        sessionKey = null;
        ClipboardGuard.onLock(this);
    }

    public void unlock() {
        try {
            byte[] key = LegacyCrypto.unlock(this);
            if (sessionKey != null) java.util.Arrays.fill(sessionKey, (byte) 0);
            sessionKey = key;
            java.io.File original = getDatabasePath("card_ledger.db");
            if (original.exists() && !com.apkbench.app.core.LegacyUpgrade.isComplete(db)) {
                try (AndroidDb old = new AndroidDb(android.database.sqlite.SQLiteDatabase.openDatabase(
                        original.getPath(), null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY))) {
                    com.apkbench.app.core.LegacyUpgrade.migrate(old, db);
                }
            }
            locked = false;
            processRecurring();
        } catch (Exception e) {
            lock();
            throw new IllegalStateException("Could not open Card Ledger. Existing data has been preserved.", e);
        }
    }

    synchronized javax.crypto.SecretKey vaultKey() {
        if (sessionKey == null || locked) throw new IllegalStateException("App is locked");
        return new javax.crypto.spec.SecretKeySpec(sessionKey, "AES");
    }

    /** Refuse to create a replacement vault key if encrypted records already exist. */
    boolean hasStoredVaultRows() {
        if (db.query("SELECT COUNT(*) AS n FROM vault").get(0).getLong("n") > 0) return true;
        java.io.File original = getDatabasePath("card_ledger.db");
        if (!original.exists()) return false;
        try (AndroidDb old = new AndroidDb(android.database.sqlite.SQLiteDatabase.openDatabase(
                original.getPath(), null, android.database.sqlite.SQLiteDatabase.OPEN_READONLY))) {
            if (old.query("SELECT name FROM sqlite_master WHERE type='table' AND name='saved_cards'").isEmpty()) return false;
            return old.query("SELECT COUNT(*) AS n FROM saved_cards").get(0).getLong("n") > 0;
        }
    }

    /** Call right before launching a system screen we expect to return from (file picker, settings). */
    public void expectExternal() { externalSince = SystemClock.elapsedRealtime(); }

    // ------------------------------------------------------------ data

    public LedgerRepo ledger() { return ledger; }
    public VaultRepo vault() { return vault; }
    public com.apkbench.app.core.CardLinks links() { return cardLinks; }

    public void syncCardLinks() {
        if (!locked && sessionKey != null) cardLinks.sync(vault.load().cards);
    }

    /** Posts any due recurring payments (including missed ones). Cheap when nothing is due. */
    public int processRecurring() {
        syncCardLinks();
        long today = CivilDate.today();
        int n = ledger.processDue(today);
        return n;
    }

    // ------------------------------------------------------------ currency

    public String currencyPref() { return prefs.getString("currency", Currencies.AUTO); }

    public void setCurrencyPref(String pref) { prefs.edit().putString("currency", pref).apply(); }

    public String simCountry() {
        try {
            TelephonyManager tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
            return tm == null ? null : tm.getSimCountryIso();
        } catch (RuntimeException e) {
            return null;
        }
    }

    public String currencyCode() { return Currencies.resolve(currencyPref(), simCountry()); }

    public String symbol() { return Currencies.symbol(currencyCode()); }

    public String money(long minor) {
        String code = currencyCode();
        return Money.format(minor, Currencies.symbol(code), Currencies.indianGrouping(code));
    }

    public SharedPreferences prefs() { return prefs; }
}
