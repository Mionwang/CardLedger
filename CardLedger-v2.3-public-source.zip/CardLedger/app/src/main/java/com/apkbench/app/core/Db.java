package com.apkbench.app.core;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Minimal SQL abstraction so the same repository code runs on Android's SQLite
 * (app) and on SQLite via JDBC (JVM tests).
 */
public interface Db {
    /** INSERT; returns the new row id. */
    long insert(String sql, Object... args);

    /** UPDATE/DELETE; returns affected rows. */
    int exec(String sql, Object... args);

    /** SELECT; rows are fully materialized. */
    List<Row> query(String sql, Object... args);

    /** Runs {@code work} atomically: all changes commit or none do. Nested calls join the outer transaction. */
    void transaction(Runnable work);

    final class Row {
        private final Map<String, Integer> index;
        private final Object[] values;

        public Row(Map<String, Integer> index, Object[] values) {
            this.index = index;
            this.values = values;
        }

        public static Map<String, Integer> indexOf(String[] columns) {
            Map<String, Integer> m = new HashMap<String, Integer>();
            for (int i = 0; i < columns.length; i++) m.put(columns[i].toLowerCase(), i);
            return m;
        }

        private Object raw(String col) {
            Integer i = index.get(col.toLowerCase());
            if (i == null) throw new IllegalArgumentException("No column " + col);
            return values[i];
        }

        public boolean isNull(String col) { return raw(col) == null; }

        public long getLong(String col) {
            Object v = raw(col);
            if (v == null) return 0;
            if (v instanceof Number) return ((Number) v).longValue();
            return Long.parseLong(v.toString());
        }

        public Long getLongOrNull(String col) {
            Object v = raw(col);
            if (v == null) return null;
            return getLong(col);
        }

        public int getInt(String col) { return (int) getLong(col); }

        public String getString(String col) {
            Object v = raw(col);
            return v == null ? null : v.toString();
        }

        public byte[] getBlob(String col) {
            Object v = raw(col);
            return (byte[]) v;
        }
    }
}
