package com.apkbench.app.core;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

/**
 * Reads the publicly readable details (number, expiry, sometimes cardholder name)
 * from contactless EMV cards over ISO-DEP. This is the same data any payment
 * terminal can read; no keys or PINs are involved. Many cards omit the name.
 */
public final class Emv {
    private Emv() {}

    public interface Transceiver { byte[] transceive(byte[] apdu) throws IOException; }

    public static final class Result {
        public String number;
        public int expMonth;
        public int expYear;
        public String holder = "";
        public String network = "";
        public String label = "";
    }

    // ================================================================ TLV

    public static final class Tlv {
        public final int tag;
        public final byte[] value;
        public final boolean constructed;
        public final List<Tlv> children = new ArrayList<Tlv>();

        Tlv(int tag, byte[] value, boolean constructed) {
            this.tag = tag;
            this.value = value;
            this.constructed = constructed;
        }
    }

    /** Parses BER-TLV; constructed objects are parsed recursively. Malformed tails are ignored. */
    public static List<Tlv> parse(byte[] b) { return parse(b, 0, b.length, 0); }

    private static List<Tlv> parse(byte[] b, int off, int end, int depth) {
        List<Tlv> out = new ArrayList<Tlv>();
        int i = off;
        while (i < end) {
            int first = b[i] & 0xFF;
            if (first == 0x00 || first == 0xFF) { i++; continue; } // padding
            int tag = first;
            i++;
            if ((first & 0x1F) == 0x1F) {
                while (i < end) {
                    int nb = b[i++] & 0xFF;
                    tag = (tag << 8) | nb;
                    if ((nb & 0x80) == 0) break;
                }
            }
            if (i >= end) break;
            int len = b[i++] & 0xFF;
            if (len == 0x81) {
                if (i >= end) break;
                len = b[i++] & 0xFF;
            } else if (len == 0x82) {
                if (i + 1 >= end) break;
                len = ((b[i] & 0xFF) << 8) | (b[i + 1] & 0xFF);
                i += 2;
            } else if (len > 0x82) {
                break;
            }
            if (i + len > end) break;
            byte[] v = new byte[len];
            System.arraycopy(b, i, v, 0, len);
            boolean constructed = (first & 0x20) != 0;
            Tlv t = new Tlv(tag, v, constructed);
            if (constructed && depth < 10) t.children.addAll(parse(b, i, i + len, depth + 1));
            out.add(t);
            i += len;
        }
        return out;
    }

    public static Tlv find(List<Tlv> list, int tag) {
        for (Tlv t : list) {
            if (t.tag == tag) return t;
            Tlv c = find(t.children, tag);
            if (c != null) return c;
        }
        return null;
    }

    public static void findAll(List<Tlv> list, int tag, List<Tlv> out) {
        for (Tlv t : list) {
            if (t.tag == tag) out.add(t);
            findAll(t.children, tag, out);
        }
    }

    // ================================================================ reading

    private static final byte[] PPSE = "2PAY.SYS.DDF01".getBytes(Charset.forName("US-ASCII"));

    private static final String[][] KNOWN_AIDS = {
            {"A0000000031010", "Visa"}, {"A0000000032010", "Visa"}, {"A0000000033010", "Visa"},
            {"A0000000041010", "Mastercard"}, {"A0000000043060", "Maestro"}, {"A0000000042203", "Mastercard"},
            {"A0000005241010", "RuPay"}, {"A00000002501", "American Express"},
            {"A0000001523010", "Discover"}, {"A0000000651010", "JCB"},
            {"A000000333010101", "UnionPay"}, {"A000000333010102", "UnionPay"},
    };

    public static String networkForAid(byte[] aid) {
        String h = hex(aid);
        if (h.startsWith("A000000003")) return "Visa";
        if (h.startsWith("A0000000043060")) return "Maestro";
        if (h.startsWith("A000000004")) return "Mastercard";
        if (h.startsWith("A000000524")) return "RuPay";
        if (h.startsWith("A000000025")) return "American Express";
        if (h.startsWith("A000000152")) return "Discover";
        if (h.startsWith("A000000065")) return "JCB";
        if (h.startsWith("A000000333")) return "UnionPay";
        return "";
    }

    /** Runs the read sequence. Throws IOException if no card details could be found. */
    public static Result read(Transceiver io) throws IOException {
        List<byte[]> aids = new ArrayList<byte[]>();
        byte[] ppse = command(io, select(PPSE));
        if (ppse != null) {
            List<Tlv> entries = new ArrayList<Tlv>();
            findAll(parse(ppse), 0x4F, entries);
            for (Tlv t : entries) aids.add(t.value);
        }
        if (aids.isEmpty()) {
            for (String[] k : KNOWN_AIDS) aids.add(unhex(k[0]));
        }
        IOException last = null;
        for (byte[] aid : aids) {
            try {
                Result r = readApplication(io, aid);
                if (r != null) return r;
            } catch (IOException e) {
                last = e;
            }
        }
        if (last != null) throw last;
        throw new IOException("No readable payment application on this card");
    }

    private static Result readApplication(Transceiver io, byte[] aid) throws IOException {
        byte[] fci = command(io, select(aid));
        if (fci == null) return null;
        List<Tlv> fciTlv = parse(fci);
        Result res = new Result();
        res.network = networkForAid(aid);
        Tlv label = find(fciTlv, 0x50);
        if (label != null) res.label = ascii(label.value).trim();

        List<List<Tlv>> collected = new ArrayList<List<Tlv>>();
        Tlv pdol = find(fciTlv, 0x9F38);
        byte[] gpo = command(io, gpo(pdol == null ? new byte[0] : pdolData(pdol.value)));
        byte[] afl = null;
        if (gpo != null) {
            List<Tlv> g = parse(gpo);
            collected.add(g);
            Tlv f1 = find(g, 0x80);
            if (f1 != null && f1.value.length > 2) {
                afl = new byte[f1.value.length - 2];
                System.arraycopy(f1.value, 2, afl, 0, afl.length);
            } else {
                Tlv a = find(g, 0x94);
                if (a != null) afl = a.value;
            }
        }
        if (!fill(res, collected)) {
            if (afl != null && afl.length >= 4) {
                for (int i = 0; i + 3 < afl.length; i += 4) {
                    int sfi = (afl[i] & 0xFF) >> 3;
                    int firstRec = afl[i + 1] & 0xFF, lastRec = afl[i + 2] & 0xFF;
                    for (int rec = firstRec; rec <= lastRec && rec <= 16; rec++) {
                        byte[] data = command(io, readRecord(sfi, rec));
                        if (data != null) collected.add(parse(data));
                    }
                }
            } else {
                for (int sfi = 1; sfi <= 4; sfi++) {
                    for (int rec = 1; rec <= 5; rec++) {
                        byte[] data = command(io, readRecord(sfi, rec));
                        if (data != null) collected.add(parse(data));
                    }
                }
            }
            if (!fill(res, collected)) return null;
        } else {
            fill(res, collected);
        }
        return res;
    }

    /** Fills number/expiry/name from collected TLVs; returns true when number and expiry are known. */
    static boolean fill(Result r, List<List<Tlv>> all) {
        for (List<Tlv> l : all) {
            if (r.number == null) {
                Tlv pan = find(l, 0x5A);
                if (pan != null) r.number = bcdDigits(pan.value);
            }
            if (r.expMonth == 0) {
                Tlv exp = find(l, 0x5F24);
                if (exp != null && exp.value.length >= 2) {
                    String d = bcdDigits(exp.value);
                    if (d.length() >= 4) setExpiry(r, d.substring(0, 2), d.substring(2, 4));
                }
            }
            Tlv t2 = find(l, 0x57);
            if (t2 == null) t2 = find(l, 0x9F6B);
            if (t2 != null) {
                String h = hex(t2.value);
                int sep = h.indexOf('D');
                if (sep > 0) {
                    if (r.number == null) r.number = h.substring(0, sep);
                    if (r.expMonth == 0 && h.length() >= sep + 5) setExpiry(r, h.substring(sep + 1, sep + 3), h.substring(sep + 3, sep + 5));
                }
            }
            if (r.holder.isEmpty()) {
                Tlv name = find(l, 0x5F20);
                if (name == null) name = find(l, 0x9F0B);
                if (name != null) r.holder = cleanName(ascii(name.value));
            }
        }
        if (r.number != null) {
            String d = CardInfo.digitsOnly(r.number);
            r.number = d == null ? null : d;
        }
        return r.number != null && r.number.length() >= 12 && r.expMonth > 0;
    }

    private static void setExpiry(Result r, String yy, String mm) {
        try {
            int y = Integer.parseInt(yy), m = Integer.parseInt(mm);
            if (m >= 1 && m <= 12) {
                r.expMonth = m;
                r.expYear = 2000 + y;
            }
        } catch (NumberFormatException ignored) {
            // leave unset
        }
    }

    static String cleanName(String s) {
        String t = s.replace('/', ' ').trim().replaceAll("\\s+", " ");
        // EMV names are "SURNAME/GIVEN"; many cards send a placeholder
        if (t.isEmpty() || t.equalsIgnoreCase("CARDHOLDER") || t.matches("[^A-Za-z]*")) return "";
        int slash = s.indexOf('/');
        if (slash > 0) {
            String sur = s.substring(0, slash).trim(), given = s.substring(slash + 1).trim();
            if (!given.isEmpty() && !sur.isEmpty()) return (given + " " + sur).replaceAll("\\s+", " ");
        }
        return t;
    }

    // ================================================================ APDUs

    /** Sends an APDU, handling 61xx / 6Cxx; returns data on 9000 else null. */
    static byte[] command(Transceiver io, byte[] apdu) throws IOException {
        byte[] r = io.transceive(apdu);
        for (int guard = 0; guard < 8 && r != null && r.length >= 2; guard++) {
            int sw1 = r[r.length - 2] & 0xFF, sw2 = r[r.length - 1] & 0xFF;
            if (sw1 == 0x61) {
                r = io.transceive(new byte[]{0x00, (byte) 0xC0, 0x00, 0x00, (byte) sw2});
            } else if (sw1 == 0x6C) {
                byte[] again = apdu.clone();
                again[again.length - 1] = (byte) sw2;
                r = io.transceive(again);
            } else {
                break;
            }
        }
        if (r == null || r.length < 2) return null;
        int sw1 = r[r.length - 2] & 0xFF, sw2 = r[r.length - 1] & 0xFF;
        if (sw1 != 0x90 || sw2 != 0x00) return null;
        byte[] data = new byte[r.length - 2];
        System.arraycopy(r, 0, data, 0, data.length);
        return data;
    }

    static byte[] select(byte[] name) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(0x00); o.write(0xA4); o.write(0x04); o.write(0x00);
        o.write(name.length);
        o.write(name, 0, name.length);
        o.write(0x00);
        return o.toByteArray();
    }

    static byte[] gpo(byte[] pdolData) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(0x80); o.write(0xA8); o.write(0x00); o.write(0x00);
        o.write(pdolData.length + 2);
        o.write(0x83);
        o.write(pdolData.length);
        o.write(pdolData, 0, pdolData.length);
        o.write(0x00);
        return o.toByteArray();
    }

    static byte[] readRecord(int sfi, int rec) {
        return new byte[]{0x00, (byte) 0xB2, (byte) rec, (byte) ((sfi << 3) | 0x04), 0x00};
    }

    /** Builds PDOL data with neutral terminal values (zero amount, read-only intent). */
    static byte[] pdolData(byte[] dol) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        int i = 0;
        Random rnd = new Random();
        Calendar cal = Calendar.getInstance();
        while (i < dol.length) {
            int first = dol[i++] & 0xFF;
            int tag = first;
            if ((first & 0x1F) == 0x1F) {
                while (i < dol.length) {
                    int nb = dol[i++] & 0xFF;
                    tag = (tag << 8) | nb;
                    if ((nb & 0x80) == 0) break;
                }
            }
            if (i >= dol.length) break;
            int len = dol[i++] & 0xFF;
            byte[] v = new byte[len];
            switch (tag) {
                case 0x9F66: // Terminal Transaction Qualifiers: contactless EMV + magstripe, online capable
                    put(v, new byte[]{(byte) 0xF6, 0x20, (byte) 0xC0, 0x00});
                    break;
                case 0x9F1A: // terminal country (India)
                case 0x5F2A: // transaction currency (INR)
                    put(v, new byte[]{0x03, 0x56});
                    break;
                case 0x9A: // date YYMMDD (BCD)
                    put(v, new byte[]{bcd(cal.get(Calendar.YEAR) % 100), bcd(cal.get(Calendar.MONTH) + 1),
                            bcd(cal.get(Calendar.DAY_OF_MONTH))});
                    break;
                case 0x9F37: // unpredictable number
                    rnd.nextBytes(v);
                    break;
                case 0x9F35: // terminal type
                    put(v, new byte[]{0x22});
                    break;
                case 0x9F33: // terminal capabilities
                    put(v, new byte[]{(byte) 0xE0, (byte) 0xA0, 0x00});
                    break;
                case 0x9F40:
                    put(v, new byte[]{(byte) 0x8E, 0x00, (byte) 0xB0, 0x50, 0x05});
                    break;
                default:
                    // zero-filled: amounts (9F02/9F03), TVR (95), type (9C), etc.
                    break;
            }
            o.write(v, 0, v.length);
        }
        return o.toByteArray();
    }

    private static void put(byte[] dst, byte[] src) {
        System.arraycopy(src, 0, dst, 0, Math.min(dst.length, src.length));
    }

    private static byte bcd(int v) { return (byte) (((v / 10) << 4) | (v % 10)); }

    // ================================================================ encoding helpers

    static String bcdDigits(byte[] v) {
        String h = hex(v);
        int f = h.indexOf('F');
        return f >= 0 ? h.substring(0, f) : h;
    }

    public static String hex(byte[] b) {
        StringBuilder s = new StringBuilder();
        for (byte x : b) {
            s.append(Character.toUpperCase(Character.forDigit((x >> 4) & 0xF, 16)));
            s.append(Character.toUpperCase(Character.forDigit(x & 0xF, 16)));
        }
        return s.toString();
    }

    public static byte[] unhex(String h) {
        byte[] out = new byte[h.length() / 2];
        for (int i = 0; i < out.length; i++) out[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16);
        return out;
    }

    private static String ascii(byte[] v) {
        StringBuilder b = new StringBuilder();
        for (byte x : v) {
            int c = x & 0xFF;
            if (c >= 0x20 && c < 0x7F) b.append((char) c);
        }
        return b.toString();
    }
}
