package com.apkbench.app.core;

import java.util.Calendar;

/**
 * Calendar date arithmetic on epoch days (days since 1970-01-01), independent of
 * time zones and of java.time (unavailable before Android 8).
 * Uses Howard Hinnant's proleptic Gregorian algorithms.
 */
public final class CivilDate {
    private CivilDate() {}

    private static final String[] MONTHS = {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    private static final String[] WEEKDAYS = {"Monday", "Tuesday", "Wednesday", "Thursday",
            "Friday", "Saturday", "Sunday"};

    public static boolean isLeap(int y) {
        return (y % 4 == 0 && y % 100 != 0) || y % 400 == 0;
    }

    public static int daysInMonth(int y, int m) {
        switch (m) {
            case 2: return isLeap(y) ? 29 : 28;
            case 4: case 6: case 9: case 11: return 30;
            default: return 31;
        }
    }

    public static long of(int y, int m, int d) {
        if (m < 1 || m > 12) throw new IllegalArgumentException("Invalid month");
        if (d < 1 || d > daysInMonth(y, m)) throw new IllegalArgumentException("Invalid day");
        int yy = m <= 2 ? y - 1 : y;
        long era = (yy >= 0 ? yy : yy - 399) / 400;
        long yoe = yy - era * 400;
        long mp = (m + 9) % 12;
        long doy = (153 * mp + 2) / 5 + d - 1;
        long doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
        return era * 146097 + doe - 719468;
    }

    /** Date with day clamped to the month's length (e.g. 31 Feb -> 28/29 Feb). */
    public static long clamped(int y, int m, int d) {
        return of(y, m, Math.max(1, Math.min(d, daysInMonth(y, m))));
    }

    /** Returns {year, month(1-12), day}. */
    public static int[] ymd(long epochDay) {
        long z = epochDay + 719468;
        long era = (z >= 0 ? z : z - 146096) / 146097;
        long doe = z - era * 146097;
        long yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
        long y = yoe + era * 400;
        long doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
        long mp = (5 * doy + 2) / 153;
        long d = doy - (153 * mp + 2) / 5 + 1;
        long m = mp < 10 ? mp + 3 : mp - 9;
        if (m <= 2) y++;
        return new int[]{(int) y, (int) m, (int) d};
    }

    public static int year(long e) { return ymd(e)[0]; }
    public static int month(long e) { return ymd(e)[1]; }
    public static int day(long e) { return ymd(e)[2]; }

    /** 0 = Monday ... 6 = Sunday */
    public static int dayOfWeek(long epochDay) {
        // 1970-01-01 was a Thursday (index 3)
        long r = (epochDay + 3) % 7;
        if (r < 0) r += 7;
        return (int) r;
    }

    public static String weekdayName(long epochDay) { return WEEKDAYS[dayOfWeek(epochDay)]; }

    /** Adds months keeping {@code anchorDay} where possible, clamping to month length. */
    public static long addMonths(long epochDay, int months, int anchorDay) {
        int[] p = ymd(epochDay);
        long total = (long) p[0] * 12 + (p[1] - 1) + months;
        long q = total / 12, r = total % 12;
        if (r < 0) { r += 12; q--; }
        int y = (int) q;
        int m = (int) r + 1;
        return clamped(y, m, anchorDay);
    }

    public static long addMonths(long epochDay, int months) {
        return addMonths(epochDay, months, day(epochDay));
    }

    public static String iso(long epochDay) {
        int[] p = ymd(epochDay);
        return pad(p[0], 4) + "-" + pad(p[1], 2) + "-" + pad(p[2], 2);
    }

    public static long parseIso(String s) {
        if (s == null) throw new IllegalArgumentException("Date is required");
        s = s.trim();
        if (s.length() != 10 || s.charAt(4) != '-' || s.charAt(7) != '-') {
            throw new IllegalArgumentException("Date must be YYYY-MM-DD");
        }
        try {
            int y = Integer.parseInt(s.substring(0, 4));
            int m = Integer.parseInt(s.substring(5, 7));
            int d = Integer.parseInt(s.substring(8, 10));
            if (y < 1900 || y > 2200) throw new IllegalArgumentException("Year out of range");
            return of(y, m, d);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Date must be YYYY-MM-DD");
        }
    }

    /** "19 Oct 2026" */
    public static String display(long epochDay) {
        int[] p = ymd(epochDay);
        return p[2] + " " + MONTHS[p[1] - 1] + " " + p[0];
    }

    /** "19 Oct" */
    public static String displayShort(long epochDay) {
        int[] p = ymd(epochDay);
        return p[2] + " " + MONTHS[p[1] - 1];
    }

    public static String monthName(int m) { return MONTHS[m - 1]; }

    public static String ordinal(int n) {
        int mod100 = n % 100;
        if (mod100 >= 11 && mod100 <= 13) return n + "th";
        switch (n % 10) {
            case 1: return n + "st";
            case 2: return n + "nd";
            case 3: return n + "rd";
            default: return n + "th";
        }
    }

    /** Today in the device's local time zone. */
    public static long today() {
        Calendar c = Calendar.getInstance();
        return of(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    private static String pad(int v, int w) {
        String s = String.valueOf(v);
        while (s.length() < w) s = "0" + s;
        return s;
    }
}
