package com.apkbench.app;

import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PersistableBundle;

import java.lang.reflect.Method;

/**
 * Copies a card number to the clipboard and tries to clear it 30 seconds later.
 * The clip is marked sensitive (Android 13+ hides it from clipboard previews).
 * Clearing only happens if the clipboard still holds our value, as far as the
 * system lets the app check; newer Android versions restrict clipboard reads in
 * the background, so this is best-effort.
 */
final class ClipboardGuard {
    private ClipboardGuard() {}

    static final long CLEAR_AFTER_MS = 30_000L;
    private static final String LABEL = "Card Ledger card number";

    private static final Handler HANDLER = new Handler(Looper.getMainLooper());
    private static Runnable pending;
    private static boolean changedSinceCopy;
    private static ClipboardManager.OnPrimaryClipChangedListener listener;

    static void copy(final Context ctx, String value) {
        final ClipboardManager cm = (ClipboardManager) ctx.getApplicationContext().getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null) return;
        ClipData clip = ClipData.newPlainText(LABEL, value);
        markSensitive(clip.getDescription());
        if (listener != null) cm.removePrimaryClipChangedListener(listener);
        cm.setPrimaryClip(clip);
        changedSinceCopy = false;
        final long copiedAt = android.os.SystemClock.elapsedRealtime();
        listener = new ClipboardManager.OnPrimaryClipChangedListener() {
            @Override public void onPrimaryClipChanged() {
                // ignore the notification for our own copy
                if (android.os.SystemClock.elapsedRealtime() - copiedAt > 1000) changedSinceCopy = true;
            }
        };
        cm.addPrimaryClipChangedListener(listener);
        if (pending != null) HANDLER.removeCallbacks(pending);
        pending = new Runnable() {
            @Override public void run() { clear(cm); }
        };
        HANDLER.postDelayed(pending, CLEAR_AFTER_MS);
    }

    /** Called on lock: if a copy is pending, leave the timer running (it still clears). */
    static void onLock(Context ctx) { }

    private static void clear(ClipboardManager cm) {
        pending = null;
        if (listener != null) {
            cm.removePrimaryClipChangedListener(listener);
            listener = null;
        }
        if (changedSinceCopy) return; // user copied something else; leave it alone
        boolean ours = true;
        try {
            ClipData current = cm.getPrimaryClip();
            if (current != null) {
                CharSequence label = current.getDescription().getLabel();
                ours = label != null && LABEL.contentEquals(label);
            }
            // null usually means the system hid it from a background app; assume still ours
        } catch (RuntimeException ignored) {
            // reading denied; fall through
        }
        if (!ours) return;
        try {
            if (Build.VERSION.SDK_INT >= 28) {
                Method m = ClipboardManager.class.getMethod("clearPrimaryClip");
                m.invoke(cm);
            } else {
                cm.setPrimaryClip(ClipData.newPlainText("", ""));
            }
        } catch (Exception e) {
            try { cm.setPrimaryClip(ClipData.newPlainText("", "")); } catch (RuntimeException ignored) { }
        }
    }

    private static void markSensitive(ClipDescription d) {
        if (Build.VERSION.SDK_INT < 24) return;
        try {
            PersistableBundle extras = new PersistableBundle();
            extras.putBoolean("android.content.extra.IS_SENSITIVE", true);
            Method m = ClipDescription.class.getMethod("setExtras", PersistableBundle.class);
            m.invoke(d, extras);
        } catch (Exception ignored) {
            // older platform
        }
    }
}
