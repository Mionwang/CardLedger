package com.apkbench.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Lock screen. Unlocks with the system biometric prompt (fingerprint etc.) or the
 * device PIN / pattern / password. The app never sees or stores the credential;
 * it only receives success or failure from the system.
 */
public final class LockActivity extends Activity {
    private static final int REQ_KEYGUARD = 41;

    private TextView status;
    private TextView unlockButton;
    private CancellationSignal cancel;
    private AlertDialog fingerprintDialog;
    private boolean prompting;
    private boolean autoPrompted;

    static void show(Activity from) { show(from, true); }

    /** @param autoPrompt false for the manual Lock button, so the prompt doesn't pop up immediately */
    static void show(Activity from, boolean autoPrompt) {
        // singleTop (manifest + flag) prevents stacking several lock screens
        Intent i = new Intent(from, LockActivity.class);
        i.putExtra("autoPrompt", autoPrompt);
        i.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        from.startActivity(i);
        from.overridePendingTransition(0, 0);
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        BaseActivity.edgeToEdge(getWindow(), 3);
        Compat.hideFromRecents(this);
        autoPrompted = b != null ? b.getBoolean("auto", false) : !getIntent().getBooleanExtra("autoPrompt", true);

        Ui.init(this);
        FrameLayout root = new FrameLayout(this);
        root.setFitsSystemWindows(true);
        int side = Ui.dp(this, 28);

        // upper block: name and a huge state word, left-aligned
        LinearLayout top = Ui.col(this);
        top.setPadding(side, Ui.dp(this, 72), side, 0);
        top.addView(Ui.text(this, getString(R.string.app_name), 16, Ui.ACCENT, Ui.MEDIUM));
        TextView big = Ui.text(this, "Locked", 76, Ui.TEXT, Ui.THIN);
        big.setLetterSpacing(-0.04f);
        big.setIncludeFontPadding(false);
        top.addView(big, Ui.margins(this, Ui.matchWrap(), -3, 10, 0, 12));
        status = Ui.text(this, "Use your fingerprint or screen lock.", 16, Ui.MUTED, Ui.SANS);
        top.addView(status, Ui.matchWrap());
        root.addView(top, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));

        // bottom block: one action
        LinearLayout bottom = Ui.col(this);
        bottom.setPadding(side, 0, side, Ui.dp(this, 28));
        unlockButton = Ui.button(this, "Unlock", Ui.PRIMARY, new View.OnClickListener() {
            @Override public void onClick(View v) { authenticate(); }
        });
        bottom.addView(unlockButton, Ui.matchWrap());
        TextView foot = Ui.text(this, "Works offline. Your data never leaves this phone.", 13, Ui.FAINT, Ui.SANS);
        bottom.addView(foot, Ui.margins(this, Ui.matchWrap(), 4, 16, 0, 0));
        root.addView(bottom, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));
        setContentView(root);
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putBoolean("auto", autoPrompted);
    }

    @Override protected void onResume() {
        super.onResume();
        if (!App.get().isLocked()) { done(); return; }
        if (!isDeviceSecure()) {
            showNoLock();
            return;
        }
        unlockButton.setText("Unlock");
        unlockButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { authenticate(); }
        });
        if (!autoPrompted) {
            autoPrompted = true;
            unlockButton.post(new Runnable() {
                @Override public void run() { authenticate(); }
            });
        }
    }

    @Override protected void onPause() {
        super.onPause();
        stopFingerprint();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (cancel != null) cancel.cancel();
    }

    @Override public void onBackPressed() {
        // Leaving the lock screen closes the app instead of revealing content
        finishAffinity();
    }

    private boolean isDeviceSecure() {
        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        return km != null && km.isDeviceSecure();
    }

    private void showNoLock() {
        status.setText("This phone has no screen lock. Set a PIN, pattern, password or fingerprint in Settings, then come back.");
        unlockButton.setText("Open security settings");
        unlockButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                App.get().expectExternal();
                try {
                    startActivity(new Intent(Settings.ACTION_SECURITY_SETTINGS));
                } catch (RuntimeException e) {
                    startActivity(new Intent(Settings.ACTION_SETTINGS));
                }
            }
        });
    }

    private void authenticate() {
        if (prompting) return;
        if (!isDeviceSecure()) { showNoLock(); return; }
        status.setText("Use your fingerprint or screen lock.");
        if (Build.VERSION.SDK_INT >= 29) {
            prompting = true;
            try {
                cancel = BiometricUnlocker.authenticate(this, new BiometricUnlocker.Result() {
                    @Override public void onSuccess() { prompting = false; success(); }
                    @Override public void onCancel() { prompting = false; status.setText("Use your fingerprint or screen lock."); }
                    @Override public void onError(int code, CharSequence message) {
                        prompting = false;
                        status.setText(message == null ? "Authentication unavailable" : message.toString());
                        if (code != 7 && code != 9) deviceCredential(); // not a lockout: offer screen lock
                    }
                });
            } catch (RuntimeException e) {
                prompting = false;
                deviceCredential();
            }
        } else if (fingerprintReady()) {
            startFingerprint();
        } else {
            deviceCredential();
        }
    }

    // ------------------------------------------------------------ Android 6-9 paths

    @SuppressWarnings("deprecation")
    private boolean fingerprintReady() {
        if (checkSelfPermission(Manifest.permission.USE_FINGERPRINT) != PackageManager.PERMISSION_GRANTED) return false;
        FingerprintManager fm = getSystemService(FingerprintManager.class);
        try {
            return fm != null && fm.isHardwareDetected() && fm.hasEnrolledFingerprints();
        } catch (RuntimeException e) {
            return false;
        }
    }

    @SuppressWarnings("deprecation")
    private void startFingerprint() {
        FingerprintManager fm = getSystemService(FingerprintManager.class);
        prompting = true;
        cancel = new CancellationSignal();
        final TextView msg = Ui.body(this, "Touch the fingerprint sensor");
        int p = Ui.dp(this, 24);
        msg.setPadding(p, Ui.dp(this, 16), p, 0);
        fingerprintDialog = new AlertDialog.Builder(this)
                .setTitle("Unlock " + getString(R.string.app_name))
                .setView(msg)
                .setNegativeButton("Use PIN", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        stopFingerprint();
                        deviceCredential();
                    }
                })
                .setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override public void onCancel(DialogInterface d) { stopFingerprint(); }
                })
                .create();
        fingerprintDialog.show();
        fm.authenticate(null, cancel, 0, new FingerprintManager.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult r) {
                prompting = false;
                if (fingerprintDialog != null) fingerprintDialog.dismiss();
                success();
            }

            @Override public void onAuthenticationFailed() { msg.setText("Not recognized. Try again."); }

            @Override public void onAuthenticationHelp(int code, CharSequence help) {
                if (help != null) msg.setText(help);
            }

            @Override public void onAuthenticationError(int code, CharSequence err) {
                prompting = false;
                if (code == FingerprintManager.FINGERPRINT_ERROR_CANCELED) return;
                if (fingerprintDialog != null) fingerprintDialog.dismiss();
                status.setText(err == null ? "Fingerprint unavailable" : err.toString());
                deviceCredential();
            }
        }, null);
    }

    private void stopFingerprint() {
        if (cancel != null && Build.VERSION.SDK_INT < 29) {
            cancel.cancel();
            cancel = null;
        }
        if (fingerprintDialog != null) {
            fingerprintDialog.dismiss();
            fingerprintDialog = null;
        }
        if (Build.VERSION.SDK_INT < 29) prompting = false;
    }

    @SuppressWarnings("deprecation")
    private void deviceCredential() {
        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        Intent i = km == null ? null : km.createConfirmDeviceCredentialIntent("Unlock " + getString(R.string.app_name),
                "Enter your PIN, pattern or password");
        if (i == null) { showNoLock(); return; }
        try {
            startActivityForResult(i, REQ_KEYGUARD);
        } catch (RuntimeException e) {
            status.setText("Screen lock confirmation is unavailable");
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_KEYGUARD) {
            if (res == RESULT_OK) success(); else status.setText("Use your fingerprint or screen lock.");
        }
    }

    private void success() {
        try {
            App.get().unlock();
            done();
        } catch (RuntimeException e) {
            status.setText("Could not unlock your existing data. Use your screen lock and try again. Your data has been preserved.");
        }
    }

    private void done() {
        finish();
        overridePendingTransition(0, 0);
    }
}
