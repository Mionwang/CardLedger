package com.apkbench.app.core;

import java.util.Arrays;
import java.util.List;

/** One-time, atomic copy of Card Ledger 1.6–1.8. The source is read-only on Android. */
public final class LegacyUpgrade {
    private static final String MARKER = "cardledger-v1-import";
    private LegacyUpgrade() {}

    public static boolean isComplete(Db destination) {
        return !destination.query("SELECT value FROM migration_state WHERE name=?", MARKER).isEmpty();
    }

    public static void migrate(final Db source, final Db destination) {
        if (isComplete(destination)) return;
        int version = source.query("PRAGMA user_version").get(0).getInt("user_version");
        if (version != 4) throw new IllegalStateException("Unsupported legacy schema; original data preserved");
        // Materialize before writing. Never modify, checkpoint, rename or remove the legacy database.
        final List<Db.Row> cards = source.query("SELECT * FROM cards ORDER BY _id");
        final List<Db.Row> rules = source.query("SELECT * FROM recurring ORDER BY _id");
        final List<Db.Row> entries = source.query("SELECT * FROM transactions ORDER BY _id");
        final List<Db.Row> saved = source.query("SELECT * FROM saved_cards ORDER BY _id");
        destination.transaction(new Runnable() {
            @Override public void run() {
                if (isComplete(destination)) return;
                for (String table : new String[]{"cards", "txns", "rules", "vault"}) {
                    if (destination.query("SELECT COUNT(*) AS n FROM " + table).get(0).getLong("n") != 0)
                        throw new IllegalStateException("Destination already contains data; preserving both databases");
                }
                for (Db.Row r : cards) {
                    destination.insert("INSERT INTO cards(id,name,billing_day,created_at) VALUES(?,?,?,?)",
                            r.getLong("_id"), r.getString("name"), r.getInt("bill_day"), r.getLong("created_at"));
                }
                for (Db.Row r : rules) {
                    String until = r.getString("paused_until");
                    boolean paused = r.getInt("active") == 0 || (until != null && !until.isEmpty());
                    String resume = r.getString("pause_resume_date");
                    String base = paused && resume != null && !resume.isEmpty() ? resume : r.getString("next_date");
                    destination.insert("INSERT INTO rules(id,card_id,name,amount,frequency,start_date,anchor_day,"
                                    + "next_index,paused,paused_at,pause_until,note,created_at) VALUES(?,?,?,?,?,?,?,0,?,NULL,?,'',?)",
                            r.getLong("_id"), r.getLong("card_id"), r.getString("title"), r.getLong("amount_paise"),
                            Recurrence.parseFrequency(r.getString("frequency")), CivilDate.parseIso(base), r.getInt("anchor_day"),
                            paused ? 1 : 0, r.getInt("active") != 0 && until != null && !until.isEmpty() ? CivilDate.parseIso(until) : null,
                            r.getLong("created_at"));
                }
                for (Db.Row r : entries) {
                    String type = r.getString("type");
                    if (!"EXPENSE".equals(type) && !"CASHBACK".equals(type))
                        throw new IllegalStateException("Unknown legacy entry type");
                    destination.insert("INSERT INTO txns(id,card_id,type,amount,date,description,note,recurring_id,occurrence,created_at)"
                                    + " VALUES(?,?,?,?,?,?,?,?,NULL,?)",
                            r.getLong("_id"), r.getLong("card_id"), "CASHBACK".equals(type) ? Models.TYPE_CASHBACK : Models.TYPE_EXPENSE,
                            r.getLong("amount_paise"), CivilDate.parseIso(r.getString("date")), r.getString("title"),
                            r.getString("notes") == null ? "" : r.getString("notes"), r.getLongOrNull("recurring_id"), r.getLong("created_at"));
                }
                for (Db.Row r : saved) {
                    byte[] blob = r.getBlob("payload");
                    if (blob == null || blob.length < 29 || blob[0] != 1)
                        throw new IllegalStateException("Invalid legacy encrypted record; preserving original data");
                    // Repackage the encrypted bytes without decrypting or re-encrypting them.
                    destination.insert("INSERT INTO vault(id,iv,data,created_at,updated_at) VALUES(?,?,?,0,0)",
                            r.getLong("_id"), Arrays.copyOfRange(blob, 1, 13), Arrays.copyOfRange(blob, 13, blob.length));
                }
                destination.insert("INSERT INTO migration_state(name,value) VALUES(?,?)", MARKER, "complete");
            }
        });
    }
}
