package com.apkbench.app;

import android.app.Activity;
import android.os.Build;
import android.view.View;
import android.widget.EditText;

import java.lang.reflect.Method;

/**
 * Calls to APIs newer than the compile platform (Android 6.0), made by reflection
 * and guarded by SDK checks so they are simply skipped on older devices.
 */
final class Compat {
    private Compat() {}

    static final int IME_FLAG_NO_PERSONALIZED_LEARNING = 0x1000000; // API 26
    static final int AUTOFILL_NO = 0x2;                            // API 26
    static final int AUTOFILL_NO_EXCLUDE_DESCENDANTS = 0x8;        // API 26

    /** Keeps the app's screens out of autofill services. */
    static void disableAutofill(View v, boolean descendants) {
        if (Build.VERSION.SDK_INT < 26) return;
        try {
            Method m = View.class.getMethod("setImportantForAutofill", int.class);
            m.invoke(v, descendants ? AUTOFILL_NO_EXCLUDE_DESCENDANTS : AUTOFILL_NO);
        } catch (Exception ignored) {
            // not available
        }
    }

    /** No autofill and no keyboard learning for a field. */
    static void sensitive(EditText e) {
        e.setImeOptions(e.getImeOptions() | IME_FLAG_NO_PERSONALIZED_LEARNING);
        disableAutofill(e, false);
    }

    /** Hides app content from the Recents thumbnail on Android 13+ without blocking screenshots. */
    static void hideFromRecents(Activity a) {
        if (Build.VERSION.SDK_INT < 33) return;
        try {
            Method m = Activity.class.getMethod("setRecentsScreenshotEnabled", boolean.class);
            m.invoke(a, false);
        } catch (Exception ignored) {
            // not available
        }
    }
}
