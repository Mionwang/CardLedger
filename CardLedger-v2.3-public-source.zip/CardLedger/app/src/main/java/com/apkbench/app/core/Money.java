package com.apkbench.app.core;

/**
 * Exact money arithmetic. Every amount is a {@code long} count of minor units
 * (hundredths), so no floating-point value is ever used for money.
 * The currency is only a display symbol; values are never converted.
 */
public final class Money {
    private Money() {}

    /** Largest amount accepted from user input: 99,999,999,999.99 */
    public static final long MAX_INPUT = 9_999_999_999_999L;

    /**
     * Parses a user-entered or imported amount such as "1234", "1234.5", "1,234.50"
     * or "0.05". Grouping commas are allowed when a '.' decimal point is used;
     * a lone ',' followed by 1-2 digits is treated as a decimal comma.
     * Negative numbers are rejected. Returns minor units.
     */
    public static long parse(String raw) {
        if (raw == null) throw new IllegalArgumentException("Amount is required");
        String s = raw.trim().replace(" ", "").replace(" ", "");
        if (s.isEmpty()) throw new IllegalArgumentException("Amount is required");
        if (s.startsWith("+")) s = s.substring(1);
        if (s.startsWith("-")) throw new IllegalArgumentException("Amount must be positive");
        int dot = s.indexOf('.');
        if (dot < 0) {
            int lastComma = s.lastIndexOf(',');
            if (lastComma >= 0 && s.indexOf(',') == lastComma) {
                int frac = s.length() - lastComma - 1;
                if (frac == 1 || frac == 2) {
                    s = s.substring(0, lastComma) + "." + s.substring(lastComma + 1);
                }
            }
        }
        dot = s.indexOf('.');
        String intPart = dot < 0 ? s : s.substring(0, dot);
        String fracPart = dot < 0 ? "" : s.substring(dot + 1);
        if (fracPart.indexOf('.') >= 0 || fracPart.indexOf(',') >= 0) {
            throw new IllegalArgumentException("Invalid amount");
        }
        if (intPart.indexOf(',') >= 0) {
            // validate grouping: digits separated by commas, groups after first are 2 or 3 long
            String[] groups = intPart.split(",", -1);
            if (groups[0].isEmpty() || groups[0].length() > 3) throw new IllegalArgumentException("Invalid amount");
            for (int i = 1; i < groups.length; i++) {
                int len = groups[i].length();
                if (len != 3 && len != 2) throw new IllegalArgumentException("Invalid amount");
            }
            intPart = intPart.replace(",", "");
        }
        if (intPart.isEmpty()) intPart = "0";
        if (!allDigits(intPart) || !allDigits(fracPart)) throw new IllegalArgumentException("Invalid amount");
        if (fracPart.length() > 2) throw new IllegalArgumentException("Use at most 2 decimal places");
        if (dot >= 0 && fracPart.isEmpty() && s.length() == 1) throw new IllegalArgumentException("Invalid amount");
        String trimmed = stripLeadingZeros(intPart);
        if (trimmed.length() > 11) throw new IllegalArgumentException("Amount is too large");
        long whole = trimmed.isEmpty() ? 0 : Long.parseLong(trimmed);
        while (fracPart.length() < 2) fracPart = fracPart + "0";
        long minor = whole * 100 + Long.parseLong(fracPart);
        if (minor > MAX_INPUT) throw new IllegalArgumentException("Amount is too large");
        return minor;
    }

    /** Like {@link #parse} but also rejects zero. */
    public static long parsePositive(String raw) {
        long v = parse(raw);
        if (v <= 0) throw new IllegalArgumentException("Amount must be greater than zero");
        return v;
    }

    public static long add(long a, long b) {
        long r = a + b;
        if (((a ^ r) & (b ^ r)) < 0) throw new ArithmeticException("Amount overflow");
        return r;
    }
    public static long sub(long a, long b) {
        long r = a - b;
        if (((a ^ b) & (a ^ r)) < 0) throw new ArithmeticException("Amount overflow");
        return r;
    }
    public static long times(long a, long n) {
        if (a == 0 || n == 0) return 0;
        long r = a * n;
        if (r / n != a || (a == -1 && n == Long.MIN_VALUE) || (n == -1 && a == Long.MIN_VALUE)) {
            throw new ArithmeticException("Amount overflow");
        }
        return r;
    }

    /** Plain machine format: "-1234.05". Used for JSON export. */
    public static String toPlain(long minor) {
        boolean neg = minor < 0;
        long abs = Math.abs(minor);
        String frac = String.valueOf(abs % 100);
        if (frac.length() < 2) frac = "0" + frac;
        return (neg ? "-" : "") + (abs / 100) + "." + frac;
    }

    /** Editable input format without grouping: "1234.05" (or "" for 0 if blankZero). */
    public static String toInput(long minor) { return toPlain(minor); }

    /**
     * Display format with symbol and grouping. Indian grouping (12,34,567.00)
     * is used when {@code indian} is true.
     */
    public static String format(long minor, String symbol, boolean indian) {
        boolean neg = minor < 0;
        long abs = minor == Long.MIN_VALUE ? Long.MAX_VALUE : Math.abs(minor);
        String whole = String.valueOf(abs / 100);
        String frac = String.valueOf(abs % 100);
        if (frac.length() < 2) frac = "0" + frac;
        return (neg ? "-" : "") + symbol + group(whole, indian) + "." + frac;
    }

    static String group(String digits, boolean indian) {
        int n = digits.length();
        if (n <= 3) return digits;
        StringBuilder sb = new StringBuilder();
        String last3 = digits.substring(n - 3);
        String rest = digits.substring(0, n - 3);
        int step = indian ? 2 : 3;
        int first = rest.length() % step;
        if (first == 0) first = step;
        sb.append(rest, 0, first);
        for (int i = first; i < rest.length(); i += step) {
            sb.append(',').append(rest, i, i + step);
        }
        sb.append(',').append(last3);
        return sb.toString();
    }

    private static boolean allDigits(String s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c < '0' || c > '9') return false;
        }
        return true;
    }

    private static String stripLeadingZeros(String s) {
        int i = 0;
        while (i < s.length() - 1 && s.charAt(i) == '0') i++;
        String r = s.substring(i);
        return r.equals("0") ? "" : r;
    }
}
