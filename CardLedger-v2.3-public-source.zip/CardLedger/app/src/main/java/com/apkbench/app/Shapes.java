package com.apkbench.app;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

/** Line icons drawn in code (24-unit grid, round strokes), so they stay sharp at any density. */
final class Shapes {
    private Shapes() {}

    static final int ICON_BACK = 0, ICON_MORE = 1, ICON_LOCK = 2, ICON_PLUS = 3, ICON_REPEAT = 4, ICON_CHEVRON = 5;

    /** 24-unit line icons drawn with round strokes. */
    static final class Icon extends Drawable {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int kind, sizePx;

        Icon(int kind, int sizePx, int color) {
            this.kind = kind;
            this.sizePx = sizePx;
            p.setColor(color);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
        }

        @Override public int getIntrinsicWidth() { return sizePx; }
        @Override public int getIntrinsicHeight() { return sizePx; }

        @Override public void draw(Canvas c) {
            Rect b = getBounds();
            float u = Math.min(b.width(), b.height()) / 24f;
            c.save();
            c.translate(b.centerX() - 12 * u, b.centerY() - 12 * u);
            p.setStrokeWidth(1.7f * u);
            Path path = new Path();
            switch (kind) {
                case ICON_BACK:
                    path.moveTo(14.5f * u, 6 * u); path.lineTo(8.5f * u, 12 * u); path.lineTo(14.5f * u, 18 * u);
                    c.drawPath(path, p);
                    break;
                case ICON_CHEVRON:
                    path.moveTo(9.5f * u, 6 * u); path.lineTo(15.5f * u, 12 * u); path.lineTo(9.5f * u, 18 * u);
                    c.drawPath(path, p);
                    break;
                case ICON_MORE: {
                    p.setStyle(Paint.Style.FILL);
                    for (int i = -1; i <= 1; i++) c.drawCircle(12 * u + i * 6 * u, 12 * u, 1.6f * u, p);
                    p.setStyle(Paint.Style.STROKE);
                    break;
                }
                case ICON_LOCK: {
                    RectF body = new RectF(6 * u, 11 * u, 18 * u, 19.5f * u);
                    c.drawRoundRect(body, 2.6f * u, 2.6f * u, p);
                    path.moveTo(8.8f * u, 11 * u);
                    path.lineTo(8.8f * u, 8.5f * u);
                    path.arcTo(new RectF(8.8f * u, 5 * u, 15.2f * u, 11.4f * u), 180, 180);
                    path.lineTo(15.2f * u, 11 * u);
                    c.drawPath(path, p);
                    break;
                }
                case ICON_PLUS:
                    c.drawLine(12 * u, 6.5f * u, 12 * u, 17.5f * u, p);
                    c.drawLine(6.5f * u, 12 * u, 17.5f * u, 12 * u, p);
                    break;
                case ICON_REPEAT: {
                    RectF arc = new RectF(5.5f * u, 5.5f * u, 18.5f * u, 18.5f * u);
                    c.drawArc(arc, 200, 290, false, p);
                    path.moveTo(5.2f * u, 4.8f * u); path.lineTo(6.3f * u, 9.4f * u); path.lineTo(10.6f * u, 8.2f * u);
                    c.drawPath(path, p);
                    break;
                }
                default:
                    break;
            }
            c.restore();
        }

        @Override public void setAlpha(int a) { p.setAlpha(a); }
        @Override public void setColorFilter(ColorFilter cf) { p.setColorFilter(cf); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }
}
