package com.apkbench.app;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.apkbench.app.core.*;

/** The saved-card visual language, with ledger values and no payment credentials. */
final class LedgerTile {
    private LedgerTile() {}
    static FrameLayout build(Context c, Models.CardSummary s, CardInfo saved, boolean review, View.OnClickListener menu) {
        FrameLayout face = new FrameLayout(c);
        face.setBackground(Ui.rounded(c,Ui.SURFACE_2,28,0));
        int p = Ui.dp(c,22);
        face.setPadding(p,p,p,p);
        face.setMinimumHeight(Ui.dp(c,210));
        LinearLayout content = Ui.col(c);
        LinearLayout top = Ui.row(c);
        top.setGravity(Gravity.TOP);
        LinearLayout titles = Ui.col(c);
        titles.addView(Ui.text(c,s.card.name,20,Ui.TEXT,Ui.SANS));
        if (saved != null) {
            String identity = saved.bank + (saved.product.isEmpty() ? "" : " · " + saved.product);
            if (!CardLinks.normalized(identity).equals(CardLinks.normalized(s.card.name)))
                titles.addView(Ui.text(c,identity,13,Ui.MUTED,Ui.SANS),Ui.margins(c,Ui.matchWrap(),0,4,0,0));
        }
        top.addView(titles,Ui.weight(1));
        if (saved != null && !saved.network.isEmpty()) {
            TextView network = Ui.text(c,saved.network,12,Ui.ACCENT,Ui.MEDIUM);
            network.setMaxWidth(Ui.dp(c,85));
            top.addView(network,Ui.margins(c,Ui.lp(-2,-2),8,10,2,0));
        }
        top.addView(Ui.icon(c,Shapes.ICON_MORE,review ? "Card options. Link needs review" : "Card options",menu));
        content.addView(top);
        content.addView(Ui.space(c,22));
        TextView balance = Ui.figure(c,App.get().money(s.outstanding),36,s.outstanding < 0 ? Ui.CREDIT : Ui.TEXT);
        balance.setSingleLine(true);
        if (android.os.Build.VERSION.SDK_INT >= 26) balance.setAutoSizeTextTypeUniformWithConfiguration(20,36,1,android.util.TypedValue.COMPLEX_UNIT_SP);
        content.addView(balance,Ui.matchWrap());
        content.addView(Ui.text(c,s.outstanding < 0 ? "IN CREDIT" : "OUTSTANDING",11,Ui.MUTED,Ui.MEDIUM),
                Ui.margins(c,Ui.matchWrap(),0,3,0,18));
        LinearLayout bottom = Ui.row(c);
        bottom.setGravity(Gravity.BOTTOM);
        LinearLayout dates = Ui.col(c);
        String timing = "Bill date not set";
        if (s.card.billingDay > 0) {
            int days = BillingCycle.daysUntilStatement(s.card.billingDay,CivilDate.today());
            timing = days == 0 ? "Statement today" : days == 1 ? "Statement tomorrow" : "Statement in "+days+" days";
        }
        dates.addView(Ui.text(c,timing,13,Ui.MUTED,Ui.SANS));
        if (s.cashback > 0) dates.addView(Ui.text(c,"−"+App.get().money(s.cashback)+" cashback",13,Ui.CREDIT,Ui.SANS),
                Ui.margins(c,Ui.matchWrap(),0,5,0,0));
        if (review) dates.addView(Ui.text(c,"Link needs review · ⋮",12,Ui.ACCENT,Ui.SANS),
                Ui.margins(c,Ui.matchWrap(),0,5,0,0));
        bottom.addView(dates,Ui.weight(1));
        if (s.ruleCount > 0) bottom.addView(Ui.chip(c,s.activeRuleCount > 0 ? s.activeRuleCount+" recurring" : s.pausedRuleCount > 0 ? "Paused" : "Ended",
                s.activeRuleCount > 0 ? Ui.ACCENT : s.pausedRuleCount > 0 ? Ui.WARN : Ui.MUTED),Ui.margins(c,Ui.lp(-2,-2),8,0,0,0));
        content.addView(bottom);
        face.addView(content,Ui.matchWrap());
        return face;
    }
}
