package com.apkbench.app;

import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.apkbench.app.core.CardInfo;

/**
 * Saved card details. Number and CVV are masked; Reveal shows them for 30 seconds,
 * then they hide again automatically (also when the screen is left).
 */
public final class SavedCardActivity extends BaseActivity {
    private static final int REVEAL_SECONDS = 30;

    private long id;
    private CardInfo card;
    private boolean numberShown, cvvShown;
    private int numberLeft, cvvLeft;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private FrameLayout tileHolder;
    private TextView numberValue, numberReveal, cvvValue, cvvReveal;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (numberShown && --numberLeft <= 0) numberShown = false;
            if (cvvShown && --cvvLeft <= 0) cvvShown = false;
            render();
            if (numberShown || cvvShown) handler.postDelayed(this, 1000);
        }
    };

    @Override protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        id = getIntent().getLongExtra("id", -1);
    }

    @Override protected void onHide() { hideAll(); }

    @Override protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(tick);
        card = null;
    }

    private void hideAll() {
        numberShown = cvvShown = false;
        handler.removeCallbacks(tick);
        if (card != null) render();
    }

    @Override protected View build() {
        hideAll();
        try {
            card = app.vault().get(id);
        } catch (RuntimeException e) {
            card = null;
        }
        if (card == null) { finish(); return new View(this); }
        LinearLayout[] pg = page(card.title(), (card.kind.isEmpty() ? "Saved card" : card.kind + " card") + ", " + card.network, true,
                Ui.icon(this, Shapes.ICON_MORE, "Saved card options", v -> {
                    hideAll();
                    Dialogs.actions(this, card.title(), new String[]{"Open ledger", "Manage link"}, i -> {
                        if (i == 0) CardLinkDialogs.openLedger(this,id); else CardLinkDialogs.manageSaved(this,id);
                    });
                }),
                Ui.pill(this, "Edit", false, new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        startActivity(intent(SavedCardEditActivity.class).putExtra("id", id));
                    }
                }));
        LinearLayout body = pg[1];
        tileHolder = new FrameLayout(this);
        body.addView(tileHolder, Ui.margins(this, Ui.matchWrap(), 0, 4, 0, 16));

        LinearLayout details = Ui.col(this);
        details.setPadding(0, 0, 0, 0);

        // number row with reveal + copy
        LinearLayout numRow = Ui.row(this);
        pad(numRow);
        LinearLayout numCol = Ui.col(this);
        numCol.addView(Ui.label(this, "Card number"));
        numberValue = Ui.text(this, "", 16, Ui.TEXT, Ui.MONO);
        numberValue.setSingleLine(true);
        numCol.addView(numberValue, Ui.margins(this, Ui.matchWrap(), 0, 4, 0, 0));
        numRow.addView(numCol, Ui.weight(1));
        numberReveal = Ui.pill(this, "Reveal", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                numberShown = !numberShown;
                numberLeft = REVEAL_SECONDS;
                restartTick();
            }
        });
        numRow.addView(numberReveal);
        numRow.addView(Ui.hspace(this, 6));
        numRow.addView(Ui.pill(this, "Copy", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                ClipboardGuard.copy(SavedCardActivity.this, card.number);
                toast("Copied. The clipboard clears in 30 seconds.");
            }
        }));
        details.addView(numRow);
        details.addView(Ui.divider(this));

        LinearLayout cvvRow = Ui.row(this);
        pad(cvvRow);
        LinearLayout cvvCol = Ui.col(this);
        cvvCol.addView(Ui.label(this, "CVV"));
        cvvValue = Ui.text(this, "", 16, Ui.TEXT, Ui.MONO);
        cvvCol.addView(cvvValue, Ui.margins(this, Ui.matchWrap(), 0, 4, 0, 0));
        cvvRow.addView(cvvCol, Ui.weight(1));
        cvvReveal = Ui.pill(this, "Reveal", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                cvvShown = !cvvShown;
                cvvLeft = REVEAL_SECONDS;
                restartTick();
            }
        });
        if (!card.cvv.isEmpty()) cvvRow.addView(cvvReveal);
        details.addView(cvvRow);

        String[][] rows = {
                {"Issuing bank", card.bank},
                {"Product", card.product.isEmpty() ? "—" : card.product},
                {"Cardholder", card.holder.isEmpty() ? "—" : card.holder},
                {"Expiry", card.expiry()},
                {"Network", card.network},
                {"Type", card.kind},
        };
        for (String[] r : rows) {
            details.addView(Ui.divider(this));
            LinearLayout row = Ui.row(this);
            pad(row);
            row.addView(Ui.muted(this, r[0]), Ui.weight(1));
            row.addView(Ui.single(Ui.text(this, r[1], 15, Ui.TEXT, Ui.SANS)));
            details.addView(row);
        }
        body.addView(details);
        body.addView(Ui.text(this, "Revealed values hide automatically after 30 seconds or when you leave this screen.",
                12, Ui.FAINT, Ui.SANS), Ui.margins(this, Ui.matchWrap(), 2, 10, 0, 18));
        body.addView(Ui.button(this, "Delete saved card", Ui.DANGER_STYLE, new View.OnClickListener() {
            @Override public void onClick(View v) {
                Dialogs.confirm(SavedCardActivity.this, "Delete saved card?", card.title() + " •• " + card.last4()
                        + " will be removed from this device.", "Delete", true, new Dialogs.Done() {
                    @Override public void run() {
                        app.vault().delete(id);
                        finish();
                    }
                });
            }
        }));
        render();
        return pg[0];
    }

    private void pad(View v) {
        int p = Ui.dp(this, 16);
        v.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 12));
        v.setMinimumHeight(Ui.dp(this, 52));
    }

    private void restartTick() {
        handler.removeCallbacks(tick);
        render();
        if (numberShown || cvvShown) handler.postDelayed(tick, 1000);
    }

    private void render() {
        if (numberValue == null || card == null) return;
        String number = numberShown ? CardInfo.group(card.number, card.network) : CardInfo.mask(card.number);
        numberValue.setText(number);
        numberReveal.setText(numberShown ? "Hide " + numberLeft + "s" : "Reveal");
        cvvValue.setText(cvvShown ? card.cvv : CardInfo.maskCvv(card.cvv));
        cvvReveal.setText(cvvShown ? "Hide " + cvvLeft + "s" : "Reveal");
        tileHolder.removeAllViews();
        tileHolder.addView(CardTile.build(this, card, number));
    }
}
