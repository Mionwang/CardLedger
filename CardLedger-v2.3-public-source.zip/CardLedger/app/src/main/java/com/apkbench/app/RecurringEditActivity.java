package com.apkbench.app;

import android.text.InputFilter;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.apkbench.app.core.CivilDate;
import com.apkbench.app.core.LedgerRepo;
import com.apkbench.app.core.Models;
import com.apkbench.app.core.Money;
import com.apkbench.app.core.Recurrence;

/** Create or edit a recurring payment; pause / resume / delete when editing. */
public final class RecurringEditActivity extends BaseActivity {
    private long cardId, ruleId;
    private int frequency = Recurrence.MONTHLY;
    private long startDate;
    private Long endDate;
    private EditText name, amount, note;
    private TextView dateField, endField, preview;
    private boolean dateTouched, freqTouched, endTouched;

    @Override protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        cardId = getIntent().getLongExtra("card", -1);
        ruleId = getIntent().getLongExtra("rule", -1);
        startDate = CivilDate.today();
    }

    /** Rebuild only when the rule's pause state may have changed; inputs are re-filled from the rule. */
    @Override protected boolean rebuildOnResume() { return false; }

    @Override protected View build() {
        Models.Card card = app.ledger().getCard(cardId);
        final Models.Rule rule = ruleId > 0 ? app.ledger().getRule(ruleId) : null;
        if (card == null || (ruleId > 0 && rule == null)) { finish(); return new View(this); }
        String keepName = name != null ? name.getText().toString() : null;
        String keepAmount = amount != null ? amount.getText().toString() : null;
        String keepNote = note != null ? note.getText().toString() : null;
        if (rule != null) {
            if (!endTouched) endDate = rule.endDate;
            // Show the original anchor, never the automatically inferred next date.
            if (!freqTouched) frequency = rule.frequency;
            if (!dateTouched) startDate = rule.startDate;
        }
        LinearLayout[] pg = page(rule == null ? "New recurring payment" : "Edit recurring payment", card.name, true);
        LinearLayout body = pg[1];

        if (rule != null) {
            LinearLayout st = Ui.panel(this);
            LinearLayout r = Ui.row(this);
            r.addView(Ui.text(this, RecurringListActivity.status(rule), 14, rule.paused ? Ui.WARN : Ui.TEXT, Ui.MEDIUM), Ui.weight(1));
            if (!rule.hasEnded(CivilDate.today())) r.addView(Ui.pill(this, rule.paused ? "Resume" : "Pause", false, new View.OnClickListener() {
                @Override public void onClick(View v) { RecurringListActivity.togglePause(RecurringEditActivity.this, rule); }
            }));
            st.addView(r);
            body.addView(st, Ui.margins(this, Ui.matchWrap(), 0, 4, 0, 16));
        }

        name = Ui.input(this, "e.g. Streaming subscription", Ui.INPUT_TEXT);
        name.setFilters(new InputFilter[]{new InputFilter.LengthFilter(LedgerRepo.MAX_NAME)});
        body.addView(Ui.field(this, "Name", name));

        amount = Ui.input(this, "0.00", Ui.INPUT_MONEY);
        amount.setFilters(new InputFilter[]{new InputFilter.LengthFilter(16)});
        body.addView(Ui.field(this, "Amount (" + app.symbol().trim() + ")", amount));

        body.addView(Ui.label(this, "Repeats"), Ui.margins(this, Ui.matchWrap(), 2, 0, 0, 6));
        body.addView(Ui.segmented(this, new String[]{"Weekly", "Monthly", "Yearly"}, frequency, new Ui.SegmentListener() {
            @Override public void onSelected(int index) {
                frequency = index;
                freqTouched = true;
                updatePreview();
            }
        }), Ui.margins(this, Ui.matchWrap(), 0, 0, 0, 14));

        dateField = Ui.selector(this, CivilDate.display(startDate), new View.OnClickListener() {
            @Override public void onClick(View v) {
                Dialogs.pickDate(RecurringEditActivity.this, startDate, new Dialogs.DatePicked() {
                    @Override public void picked(long d) {
                        startDate = d;
                        dateTouched = true;
                        dateField.setText(CivilDate.display(d));
                        updatePreview();
                    }
                });
            }
        });
        body.addView(Ui.field(this, "Start date", dateField));
        endField = Ui.selector(this,endDate == null ? "No end date" : CivilDate.display(endDate),v -> chooseEndDate());
        body.addView(Ui.field(this,"End date (optional)",endField));
        preview = Ui.muted(this, "");
        body.addView(preview, Ui.margins(this, Ui.matchWrap(), 2, -6, 0, 14));

        note = Ui.input(this, "Optional", Ui.INPUT_MULTI);
        note.setFilters(new InputFilter[]{new InputFilter.LengthFilter(LedgerRepo.MAX_NOTE)});
        body.addView(Ui.field(this, "Notes", note));

        if (keepName != null) {
            name.setText(keepName);
            amount.setText(keepAmount);
            note.setText(keepNote);
        } else if (rule != null) {
            name.setText(rule.name);
            amount.setText(Money.toInput(rule.amount));
            note.setText(rule.note);
        }
        updatePreview();

        body.addView(Ui.button(this, rule == null ? "Create" : "Save", Ui.PRIMARY, new View.OnClickListener() {
            @Override public void onClick(View v) { save(); }
        }), Ui.margins(this, Ui.matchWrap(), 0, 6, 0, 10));
        if (rule != null) {
            body.addView(Ui.button(this, "Delete", Ui.DANGER_STYLE, new View.OnClickListener() {
                @Override public void onClick(View v) { RecurringListActivity.confirmDelete(RecurringEditActivity.this, rule, true); }
            }));
        } else {
            name.requestFocus();
        }
        return pg[0];
    }

    private void updatePreview() {
        if (preview == null) return;
        long today=CivilDate.today();
        try {
            Models.Rule plan=app.ledger().previewRuleFromStart(ruleId,frequency,startDate,endDate,today);
            StringBuilder b=new StringBuilder(plan.describe());
            Long next=plan.effectiveNextDate();
            if (next == null) b.append(plan.paused ? ". No payment scheduled while paused" : ". No remaining payments");
            else {
                b.append(".\nNext payment: ").append(CivilDate.display(next));
                long index=Recurrence.firstIndexOnOrAfter(frequency,startDate,plan.anchorDay,plan.nextIndex,next);
                for (int i=1; i<=2; i++) {
                    long date=Recurrence.occurrence(frequency,startDate,plan.anchorDay,index+i);
                    if (endDate != null && date>endDate) break;
                    b.append(i==1 ? ". Following: " : ", ").append(CivilDate.displayShort(date));
                }
                if (next==today) b.append(". Today's payment will be added when you save");
            }
            if (endDate != null) b.append(". Ends ").append(CivilDate.display(endDate)).append(" (inclusive)");
            if (startDate<today) b.append(".\nEarlier instalments are not added when setting the start date.");
            preview.setText(b.toString());
        } catch (IllegalArgumentException e) { preview.setText(e.getMessage()); }
    }

    private void chooseEndDate() {
        Dialogs.actions(this,"End date",new String[]{"Choose date","No end date"},i -> {
            if (i == 1) { endDate=null; endTouched=true; endField.setText("No end date"); endField.setError(null); updatePreview(); }
            else Dialogs.pickDate(this,endDate == null ? Math.max(startDate,CivilDate.today()) : endDate,d -> {
                endDate=d; endTouched=true; endField.setText(CivilDate.display(d)); endField.setError(null); updatePreview();
            });
        });
    }

    private void save() {
        long minor;
        try {
            minor = Money.parsePositive(amount.getText().toString());
        } catch (IllegalArgumentException e) {
            Ui.error(amount, e.getMessage());
            return;
        }
        try {
            app.ledger().saveRuleFromStart(ruleId,cardId,name.getText().toString(),minor,frequency,
                    startDate,note.getText().toString(),endDate,CivilDate.today());
            int posted = app.processRecurring();
            if (posted > 0) toast(posted + " due payment(s) added");
            finish();
        } catch (IllegalArgumentException e) {
            String m = e.getMessage();
            if (m != null && (m.startsWith("Name"))) Ui.error(name, m);
            else if (m != null && m.startsWith("End date")) endField.setError(m);
            else if (m != null && m.startsWith("Notes")) Ui.error(note, m);
            else Ui.error(amount, m);
        }
    }
}
