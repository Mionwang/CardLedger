package com.apkbench.app;

import android.view.View;
import android.widget.LinearLayout;

import com.apkbench.app.core.CivilDate;
import com.apkbench.app.core.Models;
import com.apkbench.app.core.Recurrence;

import java.util.List;

/** Recurring payments of one card, with frequency, next date and pause status. */
public final class RecurringListActivity extends BaseActivity {
    private long cardId;

    @Override protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        cardId = getIntent().getLongExtra("card", -1);
    }

    @Override protected View build() {
        Models.Card card = app.ledger().getCard(cardId);
        if (card == null) { finish(); return new View(this); }
        LinearLayout[] pg = page("Recurring", card.name, true, Ui.pill(this, "Add", true, new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(intent(RecurringEditActivity.class).putExtra("card", cardId));
            }
        }));
        LinearLayout body = pg[1];
        body.addView(Ui.muted(this, "Next payments are calculated from the start date. Setting a past start date does not add earlier instalments. "
                + "After setup, missed due payments are added when you open the app. Marking the card paid keeps these rules."), Ui.margins(this, Ui.matchWrap(), 2, 0, 0, 14));

        List<Models.Rule> rules = app.ledger().listRules(cardId);
        if (rules.isEmpty()) {
            body.addView(Ui.button(this, "Add a recurring payment", Ui.SECONDARY, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    startActivity(intent(RecurringEditActivity.class).putExtra("card", cardId));
                }
            }), Ui.margins(this, Ui.matchWrap(), 0, 16, 0, 0));
        }
        for (final Models.Rule r : rules) body.addView(tile(r), Ui.margins(this, Ui.matchWrap(), 0, 0, 0, 10));
        if (!rules.isEmpty()) {
            body.addView(Ui.text(this, "Tap a payment to edit it. Press and hold to pause, resume or delete.", 12, Ui.FAINT, Ui.SANS),
                    Ui.margins(this, Ui.matchWrap(), 2, 4, 0, 0));
        }
        return pg[0];
    }

    static String status(Models.Rule r) {
        if (r.hasEnded(CivilDate.today())) return "Ended · " + CivilDate.display(r.endDate);
        String end = r.endDate == null ? "" : " · Ends " + CivilDate.display(r.endDate);
        if (!r.paused) return "Next " + CivilDate.display(r.nextDate()) + end;
        if (r.pauseUntil == null) return "Paused indefinitely" + end;
        Long next = r.effectiveNextDate();
        return "Paused until " + CivilDate.display(r.pauseUntil) + (next != null ? ", then " + CivilDate.display(next) : ", no payment before end date") + end;
    }

    private View tile(final Models.Rule r) {
        LinearLayout t = Ui.col(this);
        Ui.rowClickable(t);
        int p = 0;
        t.setPadding(p, Ui.dp(this, 14), p, Ui.dp(this, 14));
        LinearLayout r1 = Ui.row(this);
        r1.addView(Ui.single(Ui.text(this, r.name, 22, Ui.TEXT, Ui.SANS)), Ui.weight(1));
        r1.addView(Ui.amount(this, app.money(r.amount), 17, Ui.TEXT));
        t.addView(r1);
        LinearLayout r2 = Ui.row(this);
        r2.addView(Ui.single(Ui.muted(this, r.describe())), Ui.weight(1));
        boolean ended = r.hasEnded(CivilDate.today());
        r2.addView(Ui.chip(this, ended ? "Ended" : r.paused ? "Paused" : Recurrence.frequencyName(r.frequency),
                ended ? Ui.MUTED : r.paused ? Ui.WARN : Ui.ACCENT));
        t.addView(r2, Ui.margins(this, Ui.matchWrap(), 0, 4, 0, 0));
        t.addView(Ui.text(this, status(r), 13, r.paused ? Ui.WARN : Ui.MUTED, Ui.SANS), Ui.margins(this, Ui.matchWrap(), 0, 4, 0, 0));
        if (r.endDate != null && !r.paused && !ended) {
            long count=Recurrence.remainingOccurrences(r,CivilDate.today(),r.endDate);
            t.addView(Ui.text(this,count + " remaining · " + app.money(com.apkbench.app.core.Money.times(r.amount,count)),13,Ui.MUTED,Ui.SANS),
                    Ui.margins(this,Ui.matchWrap(),0,4,0,0));
        }
        if (!r.note.isEmpty()) t.addView(Ui.single(Ui.text(this, r.note, 12, Ui.FAINT, Ui.SANS)));
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { edit(r); }
        });
        t.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                if (r.hasEnded(CivilDate.today())) {
                    Dialogs.actions(RecurringListActivity.this,r.name,new String[]{"Edit end date","Delete"},i -> {
                        if (i == 0) edit(r); else confirmDelete(this_(),r,false);
                    });
                    return true;
                }
                String[] items = {"Edit", r.paused ? "Resume now" : "Pause…", "Delete"};
                Dialogs.actions(RecurringListActivity.this, r.name, items, new Dialogs.Picked() {
                    @Override public void picked(int i) {
                        if (i == 0) edit(r);
                        else if (i == 1) togglePause(this_(), r);
                        else confirmDelete(this_(), r, false);
                    }
                });
                return true;
            }
        });
        return t;
    }

    private RecurringListActivity this_() { return this; }

    private void edit(Models.Rule r) {
        startActivity(intent(RecurringEditActivity.class).putExtra("card", cardId).putExtra("rule", r.id));
    }

    static void togglePause(final BaseActivity a, final Models.Rule r) {
        final App app = App.get();
        if (r.paused) {
            try { app.ledger().resumeRule(r.id, CivilDate.today()); a.toast(r.name + " resumed"); }
            catch (IllegalArgumentException e) { a.toast(e.getMessage()); }
            a.rebuild();
            return;
        }
        Dialogs.pause(a, new Dialogs.PauseChosen() {
            @Override public void chosen(int months) {
                try {
                    app.ledger().pauseRule(r.id, months, CivilDate.today());
                    a.toast(months == 0 ? r.name + " paused" : r.name + " paused for " + months + " month(s)");
                } catch (IllegalArgumentException e) {
                    a.toast(e.getMessage());
                }
                a.rebuild();
            }
        });
    }

    static void confirmDelete(final BaseActivity a, final Models.Rule r, final boolean finishAfter) {
        Dialogs.confirm(a, "Delete " + r.name + "?",
                "Stops future payments. Transactions already added stay on the card.", "Delete", true, new Dialogs.Done() {
                    @Override public void run() {
                        App.get().ledger().deleteRule(r.id);
                        if (finishAfter) a.finish(); else a.rebuild();
                    }
                });
    }
}
