package com.apkbench.app;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.IsoDep;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.apkbench.app.core.CardInfo;
import com.apkbench.app.core.Emv;

import java.io.IOException;

/**
 * Add or edit a saved card. Optional NFC scan reads the number and expiry (and the
 * name when the card provides it) from contactless EMV cards; everything can be
 * typed manually instead.
 */
public final class SavedCardEditActivity extends BaseActivity {
    private long id;
    private CardInfo existing;
    private EditText bank, product, holder, number, expiry, cvv;
    private TextView networkField;
    private String network = "";
    private boolean networkManual;
    private String kind = CardInfo.KIND_CREDIT;
    private AlertDialog scanDialog;
    private boolean loaded;

    @Override protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        id = getIntent().getLongExtra("id", -1);
    }

    @Override protected boolean rebuildOnResume() { return false; }

    @Override protected void onHide() { stopScan(); }

    @Override protected View build() {
        if (id > 0 && !loaded) {
            try {
                existing = app.vault().get(id);
            } catch (RuntimeException e) {
                existing = null;
            }
            if (existing == null) { finish(); return new View(this); }
            network = existing.network;
            networkManual = true;
            kind = existing.kind;
        }
        LinearLayout[] pg = page(existing == null ? "Add saved card" : "Edit saved card", "Stored encrypted on this device", true);
        LinearLayout body = pg[1];

        final NfcAdapter nfc = NfcAdapter.getDefaultAdapter(this);
        if (nfc != null) {
            body.addView(Ui.button(this, "Scan card with NFC", Ui.SECONDARY, new View.OnClickListener() {
                @Override public void onClick(View v) { startScan(nfc); }
            }), Ui.margins(this, Ui.matchWrap(), 0, 4, 0, 6));
            body.addView(Ui.text(this, "Fills number and expiry from a contactless card. Cardholder name only if the card shares it.",
                    12, Ui.FAINT, Ui.SANS), Ui.margins(this, Ui.matchWrap(), 2, 0, 0, 16));
        }

        bank = Ui.input(this, "e.g. Your bank", Ui.INPUT_TEXT);
        limit(bank, 60);
        body.addView(Ui.field(this, "Issuing bank", bank));
        product = Ui.input(this, "e.g. Rewards card", Ui.INPUT_TEXT);
        limit(product, 60);
        body.addView(Ui.field(this, "Product name (optional)", product));
        holder = Ui.input(this, "Name on card", Ui.INPUT_CAPS);
        limit(holder, 60);
        body.addView(Ui.field(this, "Cardholder name", holder));

        number = Ui.input(this, "Card number", Ui.INPUT_DIGITS);
        number.setTypeface(Ui.MONO);
        limit(number, 19);
        number.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) {
                if (!networkManual) {
                    String d = CardInfo.digitsOnly(e.toString());
                    network = d == null || d.length() < 2 ? "" : CardInfo.detectNetwork(d);
                    renderNetwork();
                }
            }
        });
        body.addView(Ui.field(this, "Card number", number));

        LinearLayout pair = Ui.row(this);
        expiry = Ui.input(this, "MM/YY", Ui.INPUT_DIGITS);
        expiry.setKeyListener(android.text.method.DigitsKeyListener.getInstance("0123456789/"));
        limit(expiry, 5);
        expiry.addTextChangedListener(new ExpiryFormatter());
        LinearLayout e1 = Ui.field(this, "Expiry", expiry);
        pair.addView(e1, Ui.weight(1));
        pair.addView(Ui.hspace(this, 12));
        cvv = Ui.input(this, "Optional", Ui.INPUT_PIN);
        cvv.setTypeface(Ui.MONO);
        limit(cvv, 4);
        LinearLayout e2 = Ui.field(this, "CVV", cvv);
        pair.addView(e2, Ui.weight(1));
        body.addView(pair, Ui.matchWrap());

        networkField = Ui.selector(this, "", new View.OnClickListener() {
            @Override public void onClick(View v) { chooseNetwork(); }
        });
        body.addView(Ui.field(this, "Payment network", networkField));

        body.addView(Ui.label(this, "Type"), Ui.margins(this, Ui.matchWrap(), 2, 0, 0, 6));
        body.addView(Ui.segmented(this, new String[]{CardInfo.KIND_CREDIT, CardInfo.KIND_DEBIT},
                CardInfo.KIND_DEBIT.equals(kind) ? 1 : 0, new Ui.SegmentListener() {
                    @Override public void onSelected(int index) { kind = index == 1 ? CardInfo.KIND_DEBIT : CardInfo.KIND_CREDIT; }
                }), Ui.margins(this, Ui.matchWrap(), 0, 0, 0, 18));

        if (existing != null && !loaded) {
            bank.setText(existing.bank);
            product.setText(existing.product);
            holder.setText(existing.holder);
            number.setText(existing.number);
            expiry.setText(existing.expiry());
            cvv.setText(existing.cvv);
        }
        loaded = true;
        renderNetwork();

        body.addView(Ui.button(this, existing == null ? "Save card" : "Save changes", Ui.PRIMARY, new View.OnClickListener() {
            @Override public void onClick(View v) { save(); }
        }));
        body.addView(Ui.text(this, "Card numbers are checked (length and checksum) and duplicates are rejected.",
                12, Ui.FAINT, Ui.SANS), Ui.margins(this, Ui.matchWrap(), 2, 10, 0, 0));
        return pg[0];
    }

    private static void limit(EditText e, int n) { e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(n)}); }

    private void renderNetwork() {
        if (networkField == null) return;
        networkField.setText(network.isEmpty() ? "Detected from number" : network + (networkManual ? "" : " (detected)"));
        networkField.setTextColor(network.isEmpty() ? Ui.FAINT : Ui.TEXT);
    }

    private void chooseNetwork() {
        final String[] items = CardInfo.NETWORKS;
        int checked = -1;
        for (int i = 0; i < items.length; i++) if (items[i].equals(network)) checked = i;
        Dialogs.builder(this).setTitle("Payment network")
                .setSingleChoiceItems(items, checked, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        network = items[which];
                        networkManual = true;
                        renderNetwork();
                        d.dismiss();
                    }
                })
                .setNeutralButton("Auto-detect", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        networkManual = false;
                        String digits = CardInfo.digitsOnly(number.getText().toString());
                        network = digits == null || digits.length() < 2 ? "" : CardInfo.detectNetwork(digits);
                        renderNetwork();
                    }
                })
                .show();
    }

    private void save() {
        CardInfo c = new CardInfo();
        c.id = id;
        c.bank = bank.getText().toString();
        c.product = product.getText().toString();
        c.holder = holder.getText().toString();
        c.number = number.getText().toString();
        c.network = network;
        c.kind = kind;
        c.cvv = cvv.getText().toString();
        try {
            int[] e = CardInfo.parseExpiry(expiry.getText().toString());
            c.expMonth = e[0];
            c.expYear = e[1];
            CardInfo.validateExpiryNow(c.expMonth, c.expYear);
        } catch (IllegalArgumentException ex) {
            Ui.error(expiry, ex.getMessage());
            return;
        }
        try {
            CardInfo.cleanField(c.bank, 60, "Issuing bank", true);
        } catch (IllegalArgumentException ex) {
            Ui.error(bank, ex.getMessage());
            return;
        }
        try {
            c.number = CardInfo.validateNumber(c.number);
        } catch (IllegalArgumentException ex) {
            Ui.error(number, ex.getMessage());
            return;
        }
        if (c.network.isEmpty()) c.network = CardInfo.detectNetwork(c.number);
        try {
            CardInfo.validateCvv(c.cvv, c.network);
        } catch (IllegalArgumentException ex) {
            Ui.error(cvv, ex.getMessage());
            return;
        }
        try {
            if (id > 0) app.vault().update(c); else app.vault().add(c);
            finish();
        } catch (IllegalArgumentException ex) {
            String m = ex.getMessage();
            if (m != null && m.contains("number") || m != null && m.contains("saved")) Ui.error(number, m);
            else if (m != null && m.startsWith("Cardholder")) Ui.error(holder, m);
            else if (m != null && m.startsWith("Product")) Ui.error(product, m);
            else toast(m);
        } catch (RuntimeException ex) {
            Dialogs.info(this, "Couldn't save", "Encryption failed: " + ex.getMessage());
        }
    }

    // ------------------------------------------------------------ NFC

    private void startScan(final NfcAdapter nfc) {
        if (!nfc.isEnabled()) {
            Dialogs.confirm(this, "NFC is off", "Turn on NFC in system settings to scan a card, or enter the details manually.",
                    "Open settings", false, new Dialogs.Done() {
                        @Override public void run() { startExternal(new Intent(Settings.ACTION_NFC_SETTINGS), -1); }
                    });
            return;
        }
        final TextView msg = Ui.body(this, "Hold the card flat against the back of your phone and keep it still.");
        int p = Ui.dp(this, 24);
        msg.setPadding(p, Ui.dp(this, 12), p, 0);
        scanDialog = Dialogs.builder(this).setTitle("Scan card").setView(msg)
                .setNegativeButton("Cancel", null)
                .setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override public void onDismiss(DialogInterface d) {
                        try { nfc.disableReaderMode(SavedCardEditActivity.this); } catch (RuntimeException ignored) { }
                        scanDialog = null;
                    }
                })
                .create();
        scanDialog.show();
        int flags = NfcAdapter.FLAG_READER_NFC_A | NfcAdapter.FLAG_READER_NFC_B
                | NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK | NfcAdapter.FLAG_READER_NO_PLATFORM_SOUNDS;
        nfc.enableReaderMode(this, new NfcAdapter.ReaderCallback() {
            @Override public void onTagDiscovered(Tag tag) { readTag(tag, msg); }
        }, flags, null);
    }

    private void stopScan() {
        if (scanDialog != null) scanDialog.dismiss();
    }

    /** Runs on the NFC reader thread. */
    private void readTag(Tag tag, final TextView msg) {
        final IsoDep iso = IsoDep.get(tag);
        if (iso == null) {
            post(msg, "This doesn't look like a payment card. Try again or enter details manually.", null);
            return;
        }
        Emv.Result result = null;
        String error = null;
        try {
            iso.connect();
            iso.setTimeout(5000);
            result = Emv.read(new Emv.Transceiver() {
                @Override public byte[] transceive(byte[] apdu) throws IOException { return iso.transceive(apdu); }
            });
        } catch (IOException e) {
            error = "Couldn't read the card (" + e.getMessage() + "). Hold it still and try again, or enter details manually.";
        } catch (RuntimeException e) {
            error = "Couldn't read the card. Try again or enter details manually.";
        } finally {
            try { iso.close(); } catch (IOException ignored) { }
        }
        post(msg, error, result);
    }

    private void post(final TextView msg, final String error, final Emv.Result r) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                if (r == null) {
                    if (msg != null) msg.setText(error);
                    return;
                }
                number.setText(r.number);
                if (r.expMonth > 0) expiry.setText(pad2(r.expMonth) + "/" + pad2(r.expYear % 100));
                if (!r.holder.isEmpty() && holder.getText().length() == 0) holder.setText(r.holder);
                if (!r.network.isEmpty()) {
                    network = r.network;
                    networkManual = false;
                    renderNetwork();
                }
                if (product.getText().length() == 0 && !r.label.isEmpty() && !r.label.equalsIgnoreCase(r.network)) {
                    product.setText(r.label);
                }
                stopScan();
                toast(r.holder.isEmpty() ? "Card read. This card doesn't share the cardholder name." : "Card read");
            }
        });
    }

    private static String pad2(int v) { return v < 10 ? "0" + v : String.valueOf(v); }

    /** Inserts the "/" in MM/YY while typing. */
    private static final class ExpiryFormatter implements TextWatcher {
        private boolean editing;

        @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
        @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }

        @Override public void afterTextChanged(Editable e) {
            if (editing) return;
            editing = true;
            String digits = e.toString().replace("/", "");
            String out = digits.length() > 2 ? digits.substring(0, 2) + "/" + digits.substring(2, Math.min(4, digits.length())) : digits;
            if (!out.equals(e.toString())) e.replace(0, e.length(), out);
            editing = false;
        }
    }
}
