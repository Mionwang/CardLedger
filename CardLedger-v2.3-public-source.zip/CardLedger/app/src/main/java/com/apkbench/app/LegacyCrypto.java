package com.apkbench.app;

import android.content.Context;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.AtomicFile;
import java.io.File;
import java.io.FileOutputStream;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** AES-GCM payloads; a device-authenticated Keystore key wraps the session key. */
final class LegacyCrypto {
    private static final String ALIAS = "cardledger.vault.wrap.v1";
    private static final byte[] WRAP_AAD = "CardLedger wrapped vault key v1".getBytes(java.nio.charset.StandardCharsets.UTF_8);
    private static final byte[] ROW_AAD = "CardLedger saved card v1".getBytes(java.nio.charset.StandardCharsets.UTF_8);
    private LegacyCrypto() {}

    static byte[] unlock(Context context) throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        AtomicFile file = new AtomicFile(new File(context.getNoBackupFilesDir(), "vault-key-v1"));
        boolean existing = file.getBaseFile().exists() || new File(file.getBaseFile()+".bak").exists();
        if (!existing) {
            if (App.get().hasStoredVaultRows())
                throw new java.security.KeyStoreException("Wrapped vault key missing; preserving saved cards");
        }
        if (!store.containsAlias(ALIAS)) {
            if (existing) throw new java.security.KeyStoreException("Original device key unavailable");
            KeyGenParameterSpec.Builder builder = new KeyGenParameterSpec.Builder(ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setUserAuthenticationRequired(true);
            if (Build.VERSION.SDK_INT >= 30) {
                builder.setUserAuthenticationParameters(15,
                        KeyProperties.AUTH_BIOMETRIC_STRONG | KeyProperties.AUTH_DEVICE_CREDENTIAL);
            } else {
                builder.setUserAuthenticationValidityDurationSeconds(15);
            }
            if (Build.VERSION.SDK_INT >= 24) builder.setInvalidatedByBiometricEnrollment(false);
            KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            generator.init(builder.build());
            generator.generateKey();
        }
        SecretKey wrapKey = (SecretKey) store.getKey(ALIAS, null);
        if (existing) {
            byte[] unwrapped = decrypt(wrapKey, file.readFully(), WRAP_AAD);
            if (unwrapped.length != 32) {
                Arrays.fill(unwrapped, (byte) 0);
                throw new java.security.GeneralSecurityException("Invalid vault key");
            }
            return unwrapped;
        }
        byte[] key = new byte[32];
        new SecureRandom().nextBytes(key);
        byte[] wrapped;
        try { wrapped = encrypt(wrapKey, key, WRAP_AAD); }
        catch (Exception e) { Arrays.fill(key, (byte) 0); throw e; }
        FileOutputStream out = null;
        try {
            out = file.startWrite();
            out.write(wrapped);
            file.finishWrite(out);
            return key;
        } catch (Exception e) {
            if (out != null) file.failWrite(out);
            Arrays.fill(key, (byte) 0);
            throw e;
        }
    }
    static byte[] seal(byte[] key, byte[] plain) throws Exception {
        return encrypt(new SecretKeySpec(key, "AES"), plain, ROW_AAD);
    }
    static byte[] open(byte[] key, byte[] blob) throws Exception {
        return decrypt(new SecretKeySpec(key, "AES"), blob, ROW_AAD);
    }
    private static byte[] encrypt(SecretKey key, byte[] plain, byte[] aad) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        cipher.updateAAD(aad);
        byte[] encrypted = cipher.doFinal(plain);
        byte[] iv = cipher.getIV();
        if (iv.length != 12) throw new java.security.GeneralSecurityException("Unexpected GCM nonce");
        byte[] blob = new byte[1 + 12 + encrypted.length];
        blob[0] = 1;
        System.arraycopy(iv, 0, blob, 1, 12);
        System.arraycopy(encrypted, 0, blob, 13, encrypted.length);
        return blob;
    }
    private static byte[] decrypt(SecretKey key, byte[] blob, byte[] aad) throws Exception {
        if (blob.length < 29 || blob[0] != 1) throw new java.security.GeneralSecurityException("Invalid encrypted data");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, blob, 1, 12));
        cipher.updateAAD(aad);
        return cipher.doFinal(blob, 13, blob.length-13);
    }
}
