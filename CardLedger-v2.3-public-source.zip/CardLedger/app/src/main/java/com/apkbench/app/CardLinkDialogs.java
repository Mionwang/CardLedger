package com.apkbench.app;

import android.content.Intent;
import com.apkbench.app.core.*;
import java.util.ArrayList;
import java.util.List;

/** Linking is deliberately reached through the three-dot menus, never through card credentials. */
final class CardLinkDialogs {
    private CardLinkDialogs() {}
    private static boolean ready(BaseActivity a) { return !a.app.isLocked(); }
    private static CardInfo saved(BaseActivity a,long id) { return a.app.vault().get(id); }
    private static String status(CardLinks.Link l) {
        if (l == null) return "Not linked";
        if (l.needsReview()) return "Review suggested match";
        if ("auto".equals(l.status)) return "Linked automatically";
        if ("new".equals(l.status)) return "New ledger created";
        return "Linked";
    }

    static void manageAll(BaseActivity a) {
        if (!ready(a)) return;
        a.app.syncCardLinks();
        List<CardInfo> cards = a.app.vault().load().cards;
        if (cards.isEmpty()) { Dialogs.info(a,"Card links","Save a card to automatically create its ledger."); return; }
        // Pending reviews appear first, retaining the order of all other saved cards.
        List<CardInfo> ordered = new ArrayList<>();
        for (CardInfo c : cards) { CardLinks.Link l=a.app.links().forSaved(c.id); if (l != null && l.needsReview()) ordered.add(c); }
        for (CardInfo c : cards) if (!ordered.contains(c)) ordered.add(c);
        String[] labels = new String[ordered.size()];
        for (int i=0;i<labels.length;i++) {
            CardInfo c=ordered.get(i); CardLinks.Link l=a.app.links().forSaved(c.id);
            Models.Card ledger=l==null?null:a.app.ledger().getCard(l.ledgerId);
            labels[i]=c.title()+"\n"+(ledger==null?"No ledger":ledger.name)+" · "+status(l);
        }
        Dialogs.actions(a,"Manage card links",labels,i->manageSaved(a,ordered.get(i).id));
    }

    static void manageLedger(BaseActivity a,long ledgerId) {
        if (!ready(a)) return;
        CardLinks.Link link=a.app.links().forLedger(ledgerId);
        if (link==null) chooseSaved(a,ledgerId);
        else manageSaved(a,link.savedId);
    }

    static void manageSaved(BaseActivity a,long savedId) {
        if (!ready(a)) return;
        CardInfo card=saved(a,savedId);
        if (card==null) { a.toast("Saved card no longer exists"); return; }
        CardLinks.Link link=a.app.links().forSaved(savedId);
        if (link==null) { a.app.syncCardLinks(); link=a.app.links().forSaved(savedId); }
        if (link==null) return;
        final CardLinks.Link current=link;
        Models.Card ledger=a.app.ledger().getCard(link.ledgerId);
        String title=card.title()+"\nLedger: "+(ledger==null?"Not available":ledger.name)+"\n"+status(link);
        List<String> items=new ArrayList<>();
        items.add("Open ledger"); items.add("View saved card"); items.add("Choose another ledger"); items.add("Change linked saved card");
        if (link.needsReview()) items.add("Keep this as a separate ledger");
        items.add("Unlink saved card");
        Dialogs.actions(a,title,items.toArray(new String[0]),i->{
            if (!ready(a)) return;
            switch(i) {
                case 0: openLedger(a,savedId); return;
                case 1: a.startActivity(new Intent(a,SavedCardActivity.class).putExtra("id",savedId)); return;
                case 2: chooseLedger(a,savedId); return;
                case 3: chooseSaved(a,current.ledgerId); return;
                default:
                    if (current.needsReview() && i==4) { a.app.links().keepSeparate(savedId); a.rebuild(); }
                    else unlink(a,card,current);
            }
        });
    }

    static void openLedger(BaseActivity a,long savedId) {
        if (!ready(a)) return;
        a.app.syncCardLinks();
        CardLinks.Link link=a.app.links().forSaved(savedId);
        if (link!=null) a.startActivity(new Intent(a,CardDetailActivity.class).putExtra("card",link.ledgerId));
    }

    static void chooseSaved(BaseActivity a,long ledgerId) {
        if (!ready(a)) return;
        List<CardInfo> cards=a.app.vault().load().cards;
        if (cards.isEmpty()) { Dialogs.info(a,"No saved cards","Add a saved card first. Your ledger can still be used independently."); return; }
        String[] labels=new String[cards.size()];
        for(int i=0;i<cards.size();i++) {
            CardInfo c=cards.get(i); CardLinks.Link l=a.app.links().forSaved(c.id);
            Models.Card existing=l==null?null:a.app.ledger().getCard(l.ledgerId);
            labels[i]=c.title()+(c.network.isEmpty()?"":" · "+c.network)+"\n"+
                    (existing==null?"Not linked":"Ledger: "+existing.name);
        }
        Dialogs.actions(a,"Link saved card",labels,i->confirmLink(a,cards.get(i).id,ledgerId));
    }

    private static void chooseLedger(BaseActivity a,long savedId) {
        if (!ready(a)) return;
        List<Models.Card> cards=a.app.ledger().listCards();
        CardInfo card=saved(a,savedId);
        List<Models.Card> ordered=new ArrayList<>();
        // Exact names appear first as suggestions; changing the link still needs confirmation.
        for(Models.Card c:cards) if(CardLinks.normalized(c.name).equals(CardLinks.normalized(card.title()))) ordered.add(c);
        for(Models.Card c:cards) if(!ordered.contains(c)) ordered.add(c);
        String[] labels=new String[ordered.size()];
        for(int i=0;i<labels.length;i++) {
            Models.Card c=ordered.get(i); CardLinks.Link l=a.app.links().forLedger(c.id);
            labels[i]=c.name+"\n"+a.app.money(a.app.ledger().summary(c.id).outstanding)+
                    (l!=null&&l.savedId==savedId?" · Current ledger":l!=null?" · Linked to another saved card":"");
        }
        Dialogs.actions(a,"Choose ledger",labels,i->confirmLink(a,savedId,ordered.get(i).id));
    }

    private static void confirmLink(BaseActivity a,long savedId,long ledgerId) {
        if (!ready(a)) return;
        CardInfo card=saved(a,savedId);
        CardLinks.Link source=a.app.links().forSaved(savedId), occupied=a.app.links().forLedger(ledgerId);
        Models.Card target=a.app.ledger().getCard(ledgerId);
        if(card==null||target==null) { a.toast("Card no longer exists"); return; }
        if(source!=null&&source.ledgerId==ledgerId) { a.app.links().keepSeparate(savedId); a.rebuild(); return; }
        String message="Saved card: "+card.title()+"\nLedger: "+target.name+"\n\nThe existing ledger's entries, recurring payments and billing day stay intact.";
        if(occupied!=null&&occupied.savedId!=savedId) message+="\n\nIts previous saved card will receive a separate zero-balance ledger.";
        boolean history=source!=null&&a.app.links().hasEntries(source.ledgerId);
        if(history) message+="\n\nLink only keeps the previous ledger and its history separate. Combine histories moves its entries and recurring payments into this ledger.";
        android.app.AlertDialog.Builder builder=Dialogs.builder(a).setTitle("Confirm card link").setMessage(message)
                .setNegativeButton("Cancel",null).setPositiveButton(history?"Link only":"Link card",(d,w)->connect(a,savedId,ledgerId,false));
        if(history) builder.setNeutralButton("Combine histories",(d,w)->{
            if(!ready(a)) return;
            Models.CardSummary from=a.app.ledger().summary(source.ledgerId), to=a.app.ledger().summary(ledgerId);
            Dialogs.confirm(a,"Combine ledgers?",from.card.name+": "+a.app.money(from.outstanding)+", "+from.txnCount+" entries, "+from.ruleCount+" rules.\n"
                    +to.card.name+": "+a.app.money(to.outstanding)+", "+to.txnCount+" entries, "+to.ruleCount+" rules.\n\n"
                    +"All entries and rules move into "+to.card.name+". The previous ledger is removed. Total due stays unchanged. Existing duplicate expenses are not removed automatically.",
                    "Combine and link",true,()->connect(a,savedId,ledgerId,true));
        });
        builder.show();
    }

    private static void connect(BaseActivity a,long savedId,long ledgerId,boolean merge) {
        if(!ready(a))return;
        try { a.app.links().connect(savedId,ledgerId,merge); a.rebuild(); a.toast("Card linked"); }
        catch(RuntimeException e){Dialogs.info(a,"Couldn't link cards",e.getMessage());}
    }

    private static void unlink(BaseActivity a,CardInfo saved,CardLinks.Link link) {
        Models.Card ledger=a.app.ledger().getCard(link.ledgerId);
        Dialogs.confirm(a,"Unlink saved card?","Keep "+ledger.name+" and its history as a ledger-only card. "+saved.title()+
                " will receive a separate zero-balance ledger.","Unlink",false,()->{
            if(!ready(a))return;
            a.app.links().unlink(saved.id,saved.title()); a.rebuild();
        });
    }

    static void deleteOrReset(BaseActivity a,Models.Card card) {
        boolean linked=a.app.links().forLedger(card.id)!=null;
        Dialogs.confirm(a,linked?"Reset "+card.name+"?":"Delete "+card.name+"?",
                linked?"Clears all transactions and recurring payments. The card, saved credentials, link and billing date remain, with a zero balance. This can't be undone."
                        :"Deletes this ledger, all its transactions and recurring payments. This can't be undone.",
                linked?"Reset ledger":"Delete ledger",true,()->{
                    if(!ready(a))return;
                    a.app.ledger().deleteCard(card.id);
                    if(a.app.ledger().getCard(card.id)==null && a instanceof CardDetailActivity) a.finish(); else a.rebuild();
                });
    }
}
