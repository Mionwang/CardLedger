package com.apkbench.app.core;

import java.util.Calendar;

/**
 * Saved payment-card record (Saved Cards tab) plus validation, network detection
 * and masking helpers. Never contains example data.
 */
public final class CardInfo {
    public static final String[] NETWORKS = {"Visa", "Mastercard", "RuPay", "American Express", "Discover",
            "Diners Club", "JCB", "UnionPay", "Maestro", "Other"};
    public static final String KIND_CREDIT = "Credit";
    public static final String KIND_DEBIT = "Debit";

    public long id;
    public String bank = "";
    public String product = "";
    public String holder = "";
    public String number = "";   // digits only
    public int expMonth;         // 1-12
    public int expYear;          // four digits
    public String network = "";
    public String kind = KIND_CREDIT;
    public String cvv = "";      // "" = not saved; kept as text so leading zeros survive
    public long createdAt;
    public long updatedAt;

    public String expiry() { return expMonth == 0 && expYear == 0 ? "" : pad2(expMonth) + "/" + pad2(expYear % 100); }

    public String last4() { return number.length() >= 4 ? number.substring(number.length() - 4) : number; }

    public String title() {
        String t = (bank + " " + product).trim();
        return t.isEmpty() ? network : t;
    }

    // ================================================================ validation

    public static String digitsOnly(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '0' && c <= '9') b.append(c);
            else if (c != ' ' && c != '-') return null; // invalid character
        }
        return b.toString();
    }

    public static boolean luhn(String digits) {
        int sum = 0;
        boolean dbl = false;
        for (int i = digits.length() - 1; i >= 0; i--) {
            int d = digits.charAt(i) - '0';
            if (d < 0 || d > 9) return false;
            if (dbl) { d *= 2; if (d > 9) d -= 9; }
            sum += d;
            dbl = !dbl;
        }
        return sum % 10 == 0;
    }

    /** Validates a card number; returns digits-only form. */
    public static String validateNumber(String raw) {
        String d = digitsOnly(raw);
        if (d == null) throw new IllegalArgumentException("Card number may contain only digits");
        if (d.isEmpty()) throw new IllegalArgumentException("Card number is required");
        if (d.length() < 12 || d.length() > 19) throw new IllegalArgumentException("Card number must be 12-19 digits");
        if (!luhn(d)) throw new IllegalArgumentException("Card number is not valid (checksum failed)");
        return d;
    }

    /** Parses "MM/YY", "MM/YYYY", "MMYY". Returns {month, fourDigitYear}. */
    public static int[] parseExpiry(String raw) {
        if (raw == null) throw new IllegalArgumentException("Expiry is required");
        String s = raw.trim().replace(" ", "");
        String mm, yy;
        int slash = s.indexOf('/');
        if (slash < 0) slash = s.indexOf('-');
        if (slash >= 0) {
            mm = s.substring(0, slash);
            yy = s.substring(slash + 1);
        } else if (s.length() == 4 || s.length() == 6) {
            mm = s.substring(0, 2);
            yy = s.substring(2);
        } else {
            throw new IllegalArgumentException("Expiry must be MM/YY");
        }
        if (mm.length() < 1 || mm.length() > 2 || !(yy.length() == 2 || yy.length() == 4)) {
            throw new IllegalArgumentException("Expiry must be MM/YY");
        }
        int m, y;
        try {
            m = Integer.parseInt(mm);
            y = Integer.parseInt(yy);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Expiry must be MM/YY");
        }
        if (m < 1 || m > 12) throw new IllegalArgumentException("Expiry month must be 01-12");
        if (yy.length() == 2) y += 2000;
        return new int[]{m, y};
    }

    /** Rejects expired cards and implausible far-future years. {@code nowYear/nowMonth} = today. */
    public static void validateExpiry(int month, int year, int nowYear, int nowMonth) {
        if (month < 1 || month > 12) throw new IllegalArgumentException("Expiry month must be 01-12");
        if (year < nowYear || (year == nowYear && month < nowMonth)) throw new IllegalArgumentException("Card has expired");
        if (year > nowYear + 25) throw new IllegalArgumentException("Expiry year is too far in the future");
    }

    public static void validateExpiryNow(int month, int year) {
        Calendar c = Calendar.getInstance();
        validateExpiry(month, year, c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1);
    }

    /** CVV is optional. Amex uses 4 digits, the major 3-digit networks use 3, others allow 3 or 4. */
    public static String validateCvv(String raw, String network) {
        String s = raw == null ? "" : raw.trim();
        if (s.isEmpty()) return "";
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c < '0' || c > '9') throw new IllegalArgumentException("CVV may contain only digits");
        }
        if (s.length() != 3 && s.length() != 4) throw new IllegalArgumentException("CVV must be 3 or 4 digits");
        if ("American Express".equals(network) && s.length() != 4) throw new IllegalArgumentException("American Express CVV is 4 digits");
        if (isThreeDigitNetwork(network) && s.length() != 3) throw new IllegalArgumentException(network + " CVV is 3 digits");
        return s;
    }

    static boolean isThreeDigitNetwork(String n) {
        return "Visa".equals(n) || "Mastercard".equals(n) || "RuPay".equals(n) || "Discover".equals(n)
                || "JCB".equals(n) || "UnionPay".equals(n) || "Diners Club".equals(n) || "Maestro".equals(n);
    }

    public static String cleanField(String s, int max, String field, boolean required) {
        String t = s == null ? "" : s.trim().replaceAll("\\s+", " ");
        if (required && t.isEmpty()) throw new IllegalArgumentException(field + " is required");
        if (t.length() > max) throw new IllegalArgumentException(field + " is too long");
        return t;
    }

    /** Full validation of a record before saving. Normalizes fields in place. */
    public void validate(int nowYear, int nowMonth) {
        bank = cleanField(bank, 60, "Issuing bank", true);
        product = cleanField(product, 60, "Product name", false);
        holder = cleanField(holder, 60, "Cardholder name", false);
        number = validateNumber(number);
        validateExpiry(expMonth, expYear, nowYear, nowMonth);
        if (network == null || network.trim().isEmpty()) network = detectNetwork(number);
        network = network.trim();
        if (!KIND_CREDIT.equals(kind) && !KIND_DEBIT.equals(kind)) kind = KIND_CREDIT;
        cvv = validateCvv(cvv, network);
    }

    public void validateNow() {
        Calendar c = Calendar.getInstance();
        validate(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1);
    }

    // ================================================================ networks

    /** Best-effort network from the number prefix (IIN ranges). */
    public static String detectNetwork(String digits) {
        if (digits == null || digits.isEmpty()) return "Other";
        int p2 = prefix(digits, 2), p3 = prefix(digits, 3), p4 = prefix(digits, 4), p6 = prefix(digits, 6);
        if (p2 == 34 || p2 == 37) return "American Express";
        if (p2 == 36 || p2 == 38 || p2 == 39 || (p3 >= 300 && p3 <= 305) || p3 == 309) return "Diners Club";
        if (p4 >= 3528 && p4 <= 3589) return "JCB";
        // RuPay ranges (checked before Discover/Maestro which overlap)
        if (p2 == 60 && !(p4 == 6011)) return "RuPay";
        if (p3 == 508 || p2 == 81 || p2 == 82 || (p6 >= 652150 && p6 <= 653149)) return "RuPay";
        if (p4 == 6011 || p2 == 65 || (p3 >= 644 && p3 <= 649) || (p6 >= 622126 && p6 <= 622925)) return "Discover";
        if (p2 == 62) return "UnionPay";
        if (digits.charAt(0) == '4') return "Visa";
        if ((p2 >= 51 && p2 <= 55) || (p4 >= 2221 && p4 <= 2720)) return "Mastercard";
        if (p2 == 50 || (p2 >= 56 && p2 <= 69)) return "Maestro";
        return "Other";
    }

    private static int prefix(String d, int n) {
        if (d.length() < n) return -1;
        try { return Integer.parseInt(d.substring(0, n)); } catch (NumberFormatException e) { return -1; }
    }

    // ================================================================ masking

    /** "•••• •••• •••• 1234" */
    public static String mask(String digits) {
        if (digits == null || digits.length() < 4) return "••••";
        return "•••• •••• •••• " + digits.substring(digits.length() - 4);
    }

    public static String maskCvv(String cvv) {
        if (cvv == null || cvv.isEmpty()) return "Not saved";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < cvv.length(); i++) b.append('•');
        return b.toString();
    }

    /** Groups digits for display: Amex 4-6-5, others blocks of 4. */
    public static String group(String digits, String network) {
        if (digits == null) return "";
        StringBuilder b = new StringBuilder();
        if (digits.length() == 15 && ("American Express".equals(network) || "Diners Club".equals(network))) {
            b.append(digits, 0, 4).append(' ').append(digits, 4, 10).append(' ').append(digits, 10, 15);
            return b.toString();
        }
        for (int i = 0; i < digits.length(); i++) {
            if (i > 0 && i % 4 == 0) b.append(' ');
            b.append(digits.charAt(i));
        }
        return b.toString();
    }

    static String pad2(int v) { return v < 10 ? "0" + v : String.valueOf(v); }
}
