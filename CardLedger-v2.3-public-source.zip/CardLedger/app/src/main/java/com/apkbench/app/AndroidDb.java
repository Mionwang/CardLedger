package com.apkbench.app;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;

import com.apkbench.app.core.Db;
import com.apkbench.app.core.Schema;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** {@link Db} on the app's private SQLite database (survives restarts and app updates). */
final class AndroidDb implements Db, AutoCloseable {
    private static final String NAME = "card_ledger_v2.db";

    private final Helper helper;
    private final SQLiteDatabase legacy;

    AndroidDb(Context ctx) { helper = new Helper(ctx.getApplicationContext()); legacy = null; }
    AndroidDb(SQLiteDatabase readOnly) { helper = null; legacy = readOnly; }
    @Override public void close() { if (legacy != null) legacy.close(); else helper.close(); }

    private static final class Helper extends SQLiteOpenHelper {
        Helper(Context c) { super(c, NAME, null, Schema.VERSION); }

        @Override public void onConfigure(SQLiteDatabase db) {
            db.setForeignKeyConstraintsEnabled(true);
        }

        @Override public void onCreate(SQLiteDatabase db) {
            for (String sql : Schema.CREATE) db.execSQL(sql);
        }

        @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
            for (String sql : Schema.upgradesFrom(oldV)) db.execSQL(sql);
        }

        @Override public void onDowngrade(SQLiteDatabase db, int oldV, int newV) {
            throw new IllegalStateException("Database is from a newer version of Card Ledger");
        }
    }

    private SQLiteDatabase w() { return legacy != null ? legacy : helper.getWritableDatabase(); }

    private static void bind(SQLiteStatement st, Object[] args) {
        for (int i = 0; i < args.length; i++) {
            Object a = args[i];
            int idx = i + 1;
            if (a == null) st.bindNull(idx);
            else if (a instanceof Long) st.bindLong(idx, (Long) a);
            else if (a instanceof Integer) st.bindLong(idx, (Integer) a);
            else if (a instanceof Boolean) st.bindLong(idx, ((Boolean) a) ? 1 : 0);
            else if (a instanceof byte[]) st.bindBlob(idx, (byte[]) a);
            else st.bindString(idx, a.toString());
        }
    }

    @Override public long insert(String sql, Object... args) {
        SQLiteStatement st = w().compileStatement(sql);
        try {
            bind(st, args);
            long id = st.executeInsert();
            if (id < 0) throw new IllegalStateException("Insert failed");
            return id;
        } finally {
            st.close();
        }
    }

    @Override public int exec(String sql, Object... args) {
        SQLiteStatement st = w().compileStatement(sql);
        try {
            bind(st, args);
            return st.executeUpdateDelete();
        } finally {
            st.close();
        }
    }

    @Override public List<Row> query(String sql, Object... args) {
        String[] sargs = new String[args.length];
        for (int i = 0; i < args.length; i++) {
            Object a = args[i];
            if (a instanceof Boolean) a = ((Boolean) a) ? 1 : 0;
            sargs[i] = a == null ? null : a.toString();
        }
        Cursor c = w().rawQuery(sql, sargs);
        try {
            String[] cols = c.getColumnNames();
            Map<String, Integer> idx = Row.indexOf(cols);
            List<Row> out = new ArrayList<Row>();
            while (c.moveToNext()) {
                Object[] vals = new Object[cols.length];
                for (int i = 0; i < cols.length; i++) {
                    switch (c.getType(i)) {
                        case Cursor.FIELD_TYPE_NULL: vals[i] = null; break;
                        case Cursor.FIELD_TYPE_INTEGER: vals[i] = c.getLong(i); break;
                        case Cursor.FIELD_TYPE_FLOAT: vals[i] = c.getString(i); break;
                        case Cursor.FIELD_TYPE_BLOB: vals[i] = c.getBlob(i); break;
                        default: vals[i] = c.getString(i); break;
                    }
                }
                out.add(new Row(idx, vals));
            }
            return out;
        } finally {
            c.close();
        }
    }

    @Override public void transaction(Runnable work) {
        SQLiteDatabase db = w();
        db.beginTransaction();
        try {
            work.run();
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }
}
