package com.apkbench.app;

import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.apkbench.app.core.BillingCycle;
import com.apkbench.app.core.CardInfo;
import com.apkbench.app.core.CivilDate;
import com.apkbench.app.core.LedgerRepo;
import com.apkbench.app.core.LedgerTransfer;
import com.apkbench.app.core.Models;
import com.apkbench.app.core.SavedCardImport;
import com.apkbench.app.core.VaultRepo;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.List;

/** Home: Ledger tab (TOTAL DUE + card tiles) and Saved Cards tab. */
public class MainActivity extends BaseActivity {
    private static final int REQ_EXPORT = 1, REQ_IMPORT_LEDGER = 2, REQ_IMPORT_CARDS = 3;
    private static final Charset UTF8 = Charset.forName("UTF-8");

    private int tab;

    @Override protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        tab = app.prefs().getInt("tab", 0);
    }

    @Override protected View build() {
        app.syncCardLinks();
        LinearLayout page = Ui.col(this);
        View lock = Ui.icon(this, Shapes.ICON_LOCK, "Lock now", new View.OnClickListener() {
            @Override public void onClick(View v) {
                app.lock();
                LockActivity.show(MainActivity.this, false);
            }
        });
        View menu = Ui.icon(this, Shapes.ICON_MORE, "More options", new View.OnClickListener() {
            @Override public void onClick(View v) { showMenu(v); }
        });
        page.addView(topBar(tab == 0 ? null : "Saved cards", tab == 0 ? null : "Encrypted on this phone", false, lock, menu));

        LinearLayout body = Ui.col(this);
        body.setPadding(0, 0, 0, Ui.dp(this, 24));
        if (tab == 0) buildLedger(body); else buildVault(body);
        page.addView(Ui.scroll(this, body), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        page.addView(bottomBar());
        return page;
    }

    // ------------------------------------------------------------ bottom bar

    /** Two text destinations with a Material 3 pill indicator, and the FAB for the current tab. */
    private View bottomBar() {
        LinearLayout bar = Ui.row(this);
        int p = Ui.dp(this, 16);
        bar.setPadding(p, Ui.dp(this, 8), Ui.dp(this, 20), Ui.dp(this, 16));
        String[] names = {"Ledger", "Saved cards"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            boolean on = i == tab;
            TextView t = Ui.text(this, names[i], 16, on ? Ui.ON_TONAL : Ui.MUTED, Ui.MEDIUM);
            t.setGravity(Gravity.CENTER);
            t.setMinHeight(Ui.dp(this, 44));
            int ph = Ui.dp(this, 18);
            t.setPadding(ph, 0, ph, 0);
            t.setBackground(Ui.ripple(this, on ? Ui.rounded(this, Ui.TONAL, 22, 0) : null, 22));
            t.setClickable(true);
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (tab == idx) return;
                    tab = idx;
                    app.prefs().edit().putInt("tab", tab).apply();
                    rebuild();
                }
            });
            bar.addView(t, Ui.margins(this, Ui.lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT), 0, 0, 6, 0));
        }
        bar.addView(Ui.flex(this));
        View fab = Ui.fab(this, tab == 0 ? "Add card" : "Add saved card", new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (tab == 0) addCard(); else startActivity(intent(SavedCardEditActivity.class));
            }
        });
        int f = Ui.dp(this, 56);
        bar.addView(fab, Ui.lp(f, f));
        return bar;
    }

    // ------------------------------------------------------------ ledger

    private void buildLedger(LinearLayout body) {
        List<Models.CardSummary> cards = app.ledger().summaries();
        long total = LedgerRepo.totalDue(cards);
        int side = 24;

        body.addView(Ui.label(this, "Total due"), Ui.margins(this, Ui.matchWrap(), side, 8, side, 2));
        body.addView(Ui.figure(this, app.money(total), 64, total < 0 ? Ui.CREDIT : Ui.TEXT),
                Ui.margins(this, Ui.matchWrap(), side - 3, 0, side, 6));
        int active = 0;
        for (Models.CardSummary s : cards) active += s.activeRuleCount;
        String sub = cards.isEmpty() ? "No cards yet" : (cards.size() == 1 ? "Across 1 card" : "Across " + cards.size() + " cards");
        if (active > 0) sub += ", " + active + " recurring";
        if (total < 0) sub += ". You're in credit.";
        body.addView(Ui.muted(this, sub), Ui.margins(this, Ui.matchWrap(), side, 0, side, 36));

        if (cards.isEmpty()) {
            body.addView(empty("Add your first card", "Tap + to add a credit card. Track its spending, cashback and "
                    + "recurring payments, all on this phone."));
            return;
        }
        java.util.Map<Long,CardInfo> savedById = new java.util.HashMap<>();
        for(CardInfo c : app.vault().load().cards) savedById.put(c.id,c);
        for(final Models.CardSummary summary : cards) {
            com.apkbench.app.core.CardLinks.Link link = app.links().forLedger(summary.card.id);
            CardInfo saved = link == null ? null : savedById.get(link.savedId);
            FrameLayout tile = LedgerTile.build(this,summary,saved,link!=null&&link.needsReview(),v->cardActions(summary));
            tile.setForeground(Ui.ripple(this,null,28));
            tile.setClickable(true);
            tile.setOnClickListener(v->startActivity(intent(CardDetailActivity.class).putExtra("card",summary.card.id)));
            tile.setOnLongClickListener(v->{cardActions(summary);return true;});
            body.addView(tile,Ui.margins(this,Ui.matchWrap(),16,0,16,12));
        }
    }

    private void addCard() {
        Dialogs.cardEditor(this, null, new Dialogs.Done() {
            @Override public void run() { rebuild(); }
        });
    }

    private void cardActions(final Models.CardSummary s) {
        com.apkbench.app.core.CardLinks.Link link=app.links().forLedger(s.card.id);
        Dialogs.actions(this,s.card.name,new String[]{"Open ledger","Rename / billing day","Mark paid",
                link==null?"Link saved card":link.needsReview()?"Review card link":"Linked saved card",
                link==null?"Delete ledger":"Reset ledger"},i->{
            if(i==0)startActivity(intent(CardDetailActivity.class).putExtra("card",s.card.id));
            else if(i==1)Dialogs.cardEditor(this,s.card,refresh());
            else if(i==2)confirmPaid(this,s.card);
            else if(i==3)CardLinkDialogs.manageLedger(this,s.card.id);
            else CardLinkDialogs.deleteOrReset(this,s.card);
        });
    }

    private MainActivity this_() { return this; }

    private Dialogs.Done refresh() {
        return new Dialogs.Done() {
            @Override public void run() { rebuild(); }
        };
    }

    static void confirmPaid(final BaseActivity a, final Models.Card card) {
        final App app = App.get();
        Models.CardSummary s = app.ledger().summary(card.id);
        Dialogs.confirm(a, "Mark " + card.name + " as paid?",
                "Clears " + s.txnCount + " transaction(s) and resets the balance of " + app.money(s.outstanding)
                        + " to zero. Recurring payments are kept. This can't be undone.",
                "Mark Paid", true, new Dialogs.Done() {
                    @Override public void run() {
                        app.ledger().markPaid(card.id);
                        a.toast(card.name + " marked paid");
                        a.rebuild();
                    }
                });
    }


    private View empty(String title, String text) {
        LinearLayout e = Ui.col(this);
        e.setPadding(Ui.dp(this, 24), Ui.dp(this, 8), Ui.dp(this, 24), Ui.dp(this, 24));
        e.addView(Ui.text(this, title, 22, Ui.TEXT, Ui.SANS));
        e.addView(Ui.muted(this, text), Ui.margins(this, Ui.matchWrap(), 0, 8, 0, 0));
        return e;
    }

    // ------------------------------------------------------------ saved cards

    private void buildVault(LinearLayout body) {
        VaultRepo.Loaded loaded;
        try {
            loaded = app.vault().load();
        } catch (RuntimeException e) {
            body.addView(empty("Vault unavailable", "The encryption key could not be opened: " + e.getMessage()));
            return;
        }
        if (loaded.cards.isEmpty() && loaded.unreadable.isEmpty()) {
            body.addView(empty("No saved cards", "Tap + to store a card's details, automatically linked to the ledger. "
                    + "Numbers stay masked until you reveal them."));
        }
        for (final CardInfo c : loaded.cards) {
            FrameLayout tile = CardTile.build(this, c, CardInfo.mask(c.number), v -> savedCardActions(c));
            tile.setForeground(Ui.ripple(this, null, 28));
            tile.setClickable(true);
            tile.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    startActivity(intent(SavedCardActivity.class).putExtra("id", c.id));
                }
            });
            tile.setOnLongClickListener(new View.OnLongClickListener() {
                @Override public boolean onLongClick(View v) { savedCardActions(c); return true; }
            });
            body.addView(tile, Ui.margins(this, Ui.matchWrap(), 16, 0, 16, 12));
        }
        for (final Long id : loaded.unreadable) {
            LinearLayout bad = Ui.panel(this);
            bad.setBackground(Ui.rounded(this, Ui.alpha(Ui.DANGER, 0x1F), 28, 0));
            bad.addView(Ui.text(this, "Unreadable record", 15, Ui.DANGER, Ui.MEDIUM));
            bad.addView(Ui.muted(this, "This saved card can't be decrypted (the device key may have been reset). "
                    + "Long-press to delete it."));
            bad.setOnLongClickListener(new View.OnLongClickListener() {
                @Override public boolean onLongClick(View v) {
                    Dialogs.confirm(MainActivity.this, "Delete unreadable record?", "It can't be recovered.", "Delete", true,
                            new Dialogs.Done() {
                                @Override public void run() { app.vault().delete(id); rebuild(); }
                            });
                    return true;
                }
            });
            body.addView(bad, Ui.margins(this, Ui.matchWrap(), 16, 0, 16, 12));
        }
    }

    private void savedCardActions(final CardInfo c) {
        Dialogs.actions(this, c.title() + " •• " + c.last4(), new String[]{"View", "Edit", "Open ledger", "Manage link", "Delete saved card"}, new Dialogs.Picked() {
            @Override public void picked(int i) {
                if (i == 0) startActivity(intent(SavedCardActivity.class).putExtra("id", c.id));
                else if (i == 1) startActivity(intent(SavedCardEditActivity.class).putExtra("id", c.id));
                else if (i == 2) CardLinkDialogs.openLedger(MainActivity.this,c.id);
                else if (i == 3) CardLinkDialogs.manageSaved(MainActivity.this,c.id);
                else Dialogs.confirm(MainActivity.this, "Delete saved card?", c.title() + " •• " + c.last4()
                            + " will be removed from Saved Cards. Its ledger and transaction history stay intact.", "Delete", true, new Dialogs.Done() {
                        @Override public void run() { app.vault().delete(c.id); rebuild(); }
                    });
            }
        });
    }

    // ------------------------------------------------------------ menu

    private void showMenu(View anchor) {
        String[] items = {"Manage card links", "Currency (" + app.currencyCode() + ")", "Export ledger", "Import ledger",
                "Import saved cards", "About"};
        Dialogs.actions(this, getString(R.string.app_name), items, new Dialogs.Picked() {
            @Override public void picked(int i) {
                switch (i) {
                    case 0: CardLinkDialogs.manageAll(MainActivity.this); break;
                    case 1: Dialogs.currency(MainActivity.this, refresh()); break;
                    case 2: startExport(); break;
                    case 3: startImport(REQ_IMPORT_LEDGER); break;
                    case 4: startImport(REQ_IMPORT_CARDS); break;
                    default: about(); break;
                }
            }
        });
    }

    private void about() {
        String version;
        try {
            version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            version = "?";
        }
        Dialogs.info(this, getString(R.string.app_name) + " " + version,
                "Works fully offline. No accounts, internet access, ads, analytics or cloud sync — the app has no "
                        + "network permission at all.\n\nLedger data lives in a private on-device database. Saved Cards are "
                        + "encrypted with AES-256-GCM using a key held in the Android Keystore. Backups and device "
                        + "transfer are disabled.\n\nCurrency changes only the symbol; amounts are never converted.");
    }

    private void startExport() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, "cardledger-ledger-" + CivilDate.iso(CivilDate.today()) + ".json");
        startExternal(i, REQ_EXPORT);
    }

    private void startImport(int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain", "application/octet-stream"});
        startExternal(i, req);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        if (app.isLocked()) return; // safety: never act on results while locked
        try {
            if (req == REQ_EXPORT) {
                String json = LedgerTransfer.export(app.ledger(), CivilDate.today());
                OutputStream os = getContentResolver().openOutputStream(uri, "wt");
                if (os == null) throw new IOException("Can't open file");
                try {
                    os.write(json.getBytes(UTF8));
                } finally {
                    os.close();
                }
                toast("Ledger exported");
            } else if (req == REQ_IMPORT_LEDGER) {
                final LedgerTransfer.Plan plan = LedgerTransfer.plan(app.ledger(), read(uri));
                String code = app.currencyCode();
                Dialogs.preview(this, "Import ledger", plan.describe(app.symbol(),
                                com.apkbench.app.core.Currencies.indianGrouping(code)),
                        plan.hasChanges() ? "Import" : "Nothing new", plan.hasChanges(), new Dialogs.Done() {
                            @Override public void run() {
                                try {
                                    int n = LedgerTransfer.apply(app.ledger(), plan);
                                    app.processRecurring();
                                    toast("Imported " + n + " transaction(s)");
                                } catch (RuntimeException e) {
                                    Dialogs.info(MainActivity.this, "Import failed", "Nothing was changed.\n\n" + e.getMessage());
                                }
                                rebuild();
                            }
                        });
            } else if (req == REQ_IMPORT_CARDS) {
                final SavedCardImport.Plan plan = SavedCardImport.plan(app.vault(), read(uri));
                final int n = plan.importable().size();
                Dialogs.preview(this, "Import saved cards", plan.describe(),
                        n > 0 ? "Encrypt & import " + n : "Nothing to import", n > 0, new Dialogs.Done() {
                            @Override public void run() {
                                try {
                                    SavedCardImport.apply(app.vault(), plan);
                                    toast("Imported " + n + " card(s)");
                                } catch (RuntimeException e) {
                                    Dialogs.info(MainActivity.this, "Import failed", "Nothing was changed.\n\n" + e.getMessage());
                                }
                                tab = 1;
                                app.prefs().edit().putInt("tab", 1).apply();
                                rebuild();
                            }
                        });
            }
        } catch (IllegalArgumentException e) {
            Dialogs.info(this, "Can't import this file", e.getMessage());
        } catch (Exception e) {
            Dialogs.info(this, "File error", String.valueOf(e.getMessage()));
        }
    }

    private String read(Uri uri) throws IOException {
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) throw new IOException("Can't open file");
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                if (out.size() > LedgerTransfer.MAX_BYTES) throw new IOException("File is too large");
            }
            return new String(out.toByteArray(), UTF8);
        } finally {
            in.close();
        }
    }
}
