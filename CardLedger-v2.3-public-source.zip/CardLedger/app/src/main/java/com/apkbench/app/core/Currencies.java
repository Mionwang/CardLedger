package com.apkbench.app.core;

import java.util.Locale;

/** Display currencies. Selecting one changes only the symbol; amounts are never converted. */
public final class Currencies {
    private Currencies() {}

    public static final String AUTO = "AUTO";
    public static final String DEFAULT = "INR";

    /** {code, symbol, name}; the first eight are the primary list. */
    public static final String[][] LIST = {
            {"INR", "₹", "Indian Rupee"},
            {"USD", "$", "US Dollar"},
            {"EUR", "€", "Euro"},
            {"GBP", "£", "British Pound"},
            {"AED", "AED ", "UAE Dirham"},
            {"CAD", "C$", "Canadian Dollar"},
            {"AUD", "A$", "Australian Dollar"},
            {"JPY", "¥", "Japanese Yen"},
            {"SGD", "S$", "Singapore Dollar"},
            {"CHF", "CHF ", "Swiss Franc"},
            {"CNY", "CN¥", "Chinese Yuan"},
            {"HKD", "HK$", "Hong Kong Dollar"},
            {"NZD", "NZ$", "New Zealand Dollar"},
            {"SAR", "SAR ", "Saudi Riyal"},
            {"QAR", "QAR ", "Qatari Riyal"},
            {"KWD", "KWD ", "Kuwaiti Dinar"},
            {"BHD", "BHD ", "Bahraini Dinar"},
            {"OMR", "OMR ", "Omani Rial"},
            {"BDT", "৳", "Bangladeshi Taka"},
            {"NPR", "NPR ", "Nepalese Rupee"},
            {"LKR", "LKR ", "Sri Lankan Rupee"},
            {"PKR", "PKR ", "Pakistani Rupee"},
            {"MYR", "RM", "Malaysian Ringgit"},
            {"THB", "฿", "Thai Baht"},
            {"IDR", "Rp", "Indonesian Rupiah"},
            {"PHP", "₱", "Philippine Peso"},
            {"KRW", "₩", "South Korean Won"},
            {"ZAR", "R", "South African Rand"},
            {"NGN", "₦", "Nigerian Naira"},
            {"KES", "KSh", "Kenyan Shilling"},
            {"EGP", "E£", "Egyptian Pound"},
            {"SEK", "kr ", "Swedish Krona"},
            {"NOK", "kr ", "Norwegian Krone"},
            {"DKK", "kr ", "Danish Krone"},
            {"PLN", "zł ", "Polish Złoty"},
            {"TRY", "₺", "Turkish Lira"},
            {"ILS", "₪", "Israeli Shekel"},
            {"BRL", "R$", "Brazilian Real"},
            {"MXN", "MX$", "Mexican Peso"},
            {"RUB", "₽", "Russian Ruble"},
    };

    public static String[] find(String code) {
        if (code == null) return null;
        for (String[] c : LIST) if (c[0].equalsIgnoreCase(code)) return c;
        return null;
    }

    public static String symbol(String code) {
        String[] c = find(code);
        return c != null ? c[1] : code + " ";
    }

    /** Currency for an ISO-3166 country code (e.g. from the SIM); INR when unknown. */
    public static String forCountry(String iso2) {
        if (iso2 == null || iso2.trim().length() != 2) return DEFAULT;
        try {
            java.util.Currency c = java.util.Currency.getInstance(new Locale("", iso2.trim().toUpperCase(Locale.US)));
            if (c == null) return DEFAULT;
            return c.getCurrencyCode();
        } catch (RuntimeException e) {
            return DEFAULT;
        }
    }

    /** Resolves a stored preference ("AUTO" or a code) to a currency code. */
    public static String resolve(String pref, String simCountry) {
        if (pref == null || AUTO.equals(pref)) return forCountry(simCountry);
        return pref;
    }

    public static boolean indianGrouping(String code) { return "INR".equals(code); }
}
