package com.apkbench.app.core;

import com.apkbench.app.core.Models.Card;
import com.apkbench.app.core.Models.CardSummary;
import com.apkbench.app.core.Models.Rule;
import com.apkbench.app.core.Models.Txn;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** All ledger persistence and business rules (cards, transactions, recurring payments). */
public class LedgerRepo {
    public static final int MAX_NAME = 60;
    public static final int MAX_TEXT = 200;
    public static final int MAX_NOTE = 1000;
    public static final int MAX_PAUSE_MONTHS = 120;

    protected final Db db;
    private final Clock clock;

    public interface Clock { long nowMillis(); }

    public static final Clock SYSTEM_CLOCK = new Clock() {
        @Override public long nowMillis() { return System.currentTimeMillis(); }
    };

    public LedgerRepo(Db db) { this(db, SYSTEM_CLOCK); }

    public LedgerRepo(Db db, Clock clock) {
        this.db = db;
        this.clock = clock;
    }

    public Db db() { return db; }

    // ================================================================ cards

    public static String cleanName(String name) {
        if (name == null) throw new IllegalArgumentException("Name is required");
        String n = name.trim().replaceAll("\\s+", " ");
        if (n.isEmpty()) throw new IllegalArgumentException("Name is required");
        if (n.length() > MAX_NAME) throw new IllegalArgumentException("Name is too long (max " + MAX_NAME + ")");
        return n;
    }

    public long createCard(String name, int billingDay) {
        final String n = cleanName(name);
        if (!BillingCycle.isValidDay(billingDay)) throw new IllegalArgumentException("Billing day must be 1-31");
        if (findCardByName(n, -1) != null) throw new IllegalArgumentException("A card named \"" + n + "\" already exists");
        return db.insert("INSERT INTO cards(name, billing_day, created_at) VALUES (?,?,?)",
                n, billingDay, clock.nowMillis());
    }

    public void updateCard(long id, String name, int billingDay) {
        String n = cleanName(name);
        if (!BillingCycle.isValidDay(billingDay)) throw new IllegalArgumentException("Billing day must be 1-31");
        if (findCardByName(n, id) != null) throw new IllegalArgumentException("A card named \"" + n + "\" already exists");
        int c = db.exec("UPDATE cards SET name=?, billing_day=? WHERE id=?", n, billingDay, id);
        if (c != 1) throw new IllegalArgumentException("Card not found");
    }

    public void deleteCard(final long id) {
        if (!db.query("SELECT saved_id FROM card_links WHERE ledger_id=?", id).isEmpty()) {
            resetCard(id);
            return;
        }
        db.transaction(new Runnable() {
            @Override public void run() {
                db.exec("DELETE FROM txns WHERE card_id=?", id);
                db.exec("DELETE FROM rules WHERE card_id=?", id);
                db.exec("DELETE FROM cards WHERE id=?", id);
            }
        });
    }

    /** A saved card must remain represented; reset its ledger without deleting its identity. */
    public void resetCard(final long id) {
        db.transaction(new Runnable() {
            @Override public void run() {
                db.exec("DELETE FROM txns WHERE card_id=?", id);
                db.exec("DELETE FROM rules WHERE card_id=?", id);
            }
        });
    }

    public Card getCard(long id) {
        List<Db.Row> r = db.query("SELECT * FROM cards WHERE id=?", id);
        return r.isEmpty() ? null : card(r.get(0));
    }

    public Card findCardByName(String name, long excludeId) {
        for (Db.Row row : db.query("SELECT * FROM cards WHERE id<>?", excludeId)) {
            if (row.getString("name").equalsIgnoreCase(name.trim())) return card(row);
        }
        return null;
    }

    public List<Card> listCards() {
        List<Card> out = new ArrayList<Card>();
        for (Db.Row row : db.query("SELECT * FROM cards ORDER BY id")) out.add(card(row));
        return out;
    }

    private static Card card(Db.Row r) {
        Card c = new Card();
        c.id = r.getLong("id");
        c.name = r.getString("name");
        c.billingDay = r.getInt("billing_day");
        c.createdAt = r.getLong("created_at");
        return c;
    }

    /** Summaries for every card in display order (see {@link Models#CARD_ORDER}). */
    public List<CardSummary> summaries() {
        return summaries(CivilDate.today());
    }

    public List<CardSummary> summaries(long today) {
        Map<Long, CardSummary> map = new HashMap<Long, CardSummary>();
        List<CardSummary> out = new ArrayList<CardSummary>();
        for (Card c : listCards()) {
            CardSummary s = new CardSummary();
            s.card = c;
            map.put(c.id, s);
            out.add(s);
        }
        for (Db.Row r : db.query("SELECT card_id, type, amount FROM txns")) {
            CardSummary s = map.get(r.getLong("card_id"));
            if (s == null) continue;
            long a = r.getLong("amount");
            if (r.getInt("type") == Models.TYPE_CASHBACK) s.cashback = Money.add(s.cashback, a);
            else s.expenses = Money.add(s.expenses, a);
            s.txnCount++;
        }
        for (Rule rule : listAllRules()) {
            CardSummary s = map.get(rule.cardId);
            if (s == null) continue;
            s.ruleCount++;
            if (rule.hasEnded(today)) s.endedRuleCount++;
            else if (rule.paused) s.pausedRuleCount++;
            if (!rule.paused && !rule.hasEnded(today)) {
                s.activeRuleCount++;
                if (rule.endDate == null) {
                    s.unlimitedRuleCount++;
                    long annual = Recurrence.annualized(rule.frequency,rule.amount);
                    s.unlimitedAnnualCommitment = Money.add(s.unlimitedAnnualCommitment,annual);
                    s.annualCommitment = Money.add(s.annualCommitment,annual);
                } else {
                    s.limitedRuleCount++;
                    long remaining = Money.times(rule.amount,Recurrence.remainingOccurrences(rule,today,rule.endDate));
                    s.remainingCommitment = Money.add(s.remainingCommitment,remaining);
                    long horizon = Math.min(rule.endDate,CivilDate.addMonths(today,12)-1);
                    s.annualCommitment = Money.add(s.annualCommitment,
                            Money.times(rule.amount,Recurrence.remainingOccurrences(rule,today,horizon)));
                }
            }
        }
        for (CardSummary s : out) s.outstanding = Money.sub(s.expenses, s.cashback);
        Collections.sort(out, Models.CARD_ORDER);
        return out;
    }

    public CardSummary summary(long cardId) {
        for (CardSummary s : summaries()) if (s.card.id == cardId) return s;
        return null;
    }

    public static long totalDue(List<CardSummary> list) {
        long t = 0;
        for (CardSummary s : list) t = Money.add(t, s.outstanding);
        return t;
    }

    /** Clears the card's current transactions; recurring rules are kept untouched. */
    public int markPaid(long cardId) {
        return db.exec("DELETE FROM txns WHERE card_id=?", cardId);
    }

    // ================================================================ transactions

    public static String cleanText(String s, int max, String field) {
        String t = s == null ? "" : s.trim();
        if (t.length() > max) throw new IllegalArgumentException(field + " is too long (max " + max + ")");
        return t;
    }

    public long addTxn(long cardId, int type, long amount, long date, String description, String note) {
        validateTxn(cardId, type, amount);
        return db.insert("INSERT INTO txns(card_id, type, amount, date, description, note, created_at)"
                        + " VALUES (?,?,?,?,?,?,?)",
                cardId, type, amount, date, cleanText(description, MAX_TEXT, "Description"),
                cleanText(note, MAX_NOTE, "Notes"), clock.nowMillis());
    }

    public void updateTxn(long id, int type, long amount, long date, String description, String note) {
        Txn t = getTxn(id);
        if (t == null) throw new IllegalArgumentException("Transaction not found");
        validateTxn(t.cardId, type, amount);
        db.exec("UPDATE txns SET type=?, amount=?, date=?, description=?, note=? WHERE id=?",
                type, amount, date, cleanText(description, MAX_TEXT, "Description"),
                cleanText(note, MAX_NOTE, "Notes"), id);
    }

    private void validateTxn(long cardId, int type, long amount) {
        if (type != Models.TYPE_EXPENSE && type != Models.TYPE_CASHBACK) throw new IllegalArgumentException("Invalid type");
        if (amount <= 0) throw new IllegalArgumentException("Amount must be greater than zero");
        if (amount > Money.MAX_INPUT) throw new IllegalArgumentException("Amount is too large");
        if (getCard(cardId) == null) throw new IllegalArgumentException("Card not found");
    }

    public void deleteTxn(long id) { db.exec("DELETE FROM txns WHERE id=?", id); }

    public Txn getTxn(long id) {
        List<Db.Row> r = db.query("SELECT * FROM txns WHERE id=?", id);
        return r.isEmpty() ? null : txn(r.get(0));
    }

    /** Transactions for a card in chronological order (oldest first). */
    public List<Txn> listTxns(long cardId) {
        List<Txn> out = new ArrayList<Txn>();
        for (Db.Row r : db.query("SELECT * FROM txns WHERE card_id=? ORDER BY date ASC, id ASC", cardId)) out.add(txn(r));
        return out;
    }

    private static Txn txn(Db.Row r) {
        Txn t = new Txn();
        t.id = r.getLong("id");
        t.cardId = r.getLong("card_id");
        t.type = r.getInt("type");
        t.amount = r.getLong("amount");
        t.date = r.getLong("date");
        t.description = r.getString("description");
        t.note = r.getString("note");
        t.recurringId = r.getLongOrNull("recurring_id");
        t.occurrence = r.getLongOrNull("occurrence");
        t.createdAt = r.getLong("created_at");
        return t;
    }

    // ================================================================ recurring rules

    public long createRule(long cardId, String name, long amount, int frequency, long firstDate, String note) {
        return createRule(cardId,name,amount,frequency,firstDate,note,null);
    }

    public long createRule(long cardId, String name, long amount, int frequency, long firstDate, String note, Long endDate) {
        validateRule(cardId, amount, frequency);
        validateEndDate(firstDate,endDate);
        return db.insert("INSERT INTO rules(card_id, name, amount, frequency, start_date, anchor_day, next_index,"
                        + " paused, note, created_at, end_date) VALUES (?,?,?,?,?,?,0,0,?,?,?)",
                cardId, cleanName(name), amount, frequency, firstDate, CivilDate.day(firstDate),
                cleanText(note, MAX_NOTE, "Notes"), clock.nowMillis(),endDate);
    }

    public static void validateEndDate(long startDate,Long endDate) {
        if (endDate != null && endDate < startDate) throw new IllegalArgumentException("End date cannot be before the first payment date");
    }

    /** Projects exactly the schedule saved by the Start date form, without posting or writing. */
    public Rule previewRuleFromStart(long id, int frequency, long startDate, Long endDate, long today) {
        if (!Recurrence.isValidFrequency(frequency)) throw new IllegalArgumentException("Invalid frequency");
        validateEndDate(startDate,endDate);
        Rule old = id > 0 ? getRule(id) : null;
        if (id > 0 && old == null) throw new IllegalArgumentException("Recurring payment not found");
        boolean changed = old == null || old.frequency != frequency || old.startDate != startDate;
        Rule r = new Rule();
        r.frequency=frequency; r.startDate=startDate; r.endDate=endDate;
        r.anchorDay=changed ? CivilDate.day(startDate) : old.anchorDay;
        r.nextIndex=Recurrence.firstIndexOnOrAfter(frequency,startDate,r.anchorDay,changed ? 0 : old.nextIndex,today);
        if (old != null) {
            r.paused=old.paused; r.pausedAt=old.pausedAt; r.pauseUntil=old.pauseUntil;
            // A changed historical anchor must not charge today's already posted instalment twice.
            if (changed && r.nextDate() == today && !db.query("SELECT id FROM txns WHERE recurring_id=? AND date=?",id,today).isEmpty()) r.nextIndex++;
        }
        return r;
    }

    /** Historical starts establish the anchor; only today and future dates become newly eligible. */
    public long saveRuleFromStart(final long id, final long cardId, final String name, final long amount,
                                 final int frequency, final long startDate, final String note,
                                 final Long endDate, final long today) {
        final long[] saved={id};
        db.transaction(() -> {
            validateRule(cardId,amount,frequency);
            Rule old=id > 0 ? getRule(id) : null;
            if (old != null && old.cardId != cardId) throw new IllegalArgumentException("Recurring payment belongs to another card");
            Rule plan=previewRuleFromStart(id,frequency,startDate,endDate,today);
            String n=cleanName(name), nt=cleanText(note,MAX_NOTE,"Notes");
            if (id <= 0) saved[0]=createRule(cardId,n,amount,frequency,startDate,nt,endDate);
            else if (old.frequency != frequency || old.startDate != startDate)
                db.exec("UPDATE txns SET occurrence=NULL WHERE recurring_id=?",id);
            db.exec("UPDATE rules SET name=?,amount=?,frequency=?,start_date=?,anchor_day=?,next_index=?,note=?,end_date=? WHERE id=?",
                    n,amount,frequency,startDate,plan.anchorDay,plan.nextIndex,nt,endDate,saved[0]);
        });
        return saved[0];
    }

    /**
     * Edits a rule. If the frequency or next payment date changes, the schedule is
     * re-anchored at {@code nextDate}; otherwise only name/amount/note change and
     * past postings are left as they were.
     */
    public void updateRule(final long id, final String name, final long amount, final int frequency,
                           final long nextDate, final String note) {
        Rule existing=getRule(id);
        if(existing==null)throw new IllegalArgumentException("Recurring payment not found");
        updateRule(id,name,amount,frequency,nextDate,note,existing.endDate);
    }

    public void updateRule(final long id, final String name, final long amount, final int frequency,
                           final long nextDate, final String note, final Long endDate) {
        db.transaction(new Runnable() {
            @Override public void run() { updateRuleTx(id, name, amount, frequency, nextDate, note, endDate); }
        });
    }

    private void updateRuleTx(long id, String name, long amount, int frequency, long nextDate, String note, Long endDate) {
        Rule r = getRule(id);
        if (r == null) throw new IllegalArgumentException("Recurring payment not found");
        validateRule(r.cardId, amount, frequency);
        String n = cleanName(name);
        String nt = cleanText(note, MAX_NOTE, "Notes");
        Long effective = r.effectiveNextDate();
        boolean scheduleChanged = frequency != r.frequency
                || (effective == null ? nextDate != r.nextDate() : nextDate != effective);
        validateEndDate(scheduleChanged ? nextDate : r.startDate,endDate);
        if (scheduleChanged) {
            // occurrence numbers restart; earlier postings keep their link but not their index
            db.exec("UPDATE txns SET occurrence=NULL WHERE recurring_id=?", id);
            db.exec("UPDATE rules SET name=?, amount=?, frequency=?, start_date=?, anchor_day=?, next_index=0,"
                    + " note=? WHERE id=?", n, amount, frequency, nextDate, CivilDate.day(nextDate), nt, id);
        } else {
            db.exec("UPDATE rules SET name=?, amount=?, note=? WHERE id=?", n, amount, nt, id);
        }
        db.exec("UPDATE rules SET end_date=? WHERE id=?",endDate,id);
    }

    private void validateRule(long cardId, long amount, int frequency) {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be greater than zero");
        if (amount > Money.MAX_INPUT) throw new IllegalArgumentException("Amount is too large");
        if (!Recurrence.isValidFrequency(frequency)) throw new IllegalArgumentException("Invalid frequency");
        if (getCard(cardId) == null) throw new IllegalArgumentException("Card not found");
    }

    /** Deletes the rule; transactions it already posted stay on the card. */
    public void deleteRule(final long id) {
        db.transaction(new Runnable() {
            @Override public void run() {
                db.exec("UPDATE txns SET recurring_id=NULL, occurrence=NULL WHERE recurring_id=?", id);
                db.exec("DELETE FROM rules WHERE id=?", id);
            }
        });
    }

    public Rule getRule(long id) {
        List<Db.Row> r = db.query("SELECT * FROM rules WHERE id=?", id);
        return r.isEmpty() ? null : rule(r.get(0));
    }

    public List<Rule> listRules(long cardId) {
        List<Rule> out = new ArrayList<Rule>();
        for (Db.Row r : db.query("SELECT * FROM rules WHERE card_id=? ORDER BY id", cardId)) out.add(rule(r));
        return out;
    }

    public List<Rule> listAllRules() {
        List<Rule> out = new ArrayList<Rule>();
        for (Db.Row r : db.query("SELECT * FROM rules ORDER BY id")) out.add(rule(r));
        return out;
    }

    private static Rule rule(Db.Row r) {
        Rule x = new Rule();
        x.id = r.getLong("id");
        x.cardId = r.getLong("card_id");
        x.name = r.getString("name");
        x.amount = r.getLong("amount");
        x.frequency = r.getInt("frequency");
        x.startDate = r.getLong("start_date");
        x.anchorDay = r.getInt("anchor_day");
        x.nextIndex = r.getLong("next_index");
        x.paused = r.getInt("paused") != 0;
        x.pausedAt = r.getLongOrNull("paused_at");
        x.pauseUntil = r.getLongOrNull("pause_until");
        x.endDate = r.getLongOrNull("end_date");
        x.note = r.getString("note");
        x.createdAt = r.getLong("created_at");
        return x;
    }

    /**
     * Pauses a rule. Anything already due up to {@code today} is posted first.
     * {@code months <= 0} pauses indefinitely; otherwise it resumes automatically
     * on today + months (clamped to month end).
     */
    public void pauseRule(final long id, final int months, final long today) {
        if (months > MAX_PAUSE_MONTHS) throw new IllegalArgumentException("Pause is limited to " + MAX_PAUSE_MONTHS + " months");
        db.transaction(new Runnable() {
            @Override public void run() {
                Rule r = getRule(id);
                if (r == null) throw new IllegalArgumentException("Recurring payment not found");
                if (r.hasEnded(today)) throw new IllegalArgumentException("Payment has ended. Change or remove its end date first.");
                processRule(r, today);
                Long until = months > 0 ? CivilDate.addMonths(today, months) : null;
                db.exec("UPDATE rules SET paused=1, paused_at=?, pause_until=? WHERE id=?", today, until, id);
            }
        });
    }

    /** Manual resume: occurrences before today are skipped (never charged retroactively). */
    public void resumeRule(final long id, final long today) {
        db.transaction(new Runnable() {
            @Override public void run() {
                Rule r = getRule(id);
                if (r == null) throw new IllegalArgumentException("Recurring payment not found");
                if (r.hasEnded(today)) throw new IllegalArgumentException("Payment has ended. Change or remove its end date first.");
                if (!r.paused) return;
                resumeAt(r, today);
                processRule(getRule(id), today);
            }
        });
    }

    private void resumeAt(Rule r, long resumeDate) {
        long idx = Recurrence.firstIndexOnOrAfter(r.frequency, r.startDate, r.anchorDay, r.nextIndex, resumeDate);
        db.exec("UPDATE rules SET paused=0, paused_at=NULL, pause_until=NULL, next_index=? WHERE id=?", idx, r.id);
        r.paused = false;
        r.pausedAt = null;
        r.pauseUntil = null;
        r.nextIndex = idx;
    }

    /**
     * Posts every due occurrence (including missed ones) for all rules up to and
     * including {@code today}. Timed pauses that have ended are resumed on their end
     * date first, so occurrences inside the pause are skipped. Idempotent.
     * Returns the number of transactions posted.
     */
    public int processDue(final long today) {
        final int[] count = {0};
        db.transaction(new Runnable() {
            @Override public void run() {
                for (Rule r : listAllRules()) count[0] += processRule(r, today);
            }
        });
        return count[0];
    }

    private int processRule(Rule r, long today) {
        if (r.paused) {
            if (r.pauseUntil == null || today < r.pauseUntil) return 0;
            resumeAt(r, r.pauseUntil);
        }
        int posted = 0;
        long idx = r.nextIndex;
        long date = Recurrence.occurrence(r.frequency, r.startDate, r.anchorDay, idx);
        long now = clock.nowMillis();
        while (date <= today && (r.endDate == null || date <= r.endDate) && posted < Recurrence.MAX_CATCH_UP) {
            List<Db.Row> exists = db.query("SELECT id FROM txns WHERE recurring_id=? AND occurrence=?", r.id, idx);
            if (exists.isEmpty()) {
                db.insert("INSERT INTO txns(card_id, type, amount, date, description, note, recurring_id, occurrence,"
                                + " created_at) VALUES (?,?,?,?,?,?,?,?,?)",
                        r.cardId, Models.TYPE_EXPENSE, r.amount, date, r.name, "Recurring", r.id, idx, now);
                posted++;
            }
            idx++;
            date = Recurrence.occurrence(r.frequency, r.startDate, r.anchorDay, idx);
        }
        if (idx != r.nextIndex) {
            db.exec("UPDATE rules SET next_index=? WHERE id=?", idx, r.id);
            r.nextIndex = idx;
        }
        return posted;
    }
}
