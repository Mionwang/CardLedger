package com.apkbench.app.core;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Saved Cards storage. Each record's fields are serialized to JSON and the whole
 * blob is AES-256-GCM encrypted; only the IV, ciphertext and timestamps are stored
 * in SQLite. Duplicate detection decrypts in memory, so no number hash is stored.
 */
public final class VaultRepo {
    private static final Charset UTF8 = Charset.forName("UTF-8");

    private final Db db;
    private final VaultCipher cipher;

    public VaultRepo(Db db, VaultCipher cipher) {
        this.db = db;
        this.cipher = cipher;
    }

    /** Result of loading the vault: readable cards plus ids that failed to decrypt. */
    public static final class Loaded {
        public final List<CardInfo> cards = new ArrayList<CardInfo>();
        public final List<Long> unreadable = new ArrayList<Long>();
    }

    public Loaded load() {
        Loaded out = new Loaded();
        for (Db.Row r : db.query("SELECT * FROM vault ORDER BY id")) {
            long id = r.getLong("id");
            try {
                CardInfo c = decode(cipher.decrypt(r.getBlob("iv"), r.getBlob("data")));
                c.id = id;
                c.createdAt = r.getLong("created_at");
                c.updatedAt = r.getLong("updated_at");
                out.cards.add(c);
            } catch (RuntimeException e) {
                out.unreadable.add(id);
            }
        }
        return out;
    }

    public CardInfo get(long id) {
        for (CardInfo c : load().cards) if (c.id == id) return c;
        return null;
    }

    /** Returns the existing card with the same number (excluding {@code excludeId}), or null. */
    public CardInfo findDuplicate(String digits, long excludeId) {
        for (CardInfo c : load().cards) {
            if (c.id != excludeId && c.number.equals(digits)) return c;
        }
        return null;
    }

    /** Validates (with the current date) and stores a new record. */
    public long add(CardInfo c) {
        c.validateNow();
        return addValidated(c);
    }

    long addValidated(CardInfo c) {
        if (findDuplicate(c.number, -1) != null) throw new IllegalArgumentException("This card is already saved");
        VaultCipher.Sealed s = seal(c);
        long now = System.currentTimeMillis();
        return db.insert("INSERT INTO vault(iv, data, created_at, updated_at) VALUES (?,?,?,?)", s.iv, s.data, now, now);
    }

    public void update(CardInfo c) {
        c.validateNow();
        updateValidated(c);
    }

    void updateValidated(CardInfo c) {
        if (findDuplicate(c.number, c.id) != null) throw new IllegalArgumentException("Another saved card has this number");
        VaultCipher.Sealed s = seal(c);
        int n = db.exec("UPDATE vault SET iv=?, data=?, updated_at=? WHERE id=?", s.iv, s.data, System.currentTimeMillis(), c.id);
        if (n != 1) throw new IllegalArgumentException("Saved card not found");
    }

    public void delete(long id) { db.exec("DELETE FROM vault WHERE id=?", id); }

    /** Adds several pre-validated records atomically. */
    public int addAll(final List<CardInfo> list) {
        db.transaction(new Runnable() {
            @Override public void run() {
                for (CardInfo c : list) addValidated(c);
            }
        });
        return list.size();
    }

    private VaultCipher.Sealed seal(CardInfo c) {
        byte[] plain = encode(c);
        try {
            return cipher.encrypt(plain);
        } finally {
            Arrays.fill(plain, (byte) 0);
        }
    }

    static byte[] encode(CardInfo c) {
        Map<String, Object> m = new LinkedHashMap<String, Object>();
        m.put("bank", c.bank);
        m.put("product", c.product);
        m.put("holder", c.holder);
        m.put("number", c.number);
        m.put("expMonth", (long) c.expMonth);
        m.put("expYear", (long) c.expYear);
        m.put("network", c.network);
        m.put("kind", c.kind);
        m.put("cvv", c.cvv);
        return Json.write(m).getBytes(UTF8);
    }

    static CardInfo decode(byte[] plain) {
        try {
            Json.Obj o = Json.Obj.of(Json.parse(new String(plain, UTF8)), "record");
            CardInfo c = new CardInfo();
            c.bank = o.str("bank", false);
            c.product = o.str("product", false);
            c.holder = o.str("holder", false);
            c.number = o.str("number", true);
            // v1.x payloads retain the original authenticated session key and AAD.
            String oldExpiry = o.str("expiry", false);
            if (o.has("expiry")) {
                if (!oldExpiry.isEmpty()) {
                    int[] expiry = CardInfo.parseExpiry(oldExpiry);
                    c.expMonth = expiry[0];
                    c.expYear = expiry[1];
                }
            } else {
                c.expMonth = (int) o.integer("expMonth", true, 0);
                c.expYear = (int) o.integer("expYear", true, 0);
            }
            c.network = o.str("network", false);
            c.kind = o.str("kind", false);
            c.cvv = o.str("cvv", false);
            return c;
        } catch (Json.ParseException e) {
            throw new IllegalStateException("Corrupt record");
        } finally {
            Arrays.fill(plain, (byte) 0);
        }
    }
}
