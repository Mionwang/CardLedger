package com.apkbench.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.text.InputFilter;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ScrollView;
import android.widget.TextView;

import com.apkbench.app.core.CivilDate;
import com.apkbench.app.core.Currencies;
import com.apkbench.app.core.LedgerRepo;
import com.apkbench.app.core.Models;

/** Shared dialogs. All validation errors are shown inline; dialogs stay open until input is valid. */
final class Dialogs {
    private Dialogs() {}

    interface Done { void run(); }
    interface DatePicked { void picked(long epochDay); }
    interface Picked { void picked(int index); }

    static AlertDialog.Builder builder(Activity a) { return new AlertDialog.Builder(a); }

    static LinearLayout dialogBody(Activity a) {
        LinearLayout l = Ui.col(a);
        int p = Ui.dp(a, 22);
        l.setPadding(p, Ui.dp(a, 8), p, 0);
        return l;
    }

    static void confirm(Activity a, String title, String message, String action, boolean destructive, final Done done) {
        AlertDialog d = builder(a).setTitle(title).setMessage(message)
                .setNegativeButton("Cancel", null)
                .setPositiveButton(action, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface di, int w) { done.run(); }
                }).create();
        d.show();
        if (destructive) d.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Ui.DANGER);
    }

    static void info(Activity a, String title, String message) {
        builder(a).setTitle(title).setMessage(message).setPositiveButton("OK", null).show();
    }

    /** Long-press menu. */
    static void actions(Activity a, String title, String[] items, final Picked picked) {
        builder(a).setTitle(title).setItems(items, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) { picked.picked(which); }
        }).show();
    }

    static void pickDate(Activity a, long current, final DatePicked picked) {
        int[] p = CivilDate.ymd(current);
        DatePickerDialog d = new DatePickerDialog(a, new DatePickerDialog.OnDateSetListener() {
            @Override public void onDateSet(DatePicker view, int y, int m, int day) {
                picked.picked(CivilDate.of(y, m + 1, day));
            }
        }, p[0], p[1] - 1, p[2]);
        d.show();
    }

    // ------------------------------------------------------------ ledger card add / edit

    /** Add (card == null) or edit a ledger card: name and billing-cycle day. */
    static void cardEditor(final Activity a, final Models.Card card, final Done saved) {
        final App app = App.get();
        LinearLayout body = dialogBody(a);
        final EditText name = Ui.input(a, "e.g. Travel card", Ui.INPUT_TEXT);
        name.setFilters(new InputFilter[]{new InputFilter.LengthFilter(LedgerRepo.MAX_NAME)});
        if (card != null) name.setText(card.name);
        body.addView(Ui.field(a, "Card name", name));
        final NumberPicker day = new NumberPicker(a);
        day.setMinValue(1);
        day.setMaxValue(31);
        day.setValue(card != null && card.billingDay > 0 ? card.billingDay : 1);
        day.setWrapSelectorWheel(true);
        day.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        final TextView hint = Ui.muted(a, "");
        updateDayHint(hint, day.getValue());
        day.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override public void onValueChange(NumberPicker p, int o, int n) { updateDayHint(hint, n); }
        });
        body.addView(Ui.label(a, "Billing-cycle day"), Ui.margins(a, Ui.matchWrap(), 2, 0, 0, 2));
        body.addView(day, Ui.matchWrap());
        body.addView(hint, Ui.margins(a, Ui.matchWrap(), 2, 4, 0, 8));

        final AlertDialog d = builder(a).setTitle(card == null ? "Add card" : "Edit card").setView(Ui.scroll(a, body))
                .setNegativeButton("Cancel", null).setPositiveButton(card == null ? "Add" : "Save", null).create();
        d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        d.show();
        if (card == null) name.requestFocus();
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    if (card == null) app.ledger().createCard(name.getText().toString(), day.getValue());
                    else app.ledger().updateCard(card.id, name.getText().toString(), day.getValue());
                    d.dismiss();
                    saved.run();
                } catch (IllegalArgumentException e) {
                    Ui.error(name, e.getMessage());
                }
            }
        });
    }

    private static void updateDayHint(TextView hint, int day) {
        long today = CivilDate.today();
        long next = com.apkbench.app.core.BillingCycle.nextStatement(day, today);
        String s = "Next statement " + CivilDate.display(next);
        if (day > 28) s += ". In shorter months it falls on the last day.";
        hint.setText(s);
    }

    // ------------------------------------------------------------ currency

    static void currency(final Activity a, final Done changed) {
        final App app = App.get();
        String detected = Currencies.forCountry(app.simCountry());
        final String[][] list = Currencies.LIST;
        String[] items = new String[list.length + 1];
        items[0] = "Automatic from SIM (" + detected + ")";
        String pref = app.currencyPref();
        int checked = 0;
        for (int i = 0; i < list.length; i++) {
            items[i + 1] = list[i][2] + " (" + list[i][1].trim() + ")";
            if (list[i][0].equals(pref)) checked = i + 1;
        }
        builder(a).setTitle("Currency")
                .setSingleChoiceItems(items, checked, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        app.setCurrencyPref(which == 0 ? Currencies.AUTO : list[which - 1][0]);
                        d.dismiss();
                        changed.run();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ------------------------------------------------------------ pause

    interface PauseChosen { void chosen(int months); } // 0 = indefinitely

    static void pause(Activity a, final PauseChosen chosen) {
        LinearLayout body = dialogBody(a);
        body.addView(Ui.muted(a, "No payments are added while paused, and skipped payments are never charged later."),
                Ui.margins(a, Ui.matchWrap(), 0, 0, 0, 12));
        final int[] mode = {1};
        final NumberPicker months = new NumberPicker(a);
        months.setMinValue(1);
        months.setMaxValue(LedgerRepo.MAX_PAUSE_MONTHS);
        months.setValue(1);
        months.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        final TextView monthsLabel = Ui.muted(a, "months, then resume automatically");
        body.addView(Ui.segmented(a, new String[]{"Indefinitely", "For months"}, 1, new Ui.SegmentListener() {
            @Override public void onSelected(int index) {
                mode[0] = index;
                months.setVisibility(index == 1 ? View.VISIBLE : View.GONE);
                monthsLabel.setVisibility(index == 1 ? View.VISIBLE : View.GONE);
            }
        }));
        body.addView(months, Ui.margins(a, Ui.matchWrap(), 0, 8, 0, 0));
        body.addView(monthsLabel, Ui.margins(a, Ui.matchWrap(), 0, 0, 0, 8));
        monthsLabel.setGravity(android.view.Gravity.CENTER);
        builder(a).setTitle("Pause recurring payment").setView(body)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Pause", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        chosen.chosen(mode[0] == 0 ? 0 : months.getValue());
                    }
                }).show();
    }

    // ------------------------------------------------------------ preview

    static void preview(Activity a, String title, String text, String action, boolean enabled, final Done done) {
        ScrollView sv = new ScrollView(a);
        TextView t = Ui.text(a, text, 14, Ui.TEXT, Ui.SANS);
        int p = Ui.dp(a, 22);
        t.setPadding(p, Ui.dp(a, 8), p, Ui.dp(a, 8));
        t.setTextIsSelectable(false);
        sv.addView(t);
        AlertDialog d = builder(a).setTitle(title).setView(sv)
                .setNegativeButton("Cancel", null)
                .setPositiveButton(action, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface di, int w) { done.run(); }
                }).create();
        d.show();
        Button b = d.getButton(AlertDialog.BUTTON_POSITIVE);
        b.setEnabled(enabled);
        if (!enabled) b.setAlpha(0.4f);
    }
}
