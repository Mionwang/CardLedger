package com.apkbench.app.core;

/**
 * Schedule math for recurring payments.
 *
 * A schedule is anchored at {@code start} (the first payment date) with an
 * {@code anchorDay} (the intended day of month). Occurrence n is computed from the
 * anchor every time, so month-end clamping never drifts: a payment on the 31st
 * falls on 30 Apr, 28/29 Feb, and returns to 31 May. A yearly payment on 29 Feb
 * falls on 28 Feb in common years and 29 Feb in leap years.
 */
public final class Recurrence {
    private Recurrence() {}

    public static final int WEEKLY = 0;
    public static final int MONTHLY = 1;
    public static final int YEARLY = 2;

    /** Safety bound on how many occurrences one catch-up pass will generate per rule. */
    public static final int MAX_CATCH_UP = 20000;

    public static boolean isValidFrequency(int f) { return f == WEEKLY || f == MONTHLY || f == YEARLY; }

    public static String frequencyName(int f) {
        switch (f) {
            case WEEKLY: return "Weekly";
            case MONTHLY: return "Monthly";
            case YEARLY: return "Yearly";
            default: return "Unknown";
        }
    }

    public static String frequencyKey(int f) {
        switch (f) {
            case WEEKLY: return "weekly";
            case MONTHLY: return "monthly";
            case YEARLY: return "yearly";
            default: throw new IllegalArgumentException("Invalid frequency");
        }
    }

    public static int parseFrequency(String s) {
        if ("weekly".equalsIgnoreCase(s)) return WEEKLY;
        if ("monthly".equalsIgnoreCase(s)) return MONTHLY;
        if ("yearly".equalsIgnoreCase(s) || "annual".equalsIgnoreCase(s) || "annually".equalsIgnoreCase(s)) return YEARLY;
        throw new IllegalArgumentException("Frequency must be weekly, monthly or yearly");
    }

    /** Date (epoch day) of occurrence {@code n} (0-based). */
    public static long occurrence(int frequency, long start, int anchorDay, long n) {
        if (n < 0) throw new IllegalArgumentException("n < 0");
        switch (frequency) {
            case WEEKLY:
                return start + 7 * n;
            case MONTHLY:
                return CivilDate.addMonths(start, (int) n, anchorDay);
            case YEARLY: {
                int[] p = CivilDate.ymd(start);
                return CivilDate.clamped(p[0] + (int) n, p[1], anchorDay);
            }
            default:
                throw new IllegalArgumentException("Invalid frequency");
        }
    }

    /** Smallest index {@code >= from} whose occurrence date is on or after {@code date}. */
    public static long firstIndexOnOrAfter(int frequency, long start, int anchorDay, long from, long date) {
        long n = from;
        if (frequency == WEEKLY && date > start) {
            long est = (date - start + 6) / 7;
            if (est > n) n = est;
        }
        int guard = 0;
        while (occurrence(frequency, start, anchorDay, n) < date) {
            n++;
            if (++guard > 1_000_000) throw new IllegalStateException("Schedule did not converge");
        }
        return n;
    }

    /** Unposted upcoming occurrences through an inclusive end; paused rules have no active commitment. */
    public static long remainingOccurrences(Models.Rule rule, long today, long end) {
        if (rule.paused || end < today) return 0;
        long first = firstIndexOnOrAfter(rule.frequency, rule.startDate, rule.anchorDay, rule.nextIndex, today);
        long after = firstIndexOnOrAfter(rule.frequency, rule.startDate, rule.anchorDay, first, end + 1);
        return after - first;
    }

    /** Human description, e.g. "Monthly on the 31st", "Weekly on Monday", "Yearly on 29 Feb". */
    public static String describe(int frequency, long start, int anchorDay) {
        switch (frequency) {
            case WEEKLY:
                return "Weekly on " + CivilDate.weekdayName(start);
            case MONTHLY:
                return "Monthly on the " + CivilDate.ordinal(anchorDay)
                        + (anchorDay > 28 ? " (or month end)" : "");
            case YEARLY:
                return "Yearly on " + anchorDay + " " + CivilDate.monthName(CivilDate.month(start));
            default:
                return "Unknown";
        }
    }

    /** Annualized commitment of one payment in minor units (weekly counts 52 per year). */
    public static long annualized(int frequency, long amount) {
        switch (frequency) {
            case WEEKLY: return Money.times(amount, 52);
            case MONTHLY: return Money.times(amount, 12);
            case YEARLY: return amount;
            default: return 0;
        }
    }
}
