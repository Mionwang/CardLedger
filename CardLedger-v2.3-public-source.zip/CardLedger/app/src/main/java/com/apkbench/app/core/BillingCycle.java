package com.apkbench.app.core;

/**
 * Billing-cycle (statement) dates. A billing day of 29-31 falls on the last day of
 * shorter months (e.g. day 31 -> 30 Apr, 28 Feb or 29 Feb in leap years).
 */
public final class BillingCycle {
    private BillingCycle() {}

    public static boolean isValidDay(int day) { return day >= 1 && day <= 31; }

    /** Statement date in the given month. */
    public static long statementIn(int billingDay, int year, int month) {
        if (!isValidDay(billingDay)) throw new IllegalArgumentException("Billing day must be 1-31");
        return CivilDate.clamped(year, month, billingDay);
    }

    /** Next statement date on or after {@code today}. */
    public static long nextStatement(int billingDay, long today) {
        int[] p = CivilDate.ymd(today);
        long thisMonth = statementIn(billingDay, p[0], p[1]);
        if (thisMonth >= today) return thisMonth;
        long nextMonthFirst = CivilDate.addMonths(CivilDate.of(p[0], p[1], 1), 1, 1);
        int[] q = CivilDate.ymd(nextMonthFirst);
        return statementIn(billingDay, q[0], q[1]);
    }

    /** Most recent statement date strictly before {@code today}. */
    public static long previousStatement(int billingDay, long today) {
        int[] p = CivilDate.ymd(today);
        long thisMonth = statementIn(billingDay, p[0], p[1]);
        if (thisMonth < today) return thisMonth;
        long prevMonthFirst = CivilDate.addMonths(CivilDate.of(p[0], p[1], 1), -1, 1);
        int[] q = CivilDate.ymd(prevMonthFirst);
        return statementIn(billingDay, q[0], q[1]);
    }

    /** {cycleStart, cycleEnd(statement date)} for the cycle containing {@code today}. */
    public static long[] currentCycle(int billingDay, long today) {
        long end = nextStatement(billingDay, today);
        long start = previousStatement(billingDay, today) + 1;
        return new long[]{start, end};
    }

    public static int daysUntilStatement(int billingDay, long today) {
        return (int) (nextStatement(billingDay, today) - today);
    }
}
