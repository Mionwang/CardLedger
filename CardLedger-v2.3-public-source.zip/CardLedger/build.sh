#!/usr/bin/env bash
# Builds Card Ledger using a signing key supplied by the developer.
set -euo pipefail
APP="$(cd "$(dirname "$0")" && pwd)"
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
: "${SDK:?Set ANDROID_SDK_ROOT to SDK platform 35 and build-tools 35.0.0}"
BT="$SDK/build-tools/35.0.0"
ANDROID_JAR="$SDK/platforms/android-35/android.jar"
JAVA="${JAVA_HOME:+$JAVA_HOME/bin/}java"
JAVAC="${JAVA_HOME:+$JAVA_HOME/bin/}javac"
cd "$APP"
# A fresh build directory avoids stale classes without deleting prior work.
BUILD="$(mktemp -d "$APP/build-run-XXXXXXXX")"
mkdir -p "$BUILD/gen" "$BUILD/classes" "$BUILD/dex" dist
"$BT/aapt2" compile --dir app/src/main/res -o "$BUILD/resources.zip"
"$BT/aapt2" link -o "$BUILD/resources.apk" -I "$ANDROID_JAR" --manifest app/src/main/AndroidManifest.xml \
    --java "$BUILD/gen" --custom-package com.apkbench.app --min-sdk-version 23 --target-sdk-version 34 \
    --version-code 13 --version-name 2.3 -A app/src/main/assets "$BUILD/resources.zip"
find app/src/main/java "$BUILD/gen" -name '*.java' -print > "$BUILD/java-sources.txt"
"$JAVAC" -encoding UTF-8 -source 8 -target 8 -Xlint:unchecked -classpath "$ANDROID_JAR" \
    -d "$BUILD/classes" @"$BUILD/java-sources.txt"
find "$BUILD/classes" -name '*.class' -print > "$BUILD/class-files.txt"
"$JAVA" -cp "$BT/lib/d8.jar" com.android.tools.r8.D8 --release --min-api 23 --lib "$ANDROID_JAR" \
    --output "$BUILD/dex" @"$BUILD/class-files.txt"
cp "$BUILD/resources.apk" "$BUILD/unaligned.apk"
(cd "$BUILD/dex" && zip -q ../unaligned.apk classes*.dex)
"$BT/zipalign" -f -p 4 "$BUILD/unaligned.apk" "$BUILD/aligned.apk"
: "${CARDLEDGER_KEYSTORE:?Set CARDLEDGER_KEYSTORE to your own keystore outside the source folder}"
: "${CARDLEDGER_KEY_ALIAS:?Set CARDLEDGER_KEY_ALIAS}"
: "${CARDLEDGER_STORE_PASSWORD:?Set CARDLEDGER_STORE_PASSWORD}"
CARDLEDGER_KEY_PASSWORD="${CARDLEDGER_KEY_PASSWORD:-$CARDLEDGER_STORE_PASSWORD}"
export CARDLEDGER_STORE_PASSWORD CARDLEDGER_KEY_PASSWORD
"$BT/apksigner" sign --ks "$CARDLEDGER_KEYSTORE" --ks-key-alias "$CARDLEDGER_KEY_ALIAS" \
    --ks-pass env:CARDLEDGER_STORE_PASSWORD --key-pass env:CARDLEDGER_KEY_PASSWORD \
    --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true \
    --out dist/CardLedger-v2.3-update.apk "$BUILD/aligned.apk"
"$BT/zipalign" -c -p 4 dist/CardLedger-v2.3-update.apk
"$BT/apksigner" verify --verbose --print-certs dist/CardLedger-v2.3-update.apk
printf '%s\n' "$BUILD" > last-build-path.txt
if [[ "${1:-}" != "--no-test" ]]; then bash tests/run.sh; fi
