#!/usr/bin/env python3
from pathlib import Path
import os, re, subprocess, xml.etree.ElementTree as E, zipfile

root = Path(__file__).resolve().parents[1]
ns = '{http://schemas.android.com/apk/res/android}'
manifest = E.parse(root/'app/src/main/AndroidManifest.xml').getroot()
assert manifest.get('package') == 'com.mion.cardledger.v14'
app = manifest.find('application')
for flag in ['allowBackup','fullBackupContent','debuggable','usesCleartextTraffic']:
    assert app.get(ns+flag) == 'false', flag
permissions = {p.get(ns+'name') for p in manifest.findall('uses-permission')}
assert permissions == {'android.permission.NFC','android.permission.USE_BIOMETRIC','android.permission.USE_FINGERPRINT'}
for a in app.findall('activity'):
    assert a.get(ns+'exported') == ('true' if a.get(ns+'name') == 'com.mion.cardledger.MainActivity' else 'false')
launcher = next(a for a in app.findall('activity') if a.get(ns+'name') == 'com.mion.cardledger.MainActivity')
assert launcher.find('intent-filter/action').get(ns+'name') == 'android.intent.action.MAIN'
assert launcher.find('intent-filter/category').get(ns+'name') == 'android.intent.category.LAUNCHER'
backup = E.parse(root/'app/src/main/res/xml/data_extraction_rules.xml').getroot()
for section in ['cloud-backup','device-transfer']:
    excludes = {(e.get('domain'),e.get('path')) for e in backup.find(section).findall('exclude')}
    assert {('root','.'),('file','.'),('database','.'),('sharedpref','.'),('external','.')} <= excludes
apk = root/'dist/CardLedger-v2.3-update.apk'
bt = Path(os.environ['ANDROID_SDK_ROOT'])/'build-tools/35.0.0'
badging = subprocess.check_output([str(bt/'aapt2'),'dump','badging',str(apk)],text=True)
assert "name='com.mion.cardledger.v14' versionCode='13' versionName='2.3'" in badging
assert "application-label:'Card Ledger'" in badging
assert "launchable-activity: name='com.mion.cardledger.MainActivity'" in badging
assert set(re.findall(r"uses-permission: name='([^']+)'",badging)) == permissions
signature = subprocess.check_output([str(bt/'apksigner'),'verify','--verbose','--print-certs',str(apk)],text=True)
expected_cert = os.environ.get('CARDLEDGER_EXPECTED_CERT_SHA256')
if expected_cert:
    assert expected_cert.lower().replace(':','') in signature.lower(), 'Unexpected signing certificate' 
for scheme in [1,2,3]: assert re.search(r'Verified using v'+str(scheme)+r' scheme.*true',signature)
subprocess.run([str(bt/'zipalign'),'-c','-p','4',str(apk)],check=True)
with zipfile.ZipFile(apk) as z:
    assert z.testzip() is None
    assert 'assets/fonts/DMMono-Regular.ttf' in z.namelist()
    dex = b''.join(z.read(n) for n in z.namelist() if n.endswith('.dex'))
    for test in [b'JdbcDb',b'LegacyUpgradeTest',b'LegacyCryptoCompatibilityTest',b'Lorg/junit/']:
        assert test not in dex, 'Test code leaked into APK'
print('PASS: actual APK identity, app label, legacy launcher, unchanged permissions, backup restrictions, no test adapters, optional signing certificate pin, v1/v2/v3 signatures and alignment')
