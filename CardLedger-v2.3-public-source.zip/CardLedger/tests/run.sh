#!/usr/bin/env bash
set -euo pipefail
APP="$(cd "$(dirname "$0")/.." && pwd)"
cd "$APP"
: "${JUNIT_JAR:?Point to junit 4.13.2}"
: "${HAMCREST_JAR:?Point to hamcrest-core 1.3}"
: "${SQLITE_JDBC_JAR:?Point to sqlite-jdbc 3.46.1.0}"
: "${SLF4J_JAR:?Point to slf4j-api 2.0.13}"
: "${ANDROID_SDK_ROOT:?Set ANDROID_SDK_ROOT}"
BUILD="$(cat last-build-path.txt)"
JAVA="${JAVA_HOME:+$JAVA_HOME/bin/}java"
JAVAC="${JAVA_HOME:+$JAVA_HOME/bin/}javac"
CP="$BUILD/classes:$ANDROID_SDK_ROOT/platforms/android-35/android.jar:$JUNIT_JAR:$HAMCREST_JAR:$SQLITE_JDBC_JAR:$SLF4J_JAR"
mkdir -p "$BUILD/test-classes"
find app/src/test/java -name '*.java' -print > "$BUILD/test-sources.txt"
"$JAVAC" -encoding UTF-8 -classpath "$CP" -d "$BUILD/test-classes" @"$BUILD/test-sources.txt"
TESTS=$(python3 - <<'PYTEST'
from pathlib import Path
root=Path('app/src/test/java')
print(' '.join('.'.join(p.relative_to(root).with_suffix('').parts) for p in sorted(root.rglob('*Test.java'))))
PYTEST
)
"$JAVA" -classpath "$BUILD/test-classes:$CP" org.junit.runner.JUnitCore $TESTS
